// BlueprintGeneratedClass BB_AugmentsList.BB_AugmentsList_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_AugmentsList_C : UFortMobileActionButtonBehavior {
};


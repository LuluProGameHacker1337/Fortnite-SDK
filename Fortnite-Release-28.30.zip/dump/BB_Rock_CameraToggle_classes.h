// BlueprintGeneratedClass BB_Rock_CameraToggle.BB_Rock_CameraToggle_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_Rock_CameraToggle_C : UFortMobileActionButtonBehavior {
};


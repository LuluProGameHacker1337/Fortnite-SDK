// BlueprintGeneratedClass CamShake_Shadow_Bomb.CamShake_Shadow_Bomb_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCamShake_Shadow_Bomb_C : ULegacyCameraShake {
};


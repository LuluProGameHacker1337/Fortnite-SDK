// BlueprintGeneratedClass Border-ItemInfo-Locked.Border-ItemInfo-Locked_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-ItemInfo-Locked_C : UBorder-ItemInfo-Unlocked_C {
};


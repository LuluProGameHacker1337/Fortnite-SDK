// WidgetBlueprintGeneratedClass CameraDebugDisplay.CameraDebugDisplay_C
// Size: 0x318 (Inherited: 0x2c0)
struct UCameraDebugDisplay_C : UUserWidget {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2c0(0x08)
	struct UCommonTextBlock* CamForwardText; // 0x2c8(0x08)
	struct UCommonTextBlock* ConfinedSpaceText; // 0x2d0(0x08)
	struct UCommonTextBlock* FAActor; // 0x2d8(0x08)
	struct UCommonTextBlock* FAText; // 0x2e0(0x08)
	struct UCommonTextBlock* FOVText; // 0x2e8(0x08)
	struct UCommonTextBlock* InteriorCheckText; // 0x2f0(0x08)
	struct UCommonTextBlock* VActor; // 0x2f8(0x08)
	struct UCommonTextBlock* VertProbeText; // 0x300(0x08)
	struct UCommonTextBlock* ZOffsetText; // 0x308(0x08)
	struct UJunoCameraMode_OrbitCam_C* As Juno Camera Mode Orbit Cam; // 0x310(0x08)

	void InitFromObject(struct UObject* InitObject); // Function CameraDebugDisplay.CameraDebugDisplay_C.InitFromObject // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Tick(struct FGeometry MyGeometry, float InDeltaTime); // Function CameraDebugDisplay.CameraDebugDisplay_C.Tick // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_CameraDebugDisplay(int32_t EntryPoint); // Function CameraDebugDisplay.CameraDebugDisplay_C.ExecuteUbergraph_CameraDebugDisplay // (Final|UbergraphFunction|HasDefaults) // @ game+0x3d1d968
};


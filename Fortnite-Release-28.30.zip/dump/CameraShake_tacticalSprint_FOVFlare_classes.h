// BlueprintGeneratedClass CameraShake_tacticalSprint_FOVFlare.CameraShake_tacticalSprint_FOVFlare_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_tacticalSprint_FOVFlare_C : ULegacyCameraShake {
};


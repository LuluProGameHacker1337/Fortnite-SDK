// BlueprintGeneratedClass Athena_PlayerCamera_DBNO.Athena_PlayerCamera_DBNO_C
// Size: 0x1ba0 (Inherited: 0x1ba0)
struct UAthena_PlayerCamera_DBNO_C : UAthena_PlayerCameraModeBase_C {
};


// BlueprintGeneratedClass CamShake_Spooky_Dive.CamShake_Spooky_Dive_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCamShake_Spooky_Dive_C : ULegacyCameraShake {
};


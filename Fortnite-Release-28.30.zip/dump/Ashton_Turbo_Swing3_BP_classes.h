// BlueprintGeneratedClass Ashton_Turbo_Swing3_BP.Ashton_Turbo_Swing3_BP_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UAshton_Turbo_Swing3_BP_C : ULegacyCameraShake {
};


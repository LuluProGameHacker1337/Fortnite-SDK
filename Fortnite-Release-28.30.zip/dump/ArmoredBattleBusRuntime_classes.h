// Class ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance
// Size: 0x16f0 (Inherited: 0x1620)
struct UFortArmoredBattleBusPassengerAnimInstance : UFortPlayerAnimInstanceProxy {
	struct FRotator PreviousVehicleRotator; // 0x1620(0x18)
	float SmoothedVehicleYawRate; // 0x1638(0x04)
	int32_t PawnSeat; // 0x163c(0x04)
	bool bIsFrontTurretPassenger; // 0x1640(0x01)
	bool bIsRearTurretPassenger; // 0x1641(0x01)
	char pad_1642[0x2]; // 0x1642(0x02)
	float Speed; // 0x1644(0x04)
	float YawDelta; // 0x1648(0x04)
	float TurretYaw; // 0x164c(0x04)
	float TurretPitch; // 0x1650(0x04)
	char pad_1654[0x4]; // 0x1654(0x04)
	struct FRotator TurretYawRotator; // 0x1658(0x18)
	float SlopeRollDegreeAngle; // 0x1670(0x04)
	float SlopePitchDegreeAngle; // 0x1674(0x04)
	struct FVector HandAttachL; // 0x1678(0x18)
	struct FVector HandAttachR; // 0x1690(0x18)
	enum class ERelativeTransformSpace TransformSpace; // 0x16a8(0x01)
	char pad_16A9[0x3]; // 0x16a9(0x03)
	float UpdateYawDeltaSmoothedLerpRate; // 0x16ac(0x04)
	int32_t TurretPassengerFront; // 0x16b0(0x04)
	int32_t TurretPassengerRear; // 0x16b4(0x04)
	struct FName FrontFootBoneName; // 0x16b8(0x04)
	struct FName RearFootBoneName; // 0x16bc(0x04)
	struct FName GunHandAttachBoneName_FrontLeft; // 0x16c0(0x04)
	struct FName GunHandAttachBoneName_RearLeft; // 0x16c4(0x04)
	struct FName GunHandAttachBoneName_FrontRight; // 0x16c8(0x04)
	struct FName GunHandAttachBoneName_RearRight; // 0x16cc(0x04)
	struct FName PassengerBoneName_Front; // 0x16d0(0x04)
	struct FName PassengerBoneName_Rear; // 0x16d4(0x04)
	float TurretPitchDegMin; // 0x16d8(0x04)
	float TurretPitchDegMax; // 0x16dc(0x04)
	float LocalPlayerTurretPitchEaseRate; // 0x16e0(0x04)
	char pad_16E4[0xc]; // 0x16e4(0x0c)

	void UpdateYawDeltaSmoothed(struct AFortAthenaVehicle* VehicleActor, struct FName SocketName, struct FRotator& NewRotation, float& SmoothedYawValue); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateYawDeltaSmoothed // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xaccd2ec
	void UpdateSmoothedVehicleYawRate(struct AFortAthenaVehicle* VehicleActor); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateSmoothedVehicleYawRate // (Final|Native|Public|BlueprintCallable) // @ game+0xacccd7c
	void UpdateHandPositionsSlopeValues(struct USkeletalMeshComponent* BusMeshComponent); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UpdateHandPositionsSlopeValues // (Final|Native|Public|BlueprintCallable) // @ game+0xaccccfc
	struct FVector UnrotateHandAttachLocation(struct FVector& HandLocation, struct FVector& FootLocation, struct FRotator& FootRotation); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.UnrotateHandAttachLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xacccb38
	struct FTransform GetPassengerTransform(struct USkeletalMeshComponent* BusMeshComponent); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetPassengerTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xaccc860
	struct FVector GetHandAttachLocation(struct USkeletalMeshComponent* BusMeshComponent, struct FName FrontHandAttachBoneName, struct FName RearHandAttachBoneName); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetHandAttachLocation // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xaccc750
	struct FTransform GetFootAttachTransform(struct USkeletalMeshComponent* BusMeshComponent); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GetFootAttachTransform // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xaccc674
	void GenerateCharacterPitchAndYawForSlopedTerrain(struct AFortAthenaVehicle* VehicleActor, float& TurretYaw, float& TurretPitch, struct FRotator& PawnYawRotator); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusPassengerAnimInstance.GenerateCharacterPitchAndYawForSlopedTerrain // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xaccc508
};

// Class ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance
// Size: 0x6b0 (Inherited: 0x620)
struct UFortArmoredBattleBusVehicleAnimInstance : UFortVehicleAnimInstance {
	float FrontTurretAimPitch; // 0x618(0x04)
	float RearTurretAimPitch; // 0x61c(0x04)
	float FrontYawDeltaSmoothed; // 0x620(0x04)
	float RearYawDeltaSmoothed; // 0x624(0x04)
	float SmoothedVehicleYawRate; // 0x628(0x04)
	float FrontYawDeltaSmoothedAlpha; // 0x62c(0x04)
	float RearYawDeltaSmoothedAlpha; // 0x630(0x04)
	struct FRotator FrontWeaponYaw; // 0x638(0x18)
	struct FRotator RearWeaponYaw; // 0x650(0x18)
	struct FRotator PreviousVehicleRotator; // 0x668(0x18)
	bool bHasFrontTurretPassenger; // 0x680(0x01)
	bool bHasRearTurretPassenger; // 0x681(0x01)
	float NetworkEaseRate; // 0x684(0x04)
	float UpdateYawDeltaSmoothedLerpRate; // 0x688(0x04)
	int32_t FrontPassengerSeatIndex; // 0x68c(0x04)
	int32_t RearPassengerSeatIndex; // 0x690(0x04)
	float FrontPassengerYawOffset; // 0x694(0x04)
	float RearPassengerYawOffset; // 0x698(0x04)
	struct FName FrontPassengerBoneName; // 0x69c(0x04)
	struct FName RearPassengerBoneName; // 0x6a0(0x04)
	char pad_6A6[0xa]; // 0x6a6(0x0a)

	float UpdateYawDeltaSmoothed(struct AFortAthenaVehicle* VehicleActor, struct FName SocketName, struct FRotator NewRotation, float SmoothedYawValue); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateYawDeltaSmoothed // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xaccd44c
	void UpdateTurretAimPitchWeaponYaw(struct AFortAthenaVehicle* OwnerVehicle, struct AFortPlayerPawn* GunnerActor, struct FName SocketName, float YawOffset, float& TurretAimPitch, float& YawDeltaSmoothed, struct FRotator& WeaponYaw); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateTurretAimPitchWeaponYaw // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xaccd0b4
	float UpdateSmoothedVehicleYawRate(struct AFortAthenaVehicle* VehicleActor, struct FRotator PreviousRotator); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.UpdateSmoothedVehicleYawRate // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xaccce84
	void GetPitchAndYaw(struct AFortAthenaVehicle* VehicleActor, struct AFortPlayerPawn* GunnerActor, float& AdjustedPitch, float& AdjustedYaw, bool& bIsLocalPlayerControlled, struct FRotator& YawRotator); // Function ArmoredBattleBusRuntime.FortArmoredBattleBusVehicleAnimInstance.GetPitchAndYaw // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xaccc93c
};


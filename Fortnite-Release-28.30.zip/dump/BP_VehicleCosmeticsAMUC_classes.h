// BlueprintGeneratedClass BP_VehicleCosmeticsAMUC.BP_VehicleCosmeticsAMUC_C
// Size: 0x68c (Inherited: 0x678)
struct UBP_VehicleCosmeticsAMUC_C : UVehicleCosmeticsAssembledMeshUserComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x678(0x08)
	struct AFortAthenaVehicle* VehiclePawn; // 0x680(0x08)
	struct FGameplayTag GC_LoopingApplication; // 0x688(0x04)

	void ApplyInitialGC(); // Function BP_VehicleCosmeticsAMUC.BP_VehicleCosmeticsAMUC_C.ApplyInitialGC // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveBeginPlay(); // Function BP_VehicleCosmeticsAMUC.BP_VehicleCosmeticsAMUC_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void RemoveInitialGC(); // Function BP_VehicleCosmeticsAMUC.BP_VehicleCosmeticsAMUC_C.RemoveInitialGC // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_BP_VehicleCosmeticsAMUC(int32_t EntryPoint); // Function BP_VehicleCosmeticsAMUC.BP_VehicleCosmeticsAMUC_C.ExecuteUbergraph_BP_VehicleCosmeticsAMUC // (Final|UbergraphFunction|HasDefaults) // @ game+0x3d1d968
};


// BlueprintGeneratedClass BP_SparksCosmeticPreviewDisplay_Base.BP_SparksCosmeticPreviewDisplay_Base_C
// Size: 0x470 (Inherited: 0x470)
struct ABP_SparksCosmeticPreviewDisplay_Base_C : ASparksInstrumentPreviewActor {
};


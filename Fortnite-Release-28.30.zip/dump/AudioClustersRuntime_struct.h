// ScriptStruct AudioClustersRuntime.AudioClusterActorInfo
// Size: 0x0c (Inherited: 0x00)
struct FAudioClusterActorInfo {
	struct TWeakObjectPtr<struct AActor> Actor; // 0x00(0x08)
	struct FGameplayTag tag; // 0x08(0x04)
};

// ScriptStruct AudioClustersRuntime.AudioClusterOneShotInfo
// Size: 0x28 (Inherited: 0x00)
struct FAudioClusterOneShotInfo {
	struct FGameplayTag tag; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct FVector Position; // 0x08(0x18)
	float LifetimeSeconds; // 0x20(0x04)
	float TimeRemainingSeconds; // 0x24(0x04)
};


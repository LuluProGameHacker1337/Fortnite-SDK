// WidgetBlueprintGeneratedClass BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C
// Size: 0x15f9 (Inherited: 0x1550)
struct UBP_SidebarCollectionScreenContainerTabButtonEditTags_C : UFortSidebarCollectionScreenContainerTabButton {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1550(0x08)
	struct UWidgetAnimation* Selected_Touch; // 0x1558(0x08)
	struct UWidgetAnimation* Unselected_Touch; // 0x1560(0x08)
	struct UWidgetAnimation* Tag_DisabledUnhover; // 0x1568(0x08)
	struct UWidgetAnimation* Tag_DisabledHover; // 0x1570(0x08)
	struct UWidgetAnimation* Tag_DisabledUnhovered; // 0x1578(0x08)
	struct UWidgetAnimation* Tag_DisabledHovered; // 0x1580(0x08)
	struct UWidgetAnimation* Tag_Enabled; // 0x1588(0x08)
	struct UWidgetAnimation* Tag_Unhovered; // 0x1590(0x08)
	struct UWidgetAnimation* Tag_Hovered; // 0x1598(0x08)
	struct UWidgetAnimation* Tag_Reset; // 0x15a0(0x08)
	struct UWidgetAnimation* Reset; // 0x15a8(0x08)
	struct UWidgetAnimation* Unhovered; // 0x15b0(0x08)
	struct UWidgetAnimation* Hovered; // 0x15b8(0x08)
	struct UWidgetAnimation* Unselected; // 0x15c0(0x08)
	struct UWidgetAnimation* Selected; // 0x15c8(0x08)
	struct UHorizontalBox* ; // 0x15d0(0x08)
	struct USpacer* Mobile_Spacer; // 0x15d8(0x08)
	struct UCommonBorder* NewBang; // 0x15e0(0x08)
	struct UOverlay* ; // 0x15e8(0x08)
	struct UScaleBox* ScaleBox_MobileMultiplier; // 0x15f0(0x08)
	bool isTab; // 0x15f8(0x01)

	void HandleInputMethodChanged(enum class ECommonInputType NewInputType); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.HandleInputMethodChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Finished_D3AB39584598BB6DA7EE7C98805576AC(); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.Finished_D3AB39584598BB6DA7EE7C98805576AC // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void BP_OnHovered(); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.BP_OnHovered // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void BP_OnUnhovered(); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.BP_OnUnhovered // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void BP_OnSelected(); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.BP_OnSelected // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void BP_OnDeselected(); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.BP_OnDeselected // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void BP_ShowBang(bool bShow); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.BP_ShowBang // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void Construct(); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.Construct // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void BP_OnTagCategoryChange(enum class ESocialTagCategory InTagCategory); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.BP_OnTagCategoryChange // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void OnInitialized(); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.OnInitialized // (BlueprintCosmetic|Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_BP_SidebarCollectionScreenContainerTabButtonEditTags(int32_t EntryPoint); // Function BP_SidebarCollectionScreenContainerTabButtonEditTags.BP_SidebarCollectionScreenContainerTabButtonEditTags_C.ExecuteUbergraph_BP_SidebarCollectionScreenContainerTabButtonEditTags // (Final|UbergraphFunction|HasDefaults) // @ game+0x3d1d968
};


// BlueprintGeneratedClass ButtonStyle-Base.ButtonStyle-Base_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Base_C : UCommonButtonStyle {
};


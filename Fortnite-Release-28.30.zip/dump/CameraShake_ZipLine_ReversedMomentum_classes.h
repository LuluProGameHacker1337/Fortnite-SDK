// BlueprintGeneratedClass CameraShake_ZipLine_ReversedMomentum.CameraShake_ZipLine_ReversedMomentum_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_ZipLine_ReversedMomentum_C : ULegacyCameraShake {
};


// BlueprintGeneratedClass Athena_PlayerCameraMode_Harveting_1blade_1P.Athena_PlayerCameraMode_Harveting_1blade_1P_C
// Size: 0x1ba0 (Inherited: 0x1ba0)
struct UAthena_PlayerCameraMode_Harveting_1blade_1P_C : UAthena_PlayerCameraMode_1P_C {
};


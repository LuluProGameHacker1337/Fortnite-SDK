// BlueprintGeneratedClass ButtonStyle_VoiceSettings.ButtonStyle_VoiceSettings_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_VoiceSettings_C : UCommonButtonStyle {
};


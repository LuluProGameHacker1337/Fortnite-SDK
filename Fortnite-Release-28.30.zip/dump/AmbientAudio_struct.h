// Enum AmbientAudio.EAmbientAudioEntryActionType
enum class EAmbientAudioEntryActionType : uint8 {
	Added = 0,
	Updated = 1,
	Removed = 2,
	Count = 3,
	EAmbientAudioEntryActionType_MAX = 4
};

// Enum AmbientAudio.EAmbientAudioTagActionType
enum class EAmbientAudioTagActionType : uint8 {
	Added = 0,
	Removed = 1,
	Count = 2,
	EAmbientAudioTagActionType_MAX = 3
};

// ScriptStruct AmbientAudio.AmbientAudioBase
// Size: 0xb8 (Inherited: 0x00)
struct FAmbientAudioBase {
	struct TSoftObjectPtr<USoundBase> sound; // 0x00(0x20)
	struct FGameplayTagQuery Requirements; // 0x20(0x48)
	struct FAudioGameplayRequirements PlaybackRequirements; // 0x68(0x50)
};

// ScriptStruct AmbientAudio.AmbientAudioLoop
// Size: 0xb8 (Inherited: 0xb8)
struct FAmbientAudioLoop : FAmbientAudioBase {
};

// ScriptStruct AmbientAudio.AmbientAudioOneShot
// Size: 0xd8 (Inherited: 0xb8)
struct FAmbientAudioOneShot : FAmbientAudioBase {
	struct FVector2D RetriggerTimeRange; // 0xb8(0x10)
	struct FVector2D TriggerDistanceRange; // 0xc8(0x10)
};


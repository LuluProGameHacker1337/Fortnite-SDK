// BlueprintGeneratedClass B_SparksCosmeticPreviewDisplay.B_SparksCosmeticPreviewDisplay_C
// Size: 0x4c0 (Inherited: 0x470)
struct AB_SparksCosmeticPreviewDisplay_C : ABP_SparksCosmeticPreviewDisplay_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x470(0x08)
	struct USkeletalMeshComponent* MicMesh; // 0x478(0x08)
	struct USkeletalMeshComponent* LHDrumstick; // 0x480(0x08)
	struct USkeletalMeshComponent* RHDrumstick; // 0x488(0x08)
	struct USkeletalMeshComponent* MicStandMesh; // 0x490(0x08)
	struct USkeletalMeshComponent* DrumMesh; // 0x498(0x08)
	struct USkeletalMeshComponent* GuitarMesh; // 0x4a0(0x08)
	bool Is  active; // 0x4a8(0x01)
	char pad_4A9[0x7]; // 0x4a9(0x07)
	struct FMulticastInlineDelegate NewEventDispatcher; // 0x4b0(0x10)

	void FixupMeshAndMaterials(struct USkeletalMeshComponent* MeshComponent, struct USkeletalMesh* NewMesh, struct UMaterialInstance* Material1, struct UMaterialInstance* Material2, struct UFXSystemAsset* FX); // Function B_SparksCosmeticPreviewDisplay.B_SparksCosmeticPreviewDisplay_C.FixupMeshAndMaterials // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Hide all(); // Function B_SparksCosmeticPreviewDisplay.B_SparksCosmeticPreviewDisplay_C.Hide all // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void CustomizePreviewInstance(struct UFortItemDefinition* InItemDefinition); // Function B_SparksCosmeticPreviewDisplay.B_SparksCosmeticPreviewDisplay_C.CustomizePreviewInstance // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_B_SparksCosmeticPreviewDisplay(int32_t EntryPoint); // Function B_SparksCosmeticPreviewDisplay.B_SparksCosmeticPreviewDisplay_C.ExecuteUbergraph_B_SparksCosmeticPreviewDisplay // (Final|UbergraphFunction|HasDefaults) // @ game+0x3d1d968
	void NewEventDispatcher__DelegateSignature(); // Function B_SparksCosmeticPreviewDisplay.B_SparksCosmeticPreviewDisplay_C.NewEventDispatcher__DelegateSignature // (Public|Delegate|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
};


// Class BattleRoyaleFrontend.BattleRoyaleFrontendExperienceFlow
// Size: 0x130 (Inherited: 0x28)
struct UBattleRoyaleFrontendExperienceFlow : UObject {
	char pad_28[0x20]; // 0x28(0x20)
	struct TArray<struct FString> DefaultFlowStepArray; // 0x48(0x10)
	struct TArray<struct FString> FirstTimeSeasonFlowStepArray; // 0x58(0x10)
	struct TMap<struct FString, struct FString> BRVideoRating; // 0x68(0x50)
	char pad_B8[0x8]; // 0xb8(0x08)
	struct TSoftClassPtr<UObject> VideoPlayerClass; // 0xc0(0x20)
	struct UFortStreamMediaSource* VideoStream_Source; // 0xe0(0x08)
	struct UHabaneroIntroModal* HabaneroIntroModalClass; // 0xe8(0x08)
	struct TSoftClassPtr<UObject> FireModeSelectionReminderModalClass; // 0xf0(0x20)
	struct TSoftClassPtr<UObject> FireModeSelectionScreenClass; // 0x110(0x20)
};


// Class AudioGameplay.AudioComponentGroupExtension
// Size: 0x28 (Inherited: 0x28)
struct UAudioComponentGroupExtension : UInterface {
};

// Class AudioGameplay.AudioGameplayCondition
// Size: 0x28 (Inherited: 0x28)
struct UAudioGameplayCondition : UInterface {

	bool ConditionMet_Position(struct FVector& Position); // Function AudioGameplay.AudioGameplayCondition.ConditionMet_Position // (RequiredAPI|Native|Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x103cf18
	bool ConditionMet(); // Function AudioGameplay.AudioGameplayCondition.ConditionMet // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x1377b44
};

// Class AudioGameplay.AudioGameplayVolumeInteraction
// Size: 0x28 (Inherited: 0x28)
struct UAudioGameplayVolumeInteraction : UInterface {

	void OnListenerExit(); // Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerExit // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x313fdf0
	void OnListenerEnter(); // Function AudioGameplay.AudioGameplayVolumeInteraction.OnListenerEnter // (RequiredAPI|Native|Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x2c0e95c
};

// Class AudioGameplay.SoundHandleSubsystem
// Size: 0xe0 (Inherited: 0x30)
struct USoundHandleSubsystem : UAudioEngineSubsystem {
	char pad_30[0xb0]; // 0x30(0xb0)
};

// Class AudioGameplay.AudioComponentGroup
// Size: 0x3d0 (Inherited: 0x220)
struct UAudioComponentGroup : USceneComponent {
	char pad_220[0x8]; // 0x220(0x08)
	struct FMulticastInlineDelegate OnStopped; // 0x228(0x10)
	struct FMulticastInlineDelegate OnKilled; // 0x238(0x10)
	struct FMulticastInlineDelegate OnVirtualized; // 0x248(0x10)
	struct FMulticastInlineDelegate OnUnvirtualized; // 0x258(0x10)
	struct TArray<struct UAudioComponent*> Components; // 0x268(0x10)
	struct TArray<struct FAudioParameter> ParamsToSet; // 0x278(0x10)
	struct TArray<struct FAudioParameter> PersistentParams; // 0x288(0x10)
	struct TArray<struct TScriptInterface<IAudioComponentGroupExtension>> Extensions; // 0x298(0x10)
	char pad_2A8[0x128]; // 0x2a8(0x128)

	void UnsubscribeObject(struct UObject* Object); // Function AudioGameplay.AudioComponentGroup.UnsubscribeObject // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e815b8
	void SubscribeToStringParam(struct FName ParamName, struct FDelegate Delegate); // Function AudioGameplay.AudioComponentGroup.SubscribeToStringParam // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e814e0
	void SubscribeToEvent(struct FName EventName, struct FDelegate Delegate); // Function AudioGameplay.AudioComponentGroup.SubscribeToEvent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e81408
	void SubscribeToBool(struct FName ParamName, struct FDelegate Delegate); // Function AudioGameplay.AudioComponentGroup.SubscribeToBool // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e81330
	void StopSound(struct USoundBase* sound, float FadeTime); // Function AudioGameplay.AudioComponentGroup.StopSound // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e8126c
	struct UAudioComponentGroup* StaticGetOrCreateComponentGroup(struct AActor* Actor); // Function AudioGameplay.AudioComponentGroup.StaticGetOrCreateComponentGroup // (Final|BlueprintCosmetic|Native|Static|Public|BlueprintCallable) // @ game+0x6e811ec
	void SetVolumeMultiplier(float InVolume); // Function AudioGameplay.AudioComponentGroup.SetVolumeMultiplier // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e8116c
	void SetPitchMultiplier(float InPitch); // Function AudioGameplay.AudioComponentGroup.SetPitchMultiplier // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e810ec
	void SetLowPassFilter(float InFrequency); // Function AudioGameplay.AudioComponentGroup.SetLowPassFilter // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e8106c
	void RemoveExternalComponent(struct UAudioComponent* ComponentToRemove); // Function AudioGameplay.AudioComponentGroup.RemoveExternalComponent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e80f5c
	void RemoveExtension(struct TScriptInterface<IAudioComponentGroupExtension> NewExtension); // Function AudioGameplay.AudioComponentGroup.RemoveExtension // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e80dfc
	bool IsVirtualized(); // Function AudioGameplay.AudioComponentGroup.IsVirtualized // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e80de4
	bool IsPlayingAny(); // Function AudioGameplay.AudioComponentGroup.IsPlayingAny // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e80dc8
	struct FString GetStringParamValue(struct FName ParamName); // Function AudioGameplay.AudioComponentGroup.GetStringParamValue // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e80d24
	float GetFloatParamValue(struct FName ParamName); // Function AudioGameplay.AudioComponentGroup.GetFloatParamValue // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e80c94
	bool GetBoolParamValue(struct FName ParamName); // Function AudioGameplay.AudioComponentGroup.GetBoolParamValue // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x6e80c08
	void EnableVirtualization(); // Function AudioGameplay.AudioComponentGroup.EnableVirtualization // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e80bf4
	void DisableVirtualization(); // Function AudioGameplay.AudioComponentGroup.DisableVirtualization // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e80be0
	void BroadcastStopAll(); // Function AudioGameplay.AudioComponentGroup.BroadcastStopAll // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e80bc4
	void BroadcastKill(); // Function AudioGameplay.AudioComponentGroup.BroadcastKill // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e80ba8
	void BroadcastEvent(struct FName EventName); // Function AudioGameplay.AudioComponentGroup.BroadcastEvent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e80b28
	void AddExternalComponent(struct UAudioComponent* ComponentToAdd); // Function AudioGameplay.AudioComponentGroup.AddExternalComponent // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e80960
	void AddExtension(struct TScriptInterface<IAudioComponentGroupExtension> NewExtension); // Function AudioGameplay.AudioComponentGroup.AddExtension // (Final|BlueprintCosmetic|Native|Public|BlueprintCallable) // @ game+0x6e8080c
};

// Class AudioGameplay.AudioGameplayComponent
// Size: 0xa8 (Inherited: 0xa0)
struct UAudioGameplayComponent : UActorComponent {
	char pad_A0[0x8]; // 0xa0(0x08)
};

// Class AudioGameplay.AudioRequirementPreset
// Size: 0x78 (Inherited: 0x30)
struct UAudioRequirementPreset : UDataAsset {
	struct FGameplayTagQuery Query; // 0x30(0x48)
};

// Class AudioGameplay.AudioParameterComponent
// Size: 0xd8 (Inherited: 0xa8)
struct UAudioParameterComponent : UAudioGameplayComponent {
	char pad_A8[0x10]; // 0xa8(0x10)
	struct TArray<struct TWeakObjectPtr<struct UAudioComponent>> ActiveComponents; // 0xb8(0x10)
	struct TArray<struct FAudioParameter> Parameters; // 0xc8(0x10)

	struct TArray<struct FAudioParameter> GetParameters(); // Function AudioGameplay.AudioParameterComponent.GetParameters // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x2e56884
};


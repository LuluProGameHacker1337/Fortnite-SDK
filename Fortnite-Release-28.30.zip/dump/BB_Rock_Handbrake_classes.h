// BlueprintGeneratedClass BB_Rock_Handbrake.BB_Rock_Handbrake_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_Rock_Handbrake_C : UFortMobileActionButtonBehavior {
};


// BlueprintGeneratedClass CameraShake_Riding_JumpOnCreature.CameraShake_Riding_JumpOnCreature_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_Riding_JumpOnCreature_C : ULegacyCameraShake {
};


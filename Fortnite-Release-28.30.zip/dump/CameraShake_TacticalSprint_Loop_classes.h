// BlueprintGeneratedClass CameraShake_TacticalSprint_Loop.CameraShake_TacticalSprint_Loop_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_TacticalSprint_Loop_C : ULegacyCameraShake {
};


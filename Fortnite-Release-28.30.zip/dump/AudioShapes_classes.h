// Class AudioShapes.AudioShapeComponent
// Size: 0x140 (Inherited: 0xa8)
struct UAudioShapeComponent : UAudioGameplayComponent {
	char pad_A8[0x8]; // 0xa8(0x08)
	float MaxDistanceOffset; // 0xb0(0x04)
	float SmoothingDistance; // 0xb4(0x04)
	float FadeInTime; // 0xb8(0x04)
	float FadeOutTime; // 0xbc(0x04)
	struct FMulticastInlineDelegate OnAudibleStateChanged; // 0xc0(0x10)
	struct TMap<struct FName, struct UAudioComponent*> AudioComponents; // 0xd0(0x50)
	struct TArray<struct APlayerController*> LocalControllers; // 0x120(0x10)
	char pad_130[0x10]; // 0x130(0x10)

	void UpdateAudioShape(struct TArray<struct APlayerController*>& InLocalControllers); // Function AudioShapes.AudioShapeComponent.UpdateAudioShape // (Final|Native|Public|HasOutParms) // @ game+0x7a9d9f0
	void Enable(); // Function AudioShapes.AudioShapeComponent.Enable // (Native|Protected|BlueprintCallable) // @ game+0x2e6c604
	void Disable(); // Function AudioShapes.AudioShapeComponent.Disable // (Native|Protected|BlueprintCallable) // @ game+0x6db0d14
};

// Class AudioShapes.AudioShapePrimitiveComponent
// Size: 0x200 (Inherited: 0x140)
struct UAudioShapePrimitiveComponent : UAudioShapeComponent {
	struct USoundBase* SoundOnEdge; // 0x140(0x08)
	struct USoundBase* SoundOnInside; // 0x148(0x08)
	struct FMulticastInlineDelegate OnInsideStateChanged; // 0x150(0x10)
	bool bUseOwningActorTransform; // 0x160(0x01)
	bool bAutoRefreshShape; // 0x161(0x01)
	char pad_162[0x6]; // 0x162(0x06)
	struct FVector ActorTransformScale; // 0x168(0x18)
	char pad_180[0x80]; // 0x180(0x80)

	bool GetIsPlayerInside(); // Function AudioShapes.AudioShapePrimitiveComponent.GetIsPlayerInside // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a9d498
	struct UAudioComponent* GetInsideAudioComponent(); // Function AudioShapes.AudioShapePrimitiveComponent.GetInsideAudioComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7a9d444
	struct UAudioComponent* GetEdgeAudioComponent(); // Function AudioShapes.AudioShapePrimitiveComponent.GetEdgeAudioComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x7a9d3f0
};

// Class AudioShapes.AudioShapeBoxComponent
// Size: 0x260 (Inherited: 0x200)
struct UAudioShapeBoxComponent : UAudioShapePrimitiveComponent {
	struct FTransform BoxTransform; // 0x200(0x60)

	void SetBoxTransform(struct FTransform& InTransform); // Function AudioShapes.AudioShapeBoxComponent.SetBoxTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x7a9d5f8
};

// Class AudioShapes.AudioShapeCylinderComponent
// Size: 0x200 (Inherited: 0x200)
struct UAudioShapeCylinderComponent : UAudioShapePrimitiveComponent {
	float HalfHeight; // 0x1f8(0x04)
	float Radius; // 0x1fc(0x04)

	void SetRadius(float InRadius); // Function AudioShapes.AudioShapeCylinderComponent.SetRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x7a9d890
	void SetHalfHeight(float InHalfHeight); // Function AudioShapes.AudioShapeCylinderComponent.SetHalfHeight // (Final|Native|Public|BlueprintCallable) // @ game+0x7a9d804
};

// Class AudioShapes.AudioShapeLineComponent
// Size: 0x230 (Inherited: 0x200)
struct UAudioShapeLineComponent : UAudioShapePrimitiveComponent {
	struct FVector StartPoint; // 0x1f8(0x18)
	struct FVector EndPoint; // 0x210(0x18)

	void SetStartPoint(struct FVector& InStartPoint); // Function AudioShapes.AudioShapeLineComponent.SetStartPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x7a9d91c
	void SetEndPoint(struct FVector& InEndPoint); // Function AudioShapes.AudioShapeLineComponent.SetEndPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x7a9d730
};

// Class AudioShapes.AudioShapeLineListComponent
// Size: 0x210 (Inherited: 0x200)
struct UAudioShapeLineListComponent : UAudioShapePrimitiveComponent {
	struct TArray<struct FVector> PointList; // 0x1f8(0x10)
	bool bClosedLoop; // 0x208(0x01)

	bool UpdatePoint(int32_t InIndex, struct FVector& InPoint); // Function AudioShapes.AudioShapeLineListComponent.UpdatePoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x7a9da8c
	bool RemovePoint(int32_t InIndex); // Function AudioShapes.AudioShapeLineListComponent.RemovePoint // (Final|Native|Public|BlueprintCallable) // @ game+0x7a9d554
	void GetPoints(struct TArray<struct FVector>& OutPoints); // Function AudioShapes.AudioShapeLineListComponent.GetPoints // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a9d4b4
	int32_t AddPoint(struct FVector& InPoint); // Function AudioShapes.AudioShapeLineListComponent.AddPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x7a9d2e0
};

// Class AudioShapes.AudioShapeSphereComponent
// Size: 0x200 (Inherited: 0x200)
struct UAudioShapeSphereComponent : UAudioShapePrimitiveComponent {
	float Radius; // 0x1f8(0x04)

	void SetRadius(float InRadius); // Function AudioShapes.AudioShapeSphereComponent.SetRadius // (Final|Native|Public|BlueprintCallable) // @ game+0x7a9d804
};

// Class AudioShapes.AudioShapeSubsystem
// Size: 0x88 (Inherited: 0x30)
struct UAudioShapeSubsystem : UWorldSubsystem {
	char pad_30[0x28]; // 0x30(0x28)
	struct TArray<struct UAudioShapeComponent*> AudioShapes; // 0x58(0x10)
	struct TArray<struct APlayerController*> LocalControllers; // 0x68(0x10)
	char pad_78[0x10]; // 0x78(0x10)
};


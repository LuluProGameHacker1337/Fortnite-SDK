// Class Buoyancy.BuoyancyEventInterface
// Size: 0x28 (Inherited: 0x28)
struct UBuoyancyEventInterface : UInterface {

	void OnSurfaceTouching(struct AWaterBody* WaterBodyActor, struct UPrimitiveComponent* WaterComponent, struct UPrimitiveComponent* SubmergedComponent, float SubmergedVolume, struct FVector& SubmergedCenterOfMass, struct FVector& SubmergedVelocity); // Function Buoyancy.BuoyancyEventInterface.OnSurfaceTouching // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x3d1d968
	void OnSurfaceTouchEnd(struct AWaterBody* WaterBodyActor, struct UPrimitiveComponent* WaterComponent, struct UPrimitiveComponent* SubmergedComponent, float SubmergedVolume, struct FVector& SubmergedCenterOfMass, struct FVector& SubmergedVelocity); // Function Buoyancy.BuoyancyEventInterface.OnSurfaceTouchEnd // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x3d1d968
	void OnSurfaceTouchBegin(struct AWaterBody* WaterBodyActor, struct UPrimitiveComponent* WaterComponent, struct UPrimitiveComponent* SubmergedComponent, float SubmergedVolume, struct FVector& SubmergedCenterOfMass, struct FVector& SubmergedVelocity); // Function Buoyancy.BuoyancyEventInterface.OnSurfaceTouchBegin // (Event|Public|HasOutParms|HasDefaults|BlueprintEvent) // @ game+0x3d1d968
};

// Class Buoyancy.BuoyancyRuntimeSettings
// Size: 0x60 (Inherited: 0x30)
struct UBuoyancyRuntimeSettings : UDeveloperSettings {
	bool bBuoyancyEnabled; // 0x30(0x01)
	bool bKeepFloatingObjectsAwake; // 0x31(0x01)
	char pad_32[0x2]; // 0x32(0x02)
	float WaterDensity; // 0x34(0x04)
	float WaterDrag; // 0x38(0x04)
	enum class ECollisionChannel CollisionChannelForWaterObjects; // 0x3c(0x01)
	char pad_3D[0x3]; // 0x3d(0x03)
	int32_t MaxNumBoundsSubdivisions; // 0x40(0x04)
	float MinBoundsSubdivisionVol; // 0x44(0x04)
	char SurfaceTouchCallbackFlags; // 0x48(0x01)
	char pad_49[0x3]; // 0x49(0x03)
	float MinVelocityForSurfaceTouchCallback; // 0x4c(0x04)
	bool bEnableSplineKeyCacheGrid; // 0x50(0x01)
	char pad_51[0x3]; // 0x51(0x03)
	float SplineKeyCacheGridSize; // 0x54(0x04)
	uint32_t SplineKeyCacheLimit; // 0x58(0x04)
	char pad_5C[0x4]; // 0x5c(0x04)
};

// Class Buoyancy.BuoyancySubsystem
// Size: 0x90 (Inherited: 0x40)
struct UBuoyancySubsystem : UTickableWorldSubsystem {
	char pad_40[0x50]; // 0x40(0x50)

	bool IsEnabled(); // Function Buoyancy.BuoyancySubsystem.IsEnabled // (Final|Native|Public|Const) // @ game+0x7d25dec
};


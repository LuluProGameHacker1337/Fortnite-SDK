// Class AttachableWheelsRuntime.AttachableWheel
// Size: 0x328 (Inherited: 0x290)
struct AAttachableWheel : AActor {
	struct UStaticMeshComponent* WheelMeshComponent; // 0x290(0x08)
	struct FRotator WheelOrientation; // 0x298(0x18)
	float WheelDistance; // 0x2b0(0x04)
	float AxleDamping; // 0x2b4(0x04)
	struct UPhysicsConstraintComponent* AxleConstraint; // 0x2b8(0x08)
	struct FAttachableWheelAttachData AttachData; // 0x2c0(0x58)
	bool bAutoCreateAttachableWheelsComponent; // 0x318(0x01)
	bool bEnableWheelWheelCollision; // 0x319(0x01)
	char pad_31A[0x6]; // 0x31a(0x06)
	struct AActor* ActorRef; // 0x320(0x08)

	void SetAxleDamping(float InWheelDamping); // Function AttachableWheelsRuntime.AttachableWheel.SetAxleDamping // (Final|Native|Protected|BlueprintCallable) // @ game+0xb7def28
	void SetActorRef(struct AActor* NewActorRef); // Function AttachableWheelsRuntime.AttachableWheel.SetActorRef // (Native|Public|BlueprintCallable) // @ game+0x8473bd4
	void OnRep_AttachData(struct FAttachableWheelAttachData& AttachDataPrev); // Function AttachableWheelsRuntime.AttachableWheel.OnRep_AttachData // (Final|Native|Protected|HasOutParms) // @ game+0xb7dee70
	void OnPhysicsStateChanged(struct UPrimitiveComponent* PrimitiveComponent, enum class EComponentPhysicsStateChange StateChange); // Function AttachableWheelsRuntime.AttachableWheel.OnPhysicsStateChanged // (Final|Native|Protected) // @ game+0xb7dedac
	void OnDetached(struct UPrimitiveComponent* DetachedComponent); // Function AttachableWheelsRuntime.AttachableWheel.OnDetached // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void OnAttached(struct UPrimitiveComponent* AttachedComponent); // Function AttachableWheelsRuntime.AttachableWheel.OnAttached // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	bool GetWorldSpaceAttachData(struct FAttachableWheelAttachData& OutAttachData, struct UPrimitiveComponent* PrimitiveComponent, struct FName BodyName); // Function AttachableWheelsRuntime.AttachableWheel.GetWorldSpaceAttachData // (Final|Native|Public|HasOutParms|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7de9f8
	struct UPrimitiveComponent* GetAttachedComponent(); // Function AttachableWheelsRuntime.AttachableWheel.GetAttachedComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7de734
	struct FAttachableWheelAttachData GetAttachData(); // Function AttachableWheelsRuntime.AttachableWheel.GetAttachData // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7de6dc
	struct AActor* GetActorRef(); // Function AttachableWheelsRuntime.AttachableWheel.GetActorRef // (Final|Native|Public|BlueprintCallable) // @ game+0x85a8d24
	void DrawDebug(); // Function AttachableWheelsRuntime.AttachableWheel.DrawDebug // (Final|Native|Public|BlueprintCallable|Const) // @ game+0x3097b14
	bool DetachFrom(struct UPrimitiveComponent* InComponent); // Function AttachableWheelsRuntime.AttachableWheel.DetachFrom // (Final|Native|Public|BlueprintCallable) // @ game+0xb7de634
	void Detach(); // Function AttachableWheelsRuntime.AttachableWheel.Detach // (Final|Native|Public|BlueprintCallable) // @ game+0xb7de5a0
	bool AttachTo(struct UPrimitiveComponent* InComponent, struct FVector& WorldLocation, struct FVector& AxleDirection); // Function AttachableWheelsRuntime.AttachableWheel.AttachTo // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xb7de400
	bool AttachInPlace(struct UPrimitiveComponent* InComponent); // Function AttachableWheelsRuntime.AttachableWheel.AttachInPlace // (Final|Native|Public|BlueprintCallable) // @ game+0xb7de370
};

// Class AttachableWheelsRuntime.AttachableWheelsComponent
// Size: 0xf0 (Inherited: 0xa0)
struct UAttachableWheelsComponent : UActorComponent {
	struct TSet<struct AAttachableWheel*> AttachedWheels; // 0xa0(0x50)

	void OnWheelDetached(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelDetached // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void OnWheelAttached(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.OnWheelAttached // (RequiredAPI|Event|Public|BlueprintEvent) // @ game+0x3d1d968
	bool HandleWheelDetached_Internal(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelDetached_Internal // (Final|Native|Protected) // @ game+0xb7ded1c
	bool HandleWheelAttached_Internal(struct AAttachableWheel* AttachedWheel); // Function AttachableWheelsRuntime.AttachableWheelsComponent.HandleWheelAttached_Internal // (Final|Native|Protected) // @ game+0xb7dec8c
	struct TArray<struct AAttachableWheel*> GetAttachedWheels(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheels // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7de98c
	struct AAttachableWheel* GetAttachedWheelClosestOnAxis(struct FVector& Point, float& OutClosetDistanceToAxis, struct FVector& OutClosestPointOnAxis, struct FVector& OutClosestAxis); // Function AttachableWheelsRuntime.AttachableWheelsComponent.GetAttachedWheelClosestOnAxis // (Final|RequiredAPI|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xb7de758
	void DrawDebug(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.DrawDebug // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x3097b14
	int32_t DetachAllWheels(); // Function AttachableWheelsRuntime.AttachableWheelsComponent.DetachAllWheels // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0xb7de5b4
};


// BlueprintGeneratedClass BBE_UseValetMods.BBE_UseValetMods_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_UseValetMods_C : UFortMobileActionButtonBehaviorExtension {
};


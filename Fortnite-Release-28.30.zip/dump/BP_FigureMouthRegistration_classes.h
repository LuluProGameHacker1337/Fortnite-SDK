// BlueprintGeneratedClass BP_FigureMouthRegistration.BP_FigureMouthRegistration_C
// Size: 0x80 (Inherited: 0x30)
struct UBP_FigureMouthRegistration_C : UPrimaryDataAsset {
	struct TArray<struct FTransform> MouthRegistration01; // 0x30(0x10)
	struct TArray<struct FTransform> MouthRegistration02; // 0x40(0x10)
	struct TArray<struct FTransform> MouthRegistration03; // 0x50(0x10)
	struct TArray<struct FTransform> MouthRegistration04; // 0x60(0x10)
	struct TArray<struct FTransform> MouthRegistration05; // 0x70(0x10)
};


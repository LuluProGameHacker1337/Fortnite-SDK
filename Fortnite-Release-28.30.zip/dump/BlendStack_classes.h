// Class BlendStack.BlendStackAnimNodeLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBlendStackAnimNodeLibrary : UBlueprintFunctionLibrary {

	void ForceBlendNextUpdate(struct FBlendStackAnimNodeReference& BlendStackNode); // Function BlendStack.BlendStackAnimNodeLibrary.ForceBlendNextUpdate // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x7a614cc
	void ConvertToBlendStackNodePure(struct FAnimNodeReference& Node, struct FBlendStackAnimNodeReference& BlendStackNode, bool& Result); // Function BlendStack.BlendStackAnimNodeLibrary.ConvertToBlendStackNodePure // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7a61354
	struct FBlendStackAnimNodeReference ConvertToBlendStackNode(struct FAnimNodeReference& Node, enum class EAnimNodeReferenceConversionResult& Result); // Function BlendStack.BlendStackAnimNodeLibrary.ConvertToBlendStackNode // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x7a61228
	void BlendTo(struct FAnimUpdateContext& Context, struct FBlendStackAnimNodeReference& BlendStackNode, struct UAnimationAsset* AnimationAsset, float AnimationTime, bool bLoop, bool bMirrored, float BlendTime, struct FVector BlendParameters, float WantedPlayRate); // Function BlendStack.BlendStackAnimNodeLibrary.BlendTo // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0x7a609f8
};


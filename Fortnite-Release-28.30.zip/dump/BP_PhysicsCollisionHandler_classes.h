// BlueprintGeneratedClass BP_PhysicsCollisionHandler.BP_PhysicsCollisionHandler_C
// Size: 0xf8 (Inherited: 0xf8)
struct UBP_PhysicsCollisionHandler_C : UFortPhysicsCollisionHandler {
};


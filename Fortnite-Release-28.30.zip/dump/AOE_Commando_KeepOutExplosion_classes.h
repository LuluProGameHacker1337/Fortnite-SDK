// BlueprintGeneratedClass AOE_Commando_KeepOutExplosion.AOE_Commando_KeepOutExplosion_C
// Size: 0xad8 (Inherited: 0x6d8)
struct AAOE_Commando_KeepOutExplosion_C : AFortAreaOfEffectCloud {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x6d8(0x08)
	struct UAudioComponent* AOE_Audio_Effect; // 0x6e0(0x08)
	struct UParticleSystemComponent* P_Grenade_Linger; // 0x6e8(0x08)
	struct USphereComponent* DamageArea; // 0x6f0(0x08)
	struct USceneComponent* DefaultSceneRoot; // 0x6f8(0x08)
	double Radius; // 0x700(0x08)
	struct FSoundAttenuationSettings AOE_Sound_Attenuation_Based_On_Radius; // 0x708(0x3d0)

	void OnRep_Radius(); // Function AOE_Commando_KeepOutExplosion.AOE_Commando_KeepOutExplosion_C.OnRep_Radius // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Send_Info(double Radius); // Function AOE_Commando_KeepOutExplosion.AOE_Commando_KeepOutExplosion_C.Send_Info // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveDestroyed(); // Function AOE_Commando_KeepOutExplosion.AOE_Commando_KeepOutExplosion_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveBeginPlay(); // Function AOE_Commando_KeepOutExplosion.AOE_Commando_KeepOutExplosion_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_AOE_Commando_KeepOutExplosion(int32_t EntryPoint); // Function AOE_Commando_KeepOutExplosion.AOE_Commando_KeepOutExplosion_C.ExecuteUbergraph_AOE_Commando_KeepOutExplosion // (Final|UbergraphFunction) // @ game+0x3d1d968
};


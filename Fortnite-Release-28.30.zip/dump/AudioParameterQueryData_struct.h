// UserDefinedStruct AudioParameterQueryData.AudioParameterQueryData
// Size: 0x68 (Inherited: 0x00)
struct FAudioParameterQueryData {
	struct FGameplayTagQuery TagQuery_12_74B441D54446A49EB7F00AAC728B68F0; // 0x00(0x48)
	struct FName ParameterName_2_0E82F2EF4DD09C9EB9E25D9AD7DB520D; // 0x48(0x04)
	char pad_4C[0x4]; // 0x4c(0x04)
	struct USoundControlBus* ControlBus_5_0B33E9404596DE8D58698EA40F70C171; // 0x50(0x08)
	struct FVector2D ControlBusFadeTime_9_E9701E2E4995E4A3C8798FA35536B86E; // 0x58(0x10)
};


// BlueprintGeneratedClass Announce_Storm2018Cine.Announce_Storm2018Cine_C
// Size: 0x338 (Inherited: 0x338)
struct AAnnounce_Storm2018Cine_C : AAnnounce_EventCine_C {
};


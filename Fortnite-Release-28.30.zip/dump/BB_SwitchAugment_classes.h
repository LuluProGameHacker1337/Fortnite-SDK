// BlueprintGeneratedClass BB_SwitchAugment.BB_SwitchAugment_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_SwitchAugment_C : UFortMobileActionButtonBehavior {
};


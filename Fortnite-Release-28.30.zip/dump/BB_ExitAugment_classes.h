// BlueprintGeneratedClass BB_ExitAugment.BB_ExitAugment_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_ExitAugment_C : UFortMobileActionButtonBehavior {
};


// Enum BeatSyncedAnimRuntime.ESyncAnimBeatTo
enum class ESyncAnimBeatTo : uint8 {
	None = 0,
	Now = 1,
	PrevBeat = 2,
	Num = 3,
	ESyncAnimBeatTo_MAX = 4
};

// Enum BeatSyncedAnimRuntime.EBeatSyncAnimNodeLogging
enum class EBeatSyncAnimNodeLogging : uint8 {
	Enabled = 0,
	Disabled = 1,
	Default = 2,
	EBeatSyncAnimNodeLogging_MAX = 3
};

// Enum BeatSyncedAnimRuntime.EGotBeatAndTimeFrom
enum class EGotBeatAndTimeFrom : uint8 {
	Invalid = 0,
	None = 1,
	PreviewBPM = 2,
	MusicClock = 3,
	EGotBeatAndTimeFrom_MAX = 4
};

// ScriptStruct BeatSyncedAnimRuntime.AnimNode_PlayBeatSyncedAnim
// Size: 0xa8 (Inherited: 0x40)
struct FAnimNode_PlayBeatSyncedAnim : FAnimNode_SequenceEvaluator {
	struct UAnimSequenceBase* InSequence; // 0x40(0x08)
	struct UMusicClockComponent* MusicClock; // 0x48(0x08)
	struct FBeatAndTime BeatAndTime; // 0x50(0x0c)
	float PreviewBPM; // 0x5c(0x04)
	bool bAlwaysAllowPreviewBPM; // 0x60(0x01)
	enum class ESyncAnimBeatTo SyncAnimBeatTo; // 0x61(0x01)
	enum class EBeatSyncAnimNodeLogging Logging; // 0x62(0x01)
	bool bSideloadedLipSync; // 0x63(0x01)
	char pad_64[0x44]; // 0x64(0x44)
};

// ScriptStruct BeatSyncedAnimRuntime.BeatAndTime
// Size: 0x0c (Inherited: 0x00)
struct FBeatAndTime {
	enum class EGotBeatAndTimeFrom GotBeatTimeFrom; // 0x00(0x01)
	char pad_1[0x3]; // 0x01(0x03)
	float Beat; // 0x04(0x04)
	float Time; // 0x08(0x04)
};

// ScriptStruct BeatSyncedAnimRuntime.FMontageBeatSyncInfo
// Size: 0x08 (Inherited: 0x00)
struct FFMontageBeatSyncInfo {
	float PlayRate; // 0x00(0x04)
	float Offset; // 0x04(0x04)
};


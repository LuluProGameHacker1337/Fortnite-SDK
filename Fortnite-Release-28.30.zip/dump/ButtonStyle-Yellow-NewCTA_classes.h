// BlueprintGeneratedClass ButtonStyle-Yellow-NewCTA.ButtonStyle-Yellow-NewCTA_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-Yellow-NewCTA_C : UCommonButtonStyle {
};


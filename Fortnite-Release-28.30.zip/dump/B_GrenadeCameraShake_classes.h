// BlueprintGeneratedClass B_GrenadeCameraShake.B_GrenadeCameraShake_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UB_GrenadeCameraShake_C : ULegacyCameraShake {
};


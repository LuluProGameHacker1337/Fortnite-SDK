// BlueprintGeneratedClass BP_FigureBeardRegistration.BP_FigureBeardRegistration_C
// Size: 0x73 (Inherited: 0x30)
struct UBP_FigureBeardRegistration_C : UPrimaryDataAsset {
	struct TArray<int32_t> BeardPoses; // 0x30(0x10)
	struct TArray<int32_t> BeardBeanPoses; // 0x40(0x10)
	struct TArray<struct FTransform> BeardBean; // 0x50(0x10)
	struct TArray<struct FTransform> Beard; // 0x60(0x10)
	bool Transform Beard; // 0x70(0x01)
	bool Scale Bean; // 0x71(0x01)
	bool Transform Bean; // 0x72(0x01)
};


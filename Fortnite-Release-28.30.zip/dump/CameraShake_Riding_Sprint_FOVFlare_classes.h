// BlueprintGeneratedClass CameraShake_Riding_Sprint_FOVFlare.CameraShake_Riding_Sprint_FOVFlare_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_Riding_Sprint_FOVFlare_C : ULegacyCameraShake {
};


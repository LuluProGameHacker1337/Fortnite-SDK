// BlueprintGeneratedClass BBE_HideIfAugmentsOpen.BBE_HideIfAugmentsOpen_C
// Size: 0x90 (Inherited: 0x90)
struct UBBE_HideIfAugmentsOpen_C : UFortMobileActionBBE_AugmentShoot {
};


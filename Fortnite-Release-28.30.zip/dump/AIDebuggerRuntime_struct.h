// Enum AIDebuggerRuntime.EAIDebuggerVisualization
enum class EAIDebuggerVisualization : uint8 {
	INVALID = 0,
	NavMesh = 1,
	EAIDebuggerVisualization_MAX = 2
};


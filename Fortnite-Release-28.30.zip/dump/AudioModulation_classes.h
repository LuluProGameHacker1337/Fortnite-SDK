// Class AudioModulation.AudioModulationStyle
// Size: 0x28 (Inherited: 0x28)
struct UAudioModulationStyle : UBlueprintFunctionLibrary {

	struct FColor GetPatchColor(); // Function AudioModulation.AudioModulationStyle.GetPatchColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7c5c524
	struct FColor GetParameterColor(); // Function AudioModulation.AudioModulationStyle.GetParameterColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7c5c504
	struct FColor GetModulationGeneratorColor(); // Function AudioModulation.AudioModulationStyle.GetModulationGeneratorColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7c5c3e4
	struct FColor GetControlBusMixColor(); // Function AudioModulation.AudioModulationStyle.GetControlBusMixColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7c5c3c4
	struct FColor GetControlBusColor(); // Function AudioModulation.AudioModulationStyle.GetControlBusColor // (Final|Native|Static|Public|HasDefaults|BlueprintCallable) // @ game+0x7c5c3a4
};

// Class AudioModulation.AudioModulationSettings
// Size: 0x40 (Inherited: 0x30)
struct UAudioModulationSettings : UDeveloperSettings {
	struct TArray<struct FSoftObjectPath> Parameters; // 0x30(0x10)
};

// Class AudioModulation.AudioModulationStatics
// Size: 0x28 (Inherited: 0x28)
struct UAudioModulationStatics : UBlueprintFunctionLibrary {

	void UpdateModulator(struct UObject* WorldContextObject, struct USoundModulatorBase* Modulator); // Function AudioModulation.AudioModulationStatics.UpdateModulator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5e0c0
	void UpdateMixFromObject(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, float FadeTime); // Function AudioModulation.AudioModulationStatics.UpdateMixFromObject // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5dfa0
	void UpdateMixByFilter(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, struct FString AddressFilter, struct USoundModulationParameter* ParamClassFilter, struct USoundModulationParameter* ParamFilter, float Value, float FadeTime); // Function AudioModulation.AudioModulationStatics.UpdateMixByFilter // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5d730
	void UpdateMix(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, struct TArray<struct FSoundControlBusMixStage> Stages, float FadeTime); // Function AudioModulation.AudioModulationStatics.UpdateMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5cf5c
	void SetGlobalBusMixValue(struct UObject* WorldContextObject, struct USoundControlBus* Bus, float Value, float FadeTime); // Function AudioModulation.AudioModulationStatics.SetGlobalBusMixValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x37933e4
	void SaveMixToProfile(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, int32_t ProfileIndex); // Function AudioModulation.AudioModulationStatics.SaveMixToProfile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5cd80
	struct TArray<struct FSoundControlBusMixStage> LoadMixFromProfile(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix, bool bActivate, int32_t ProfileIndex); // Function AudioModulation.AudioModulationStatics.LoadMixFromProfile // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5c56c
	float GetModulatorValue(struct UObject* WorldContextObject, struct USoundModulatorBase* Modulator); // Function AudioModulation.AudioModulationStatics.GetModulatorValue // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x1c24cc8
	struct TSet<struct USoundModulatorBase*> GetModulatorsFromDestination(struct FSoundModulationDestinationSettings& Destination); // Function AudioModulation.AudioModulationStatics.GetModulatorsFromDestination // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x7c5c404
	void DeactivateGenerator(struct UObject* WorldContextObject, struct USoundModulationGenerator* Generator); // Function AudioModulation.AudioModulationStatics.DeactivateGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5c29c
	void DeactivateBusMix(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix); // Function AudioModulation.AudioModulationStatics.DeactivateBusMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5c1d0
	void DeactivateBus(struct UObject* WorldContextObject, struct USoundControlBus* Bus); // Function AudioModulation.AudioModulationStatics.DeactivateBus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5c104
	void DeactivateAllBusMixes(struct UObject* WorldContextObject); // Function AudioModulation.AudioModulationStatics.DeactivateAllBusMixes // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5c048
	struct USoundModulationWatcher* CreateModulationWatcher(struct UObject* WorldContextObject, struct FName Name, struct USoundModulatorBase* Modulator); // Function AudioModulation.AudioModulationStatics.CreateModulationWatcher // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5bf34
	struct USoundModulationParameter* CreateModulationParameter(struct UObject* WorldContextObject, struct FName Name, struct USoundModulationParameter* ParamClass, float DefaultValue); // Function AudioModulation.AudioModulationStatics.CreateModulationParameter // (Final|Native|Static|Public) // @ game+0x7c5bdd8
	struct USoundModulationGeneratorLFO* CreateLFOGenerator(struct UObject* WorldContextObject, struct FName Name, struct FSoundModulationLFOParams Params); // Function AudioModulation.AudioModulationStatics.CreateLFOGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5bc10
	struct USoundModulationGeneratorEnvelopeFollower* CreateEnvelopeFollowerGenerator(struct UObject* WorldContextObject, struct FName Name, struct FEnvelopeFollowerGeneratorParams Params); // Function AudioModulation.AudioModulationStatics.CreateEnvelopeFollowerGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5ba38
	struct FSoundControlBusMixStage CreateBusMixStage(struct UObject* WorldContextObject, struct USoundControlBus* Bus, float Value, float AttackTime, float ReleaseTime); // Function AudioModulation.AudioModulationStatics.CreateBusMixStage // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5b894
	struct USoundControlBusMix* CreateBusMix(struct UObject* WorldContextObject, struct FName Name, struct TArray<struct FSoundControlBusMixStage> Stages, bool Activate); // Function AudioModulation.AudioModulationStatics.CreateBusMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5b108
	struct USoundControlBus* CreateBus(struct UObject* WorldContextObject, struct FName Name, struct USoundModulationParameter* Parameter, bool Activate); // Function AudioModulation.AudioModulationStatics.CreateBus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5afd0
	struct USoundModulationGeneratorADEnvelope* CreateADEnvelopeGenerator(struct UObject* WorldContextObject, struct FName Name, struct FSoundModulationADEnvelopeParams& Params); // Function AudioModulation.AudioModulationStatics.CreateADEnvelopeGenerator // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x7c5aec0
	void ClearGlobalBusMixValue(struct UObject* WorldContextObject, struct USoundControlBus* Bus, float FadeTime); // Function AudioModulation.AudioModulationStatics.ClearGlobalBusMixValue // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5ad7c
	void ClearAllGlobalBusMixValues(struct UObject* WorldContextObject, float FadeTime); // Function AudioModulation.AudioModulationStatics.ClearAllGlobalBusMixValues // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5acc8
	void ActivateGenerator(struct UObject* WorldContextObject, struct USoundModulationGenerator* Generator); // Function AudioModulation.AudioModulationStatics.ActivateGenerator // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5abc0
	void ActivateBusMix(struct UObject* WorldContextObject, struct USoundControlBusMix* Mix); // Function AudioModulation.AudioModulationStatics.ActivateBusMix // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5aaf4
	void ActivateBus(struct UObject* WorldContextObject, struct USoundControlBus* Bus); // Function AudioModulation.AudioModulationStatics.ActivateBus // (Final|Native|Static|Public|BlueprintCallable) // @ game+0x7c5aa28
};

// Class AudioModulation.SoundModulationGenerator
// Size: 0x30 (Inherited: 0x30)
struct USoundModulationGenerator : USoundModulatorBase {
};

// Class AudioModulation.SoundModulationGeneratorADEnvelope
// Size: 0x48 (Inherited: 0x30)
struct USoundModulationGeneratorADEnvelope : USoundModulationGenerator {
	struct FSoundModulationADEnvelopeParams Params; // 0x30(0x14)
	char pad_44[0x4]; // 0x44(0x04)
};

// Class AudioModulation.SoundModulationGeneratorEnvelopeFollower
// Size: 0x50 (Inherited: 0x30)
struct USoundModulationGeneratorEnvelopeFollower : USoundModulationGenerator {
	struct FEnvelopeFollowerGeneratorParams Params; // 0x30(0x20)
};

// Class AudioModulation.SoundModulationGeneratorLFO
// Size: 0x50 (Inherited: 0x30)
struct USoundModulationGeneratorLFO : USoundModulationGenerator {
	struct FSoundModulationLFOParams Params; // 0x30(0x20)
};

// Class AudioModulation.SoundControlBus
// Size: 0x60 (Inherited: 0x30)
struct USoundControlBus : USoundModulatorBase {
	bool bBypass; // 0x30(0x01)
	char pad_31[0x7]; // 0x31(0x07)
	struct FString address; // 0x38(0x10)
	struct TArray<struct USoundModulationGenerator*> Generators; // 0x48(0x10)
	struct USoundModulationParameter* Parameter; // 0x58(0x08)
};

// Class AudioModulation.SoundControlBusMix
// Size: 0x40 (Inherited: 0x28)
struct USoundControlBusMix : UObject {
	uint32_t ProfileIndex; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FSoundControlBusMixStage> MixStages; // 0x30(0x10)

	void SoloMix(); // Function AudioModulation.SoundControlBusMix.SoloMix // (Final|Native|Protected) // @ game+0x7c5cf20
	void SaveMixToProfile(); // Function AudioModulation.SoundControlBusMix.SaveMixToProfile // (Final|Native|Protected) // @ game+0x7c5ce78
	void LoadMixFromProfile(); // Function AudioModulation.SoundControlBusMix.LoadMixFromProfile // (Final|Native|Protected) // @ game+0x7c5cd4c
	void DeactivateMix(); // Function AudioModulation.SoundControlBusMix.DeactivateMix // (Final|Native|Protected) // @ game+0x7c5c368
	void DeactivateAllMixes(); // Function AudioModulation.SoundControlBusMix.DeactivateAllMixes // (Final|Native|Protected) // @ game+0x7c5c0c8
	void ActivateMix(); // Function AudioModulation.SoundControlBusMix.ActivateMix // (Final|Native|Protected) // @ game+0x7c5acb4
};

// Class AudioModulation.SoundModulationParameter
// Size: 0x38 (Inherited: 0x28)
struct USoundModulationParameter : UObject {
	char pad_28[0x8]; // 0x28(0x08)
	struct FSoundModulationParameterSettings Settings; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class AudioModulation.SoundModulationParameterScaled
// Size: 0x40 (Inherited: 0x38)
struct USoundModulationParameterScaled : USoundModulationParameter {
	float UnitMin; // 0x38(0x04)
	float UnitMax; // 0x3c(0x04)
};

// Class AudioModulation.SoundModulationParameterFrequencyBase
// Size: 0x38 (Inherited: 0x38)
struct USoundModulationParameterFrequencyBase : USoundModulationParameter {
};

// Class AudioModulation.SoundModulationParameterFrequency
// Size: 0x40 (Inherited: 0x38)
struct USoundModulationParameterFrequency : USoundModulationParameterFrequencyBase {
	float UnitMin; // 0x38(0x04)
	float UnitMax; // 0x3c(0x04)
};

// Class AudioModulation.SoundModulationParameterFilterFrequency
// Size: 0x38 (Inherited: 0x38)
struct USoundModulationParameterFilterFrequency : USoundModulationParameterFrequencyBase {
};

// Class AudioModulation.SoundModulationParameterLPFFrequency
// Size: 0x38 (Inherited: 0x38)
struct USoundModulationParameterLPFFrequency : USoundModulationParameterFilterFrequency {
};

// Class AudioModulation.SoundModulationParameterHPFFrequency
// Size: 0x38 (Inherited: 0x38)
struct USoundModulationParameterHPFFrequency : USoundModulationParameterFilterFrequency {
};

// Class AudioModulation.SoundModulationParameterBipolar
// Size: 0x40 (Inherited: 0x38)
struct USoundModulationParameterBipolar : USoundModulationParameter {
	float UnitRange; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class AudioModulation.SoundModulationParameterVolume
// Size: 0x40 (Inherited: 0x38)
struct USoundModulationParameterVolume : USoundModulationParameter {
	float MinVolume; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
};

// Class AudioModulation.SoundModulationParameterAdditive
// Size: 0x40 (Inherited: 0x38)
struct USoundModulationParameterAdditive : USoundModulationParameter {
	float UnitMin; // 0x38(0x04)
	float UnitMax; // 0x3c(0x04)
};

// Class AudioModulation.SoundModulationPatch
// Size: 0x50 (Inherited: 0x30)
struct USoundModulationPatch : USoundModulatorBase {
	struct FSoundControlModulationPatch PatchSettings; // 0x30(0x20)
};

// Class AudioModulation.SoundModulationWatcher
// Size: 0x40 (Inherited: 0x28)
struct USoundModulationWatcher : UObject {
	struct USoundModulatorBase* Modulator; // 0x28(0x08)
	char pad_30[0x10]; // 0x30(0x10)

	bool SetModulator(struct USoundModulatorBase* InModulator); // Function AudioModulation.SoundModulationWatcher.SetModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x7c5ce90
	float GetValue(); // Function AudioModulation.SoundModulationWatcher.GetValue // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7c5c544
	struct USoundModulatorBase* GetModulator(); // Function AudioModulation.SoundModulationWatcher.GetModulator // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x7a78994
	bool ClearModulator(); // Function AudioModulation.SoundModulationWatcher.ClearModulator // (Final|Native|Public|BlueprintCallable) // @ game+0x7c5ae9c
};


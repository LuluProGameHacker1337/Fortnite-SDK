// BlueprintGeneratedClass ButtonStyle_UIKit_CTA.ButtonStyle_UIKit_CTA_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_UIKit_CTA_C : UButtonStyle-Base_C {
};


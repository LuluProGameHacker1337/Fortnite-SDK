// BlueprintGeneratedClass Athena_PlayerCameraMode_WaterSprintBoost.Athena_PlayerCameraMode_WaterSprintBoost_C
// Size: 0x1ba0 (Inherited: 0x1ba0)
struct UAthena_PlayerCameraMode_WaterSprintBoost_C : UAthena_PlayerCameraModeBase_C {
};


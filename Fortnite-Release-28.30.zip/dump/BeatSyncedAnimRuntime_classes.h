// Class BeatSyncedAnimRuntime.BeatSyncedAnimLibrary
// Size: 0x28 (Inherited: 0x28)
struct UBeatSyncedAnimLibrary : UBlueprintFunctionLibrary {

	struct UFortItemDefinition* GetLastEmoteExecuted(struct AController* Controller); // Function BeatSyncedAnimRuntime.BeatSyncedAnimLibrary.GetLastEmoteExecuted // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aa9a4
	float CalculateMontagePlayRate(struct UMusicClockComponent* MusicClock, struct UAnimMontage* Montage, float MontageBeatLength); // Function BeatSyncedAnimRuntime.BeatSyncedAnimLibrary.CalculateMontagePlayRate // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aa25c
	struct FFMontageBeatSyncInfo CalculateMontageBeatSyncInfo(struct UMusicClockComponent* MusicClock, struct UAnimMontage* Montage, float LengthInBeats, float MsOffset); // Function BeatSyncedAnimRuntime.BeatSyncedAnimLibrary.CalculateMontageBeatSyncInfo // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0a9eec
};

// Class BeatSyncedAnimRuntime.FMBeatTimingUtils
// Size: 0x28 (Inherited: 0x28)
struct UFMBeatTimingUtils : UBlueprintFunctionLibrary {

	float GetCurrentSongTime_Unsafe(struct UMusicClockComponent* InMusicClock, bool bRounded); // Function BeatSyncedAnimRuntime.FMBeatTimingUtils.GetCurrentSongTime_Unsafe // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aa8dc
	float GetCurrentSongTime(struct UMusicClockComponent* InMusicClock, bool bRounded); // Function BeatSyncedAnimRuntime.FMBeatTimingUtils.GetCurrentSongTime // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aa814
	float GetCurrentBeatForBPM(float InBPM, struct UObject* WorldContextObject); // Function BeatSyncedAnimRuntime.FMBeatTimingUtils.GetCurrentBeatForBPM // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aa644
	struct FBeatAndTime GetCurrentBeatAndTime(struct UMusicClockComponent* MusicClock, struct UObject* WorldContext, bool bAlwaysAllowPreviewBPM, float PreviewBPM, bool bForceUnsafe); // Function BeatSyncedAnimRuntime.FMBeatTimingUtils.GetCurrentBeatAndTime // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aa4ac
	float GetCurrentBeat_Unsafe(struct UMusicClockComponent* InMusicClock, bool bRounded); // Function BeatSyncedAnimRuntime.FMBeatTimingUtils.GetCurrentBeat_Unsafe // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aa70c
	float GetCurrentBeat(struct UMusicClockComponent* InMusicClock, bool bRounded); // Function BeatSyncedAnimRuntime.FMBeatTimingUtils.GetCurrentBeat // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aa3e4
	float GetBeatsPerMeasure(); // Function BeatSyncedAnimRuntime.FMBeatTimingUtils.GetBeatsPerMeasure // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aa3cc
};

// Class BeatSyncedAnimRuntime.MontageBeatSyncComponent
// Size: 0xf8 (Inherited: 0xa0)
struct UMontageBeatSyncComponent : UActorComponent {
	char pad_A0[0x4]; // 0xa0(0x04)
	float MaxPlayRateBeforeHalf; // 0xa4(0x04)
	float MinPlayRateBeforeDouble; // 0xa8(0x04)
	float DefaultToAnimationBPM; // 0xac(0x04)
	bool bForceBeatSyncAllMontages; // 0xb0(0x01)
	char pad_B1[0x3]; // 0xb1(0x03)
	float MontageLengthInBeats; // 0xb4(0x04)
	float MontageOffsetMs; // 0xb8(0x04)
	struct TWeakObjectPtr<struct UMusicClockComponent> WeakMusicClockPtr; // 0xbc(0x08)
	bool bIsMusicPlaying; // 0xc4(0x01)
	bool bHaveTimingInfo; // 0xc5(0x01)
	char pad_C6[0x2]; // 0xc6(0x02)
	int32_t LastKnownMontageInstanceId; // 0xc8(0x04)
	char pad_CC[0x4]; // 0xcc(0x04)
	struct AFortPlayerPawn* OwnerPlayerPawn; // 0xd0(0x08)
	struct USkeletalMeshComponent* OwnerMeshComponent; // 0xd8(0x08)
	struct TArray<struct TWeakObjectPtr<struct UMontageBeatSyncComponent>> YoungerSiblings; // 0xe0(0x10)
	struct UPreciseBeatSyncedAnimMetaData* ActiveTimingInfo; // 0xf0(0x08)

	void SetMusicClockReference(struct UMusicClockComponent* MusicClock); // Function BeatSyncedAnimRuntime.MontageBeatSyncComponent.SetMusicClockReference // (Final|Native|Public|BlueprintCallable) // @ game+0xb0aaa5c
	struct UPreciseBeatSyncedAnimMetaData* LookupMontageTimingInfo_BP(struct UAnimMontage* Montage, struct AFortPlayerPawn* PlayerPawn); // Function BeatSyncedAnimRuntime.MontageBeatSyncComponent.LookupMontageTimingInfo_BP // (Native|Event|Public|BlueprintEvent) // @ game+0x3a06fb8
	bool IsMusicPlaying(); // Function BeatSyncedAnimRuntime.MontageBeatSyncComponent.IsMusicPlaying // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xb0aaa44
	struct USkeletalMeshComponent* GetOwnerSkeletalMeshComponent(); // Function BeatSyncedAnimRuntime.MontageBeatSyncComponent.GetOwnerSkeletalMeshComponent // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x90083a4
	struct AFortPlayerPawn* GetOwnerFortPlayerPawn(); // Function BeatSyncedAnimRuntime.MontageBeatSyncComponent.GetOwnerFortPlayerPawn // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x9008888
	void EndedPlayingMusic(); // Function BeatSyncedAnimRuntime.MontageBeatSyncComponent.EndedPlayingMusic // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void BeganPlayingMusic(); // Function BeatSyncedAnimRuntime.MontageBeatSyncComponent.BeganPlayingMusic // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
};

// Class BeatSyncedAnimRuntime.SparksAnimLoggingComponent
// Size: 0xb8 (Inherited: 0xa0)
struct USparksAnimLoggingComponent : UActorComponent {
	char pad_A0[0x18]; // 0xa0(0x18)

	struct FString GetCurrentFullBodyAnimName(); // Function BeatSyncedAnimRuntime.SparksAnimLoggingComponent.GetCurrentFullBodyAnimName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xb0aa7d4
};

// Class BeatSyncedAnimRuntime.AnimNotify_BeatMarker
// Size: 0x38 (Inherited: 0x38)
struct UAnimNotify_BeatMarker : UAnimNotify {
};


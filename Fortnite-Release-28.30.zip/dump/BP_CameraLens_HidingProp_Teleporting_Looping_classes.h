// BlueprintGeneratedClass BP_CameraLens_HidingProp_Teleporting_Looping.BP_CameraLens_HidingProp_Teleporting_Looping_C
// Size: 0x380 (Inherited: 0x380)
struct ABP_CameraLens_HidingProp_Teleporting_Looping_C : AEmitterCameraLensEffectBase {
};


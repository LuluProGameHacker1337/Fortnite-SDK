// BlueprintGeneratedClass BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C
// Size: 0x12b (Inherited: 0xf0)
struct UBP_AudioParameterComponent_Pawn_C : UFortAudioParameterComponent_Pawn {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xf0(0x08)
	struct AActor* LocalViewTarget; // 0xf8(0x08)
	struct TArray<struct FAudioParameterQueryData> QueryAudioParams; // 0x100(0x10)
	bool bDebugEnabled; // 0x110(0x01)
	bool IsInWater; // 0x111(0x01)
	char pad_112[0x6]; // 0x112(0x06)
	struct AFortPlayerPawn* LocalPlayerPawnTarget; // 0x118(0x08)
	double WaterDepthValue; // 0x120(0x08)
	enum class PlayerWaterDepthEnum PlayerWaterDepth; // 0x128(0x01)
	enum class PlayerWaterDepthEnum CurrentWaterDepth; // 0x129(0x01)
	bool WaterDepthChanged; // 0x12a(0x01)

	void OnWaterDepthSwitch(); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.OnWaterDepthSwitch // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnWaterUpdate(); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.OnWaterUpdate // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Movement Mode Change(struct ACharacter* Character, enum class EMovementMode PrevMovementMode, char PreviousCustomMode); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.Movement Mode Change // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnExitWater(struct AFortPlayerPawn* FortPlayerPawn, bool bPawnIsOutsideOfAllWaterBodies); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.OnExitWater // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnEnterWater(struct AFortPlayerPawn* FortPlayerPawn); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.OnEnterWater // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	float GetWaterDepthValue(); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.GetWaterDepthValue // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3d1d968
	void PrintParameter(struct FAudioParameterQueryData& Parameter, bool Condition); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.PrintParameter // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveBeginPlay(); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void OnViewTargetSet(struct AActor* Actor); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.OnViewTargetSet // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_BP_AudioParameterComponent_Pawn(int32_t EntryPoint); // Function BP_AudioParameterComponent_Pawn.BP_AudioParameterComponent_Pawn_C.ExecuteUbergraph_BP_AudioParameterComponent_Pawn // (Final|UbergraphFunction) // @ game+0x3d1d968
};


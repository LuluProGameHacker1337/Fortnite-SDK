// BlueprintGeneratedClass Border_Solid_DkBlue.Border_Solid_DkBlue_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder_Solid_DkBlue_C : UCommonBorderStyle {
};


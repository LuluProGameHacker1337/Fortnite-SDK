// Enum BallisticShieldGameplayRuntime.EBallisticShieldPlayerActionState
enum class EBallisticShieldPlayerActionState : uint8 {
	Idling = 0,
	Blocking = 1,
	Charging = 2,
	EBallisticShieldPlayerActionState_MAX = 3
};


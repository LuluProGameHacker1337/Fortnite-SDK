// BlueprintGeneratedClass B_CreatureSoundLibraryContext.B_CreatureSoundLibraryContext_C
// Size: 0xb0 (Inherited: 0xb0)
struct UB_CreatureSoundLibraryContext_C : USoundLibrarySimpleContext {

	bool Play(struct FSoundLibraryContextEventInput& InEventData, struct TArray<struct UAudioComponent*>& OutComponents); // Function B_CreatureSoundLibraryContext.B_CreatureSoundLibraryContext_C.Play // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
};


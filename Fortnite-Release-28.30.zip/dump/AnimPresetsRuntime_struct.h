// ScriptStruct AnimPresetsRuntime.AnimPresetRetargetData
// Size: 0x40 (Inherited: 0x00)
struct FAnimPresetRetargetData {
	struct TSoftObjectPtr<UIKRetargeter> IKRetargeter; // 0x00(0x20)
	struct TSoftObjectPtr<USkeletalMesh> SourceSkeletalMesh; // 0x20(0x20)
};

// ScriptStruct AnimPresetsRuntime.AnimPreset_SingleAnimationData
// Size: 0x10 (Inherited: 0x00)
struct FAnimPreset_SingleAnimationData {
	struct UAnimSequence* Animation; // 0x00(0x08)
	float PlayRate; // 0x08(0x04)
	char pad_C[0x4]; // 0x0c(0x04)
};


// BlueprintGeneratedClass ButtonStyle_HoldPurchase_Yellow.ButtonStyle_HoldPurchase_Yellow_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_HoldPurchase_Yellow_C : UCommonButtonStyle {
};


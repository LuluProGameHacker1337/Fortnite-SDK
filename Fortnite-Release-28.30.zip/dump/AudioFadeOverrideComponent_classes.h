// BlueprintGeneratedClass AudioFadeOverrideComponent.AudioFadeOverrideComponent_C
// Size: 0xb0 (Inherited: 0xa0)
struct UAudioFadeOverrideComponent_C : UFortGameStateComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xa0(0x08)
	struct APlayerCameraManager* CameraManagerRef; // 0xa8(0x08)

	void ReceiveBeginPlay(); // Function AudioFadeOverrideComponent.AudioFadeOverrideComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void On Audio Fade Change Event(bool bFadeOut, float FadeTime); // Function AudioFadeOverrideComponent.AudioFadeOverrideComponent_C.On Audio Fade Change Event // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveEndPlay(enum class EEndPlayReason EndPlayReason); // Function AudioFadeOverrideComponent.AudioFadeOverrideComponent_C.ReceiveEndPlay // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_AudioFadeOverrideComponent(int32_t EntryPoint); // Function AudioFadeOverrideComponent.AudioFadeOverrideComponent_C.ExecuteUbergraph_AudioFadeOverrideComponent // (Final|UbergraphFunction) // @ game+0x3d1d968
};


// Enum Buoyancy.EBuoyancyEventFlags
enum class EBuoyancyEventFlags : uint8 {
	None = 0,
	Begin = 1,
	Continue = 2,
	End = 4,
	EBuoyancyEventFlags_MAX = 5
};


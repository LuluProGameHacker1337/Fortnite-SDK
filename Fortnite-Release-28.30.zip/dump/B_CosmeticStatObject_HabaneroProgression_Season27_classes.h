// BlueprintGeneratedClass B_CosmeticStatObject_HabaneroProgression_Season27.B_CosmeticStatObject_HabaneroProgression_Season27_C
// Size: 0xe0 (Inherited: 0xe0)
struct UB_CosmeticStatObject_HabaneroProgression_Season27_C : UFortCosmeticStatObject_HabaneroProgressionSeasonal {
};


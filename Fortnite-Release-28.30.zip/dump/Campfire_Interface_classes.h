// BlueprintGeneratedClass Campfire_Interface.Campfire_Interface_C
// Size: 0x28 (Inherited: 0x28)
struct UCampfire_Interface_C : UInterface {

	void GetWoodComponent(struct UStaticMeshComponent*& WoodComponent); // Function Campfire_Interface.Campfire_Interface_C.GetWoodComponent // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void IsStoked(bool& IsStoked); // Function Campfire_Interface.Campfire_Interface_C.IsStoked // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void GetLocationToSpawnFireVFX(struct FVector& WorldLocation); // Function Campfire_Interface.Campfire_Interface_C.GetLocationToSpawnFireVFX // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
};


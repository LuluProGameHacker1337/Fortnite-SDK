// BlueprintGeneratedClass CameraShake_ZipLineAttach.CameraShake_ZipLineAttach_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_ZipLineAttach_C : ULegacyCameraShake {
};


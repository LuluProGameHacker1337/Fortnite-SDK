// Class AvfMediaFactory.AvfMediaSettings
// Size: 0x30 (Inherited: 0x28)
struct UAvfMediaSettings : UObject {
	bool NativeAudioOut; // 0x28(0x01)
	char pad_29[0x7]; // 0x29(0x07)
};


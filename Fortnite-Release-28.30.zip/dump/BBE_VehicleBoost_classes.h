// BlueprintGeneratedClass BBE_VehicleBoost.BBE_VehicleBoost_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_VehicleBoost_C : UFortMobileActionButtonBehaviorExtension {
};


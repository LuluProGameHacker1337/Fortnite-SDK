// BlueprintGeneratedClass BBE_NevadaEnergyCanon.BBE_NevadaEnergyCanon_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_NevadaEnergyCanon_C : UFortMobileActionButtonBehaviorExtension {
};


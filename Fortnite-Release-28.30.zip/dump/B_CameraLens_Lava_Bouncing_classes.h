// BlueprintGeneratedClass B_CameraLens_Lava_Bouncing.B_CameraLens_Lava_Bouncing_C
// Size: 0x390 (Inherited: 0x380)
struct AB_CameraLens_Lava_Bouncing_C : AEmitterCameraLensEffectBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)
	struct UParticleSystemComponent* P_Camera_Lava_Bouncing; // 0x388(0x08)

	void ReceiveBeginPlay(); // Function B_CameraLens_Lava_Bouncing.B_CameraLens_Lava_Bouncing_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_B_CameraLens_Lava_Bouncing(int32_t EntryPoint); // Function B_CameraLens_Lava_Bouncing.B_CameraLens_Lava_Bouncing_C.ExecuteUbergraph_B_CameraLens_Lava_Bouncing // (Final|UbergraphFunction) // @ game+0x3d1d968
};


// Class AtomRuntime.AtomAssetImportData
// Size: 0x28 (Inherited: 0x28)
struct UAtomAssetImportData : UAssetImportData {
};

// Class AtomRuntime.AtomModelMergedMeshImportData
// Size: 0x28 (Inherited: 0x28)
struct UAtomModelMergedMeshImportData : UAssetImportData {
};

// Class AtomRuntime.AtomModelGeometryCollectionImportData
// Size: 0x28 (Inherited: 0x28)
struct UAtomModelGeometryCollectionImportData : UAssetImportData {
};

// Class AtomRuntime.AtomDatabaseSubsystemBase
// Size: 0x30 (Inherited: 0x30)
struct UAtomDatabaseSubsystemBase : UEngineSubsystem {
};

// Class AtomRuntime.AtomModelActor
// Size: 0x2a8 (Inherited: 0x290)
struct AAtomModelActor : AActor {
	struct UAtomModel* AtomModel; // 0x290(0x08)
	struct FString PrimitiveStyleName; // 0x298(0x10)
};

// Class AtomRuntime.AtomModelAssetUserData
// Size: 0xa8 (Inherited: 0x28)
struct UAtomModelAssetUserData : UAssetUserData {
	struct FSerializedConnectivityObjects AtomModelConnections; // 0x28(0x20)
	struct FAtomCommonPartInstancesCache CommonPartCache; // 0x48(0x50)
	struct TArray<struct FName> Tags; // 0x98(0x10)
};

// Class AtomRuntime.AtomCommonPartModelAssetUserData
// Size: 0x38 (Inherited: 0x28)
struct UAtomCommonPartModelAssetUserData : UAssetUserData {
	struct FAtomCommonPartAssetDescription AssetDescription; // 0x28(0x0c)
	char pad_34[0x4]; // 0x34(0x04)
};

// Class AtomRuntime.AtomPartsCollectionBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomPartsCollectionBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetName(struct FAtomModelPartsCollection& PartsCollection, struct FString Name); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.SetName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9b30e4
	void ReplacePartInstance(struct FAtomModelPartsCollection& PartCollection, struct FAtomModelPartInstanceInfo& SourcePartInstance, struct FAtomModelPartGuid& TargetPartInstanceId); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.ReplacePartInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9b2894
	void RemovePartInstance(struct FAtomModelPartsCollection& PartCollection, struct FAtomModelPartGuid& PartInstanceId); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.RemovePartInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9b2780
	struct FAtomModelPartsCollection InitializeCommonParts(struct FAtomModelPartsCollection& PartsCollection, struct UAtomModel* Model, float Scale, bool bRemoveConnectedParts, bool bRemoveAllKnobs, bool bRemoveAllTubes, bool bRemoveAllPins); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.InitializeCommonParts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9b20c4
	struct TArray<struct FAtomCommonPartAndTransform> GetPrimitiveCommonParts(struct UAtomPrimitive* Primitive, double Scale); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetPrimitiveCommonParts // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9b1d9c
	struct TArray<struct FAtomModelPartInstanceInfo> GetParts(struct FAtomModelPartsCollection& PartsCollection); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetParts // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa9b1cd4
	struct FString GetName(struct FAtomModelPartsCollection& PartsCollection); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.GetName // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa9b14e4
	struct FAtomModelPartsCollection FilterTransparent(struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterTransparent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa9b05b0
	struct FAtomModelPartsCollection FilterSelectionSet(struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString SelectionSetName, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterSelectionSet // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa9afc74
	struct FAtomModelPartsCollection FilterNonTransparent(struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterNonTransparent // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa9af458
	struct FAtomModelPartsCollection FilterGroup(struct UAtomModel* Model, struct FAtomModelPartsCollection& PartsCollectionToFilter, struct FString GroupName, struct FString NewPartsCollectionName); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.FilterGroup // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa9aeae8
	struct FAtomModelPartColorInfo CreateColorInfoFromColorId(int32_t ColorId); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.CreateColorInfoFromColorId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9ae9a4
	struct FAtomModelPartGuid Conv_StringToModelPartGuid(struct FString InString); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.Conv_StringToModelPartGuid // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9adb94
	struct FString Conv_ModelPartGuidToString(struct FAtomModelPartGuid& InModelPartGuid); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.Conv_ModelPartGuidToString // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa9adae0
	void AddPartInstance(struct FAtomModelPartsCollection& PartCollection, struct FAtomModelPartInstanceInfo& PartInstance); // Function AtomRuntime.AtomPartsCollectionBlueprintLibrary.AddPartInstance // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9acd7c
};

// Class AtomRuntime.AtomPrimitiveBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomPrimitiveBlueprintLibrary : UBlueprintFunctionLibrary {

	float GetDefaultPrimitiveScale(); // Function AtomRuntime.AtomPrimitiveBlueprintLibrary.GetDefaultPrimitiveScale // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b1480
};

// Class AtomRuntime.AtomPrimitiveGeometry
// Size: 0x2e8 (Inherited: 0x28)
struct UAtomPrimitiveGeometry : UObject {
	char pad_28[0x2c0]; // 0x28(0x2c0)

	struct UStaticMesh* ToSimplifiedStaticMesh(float Scale, struct UObject* Outer, struct FString Name, bool bFastBuild); // Function AtomRuntime.AtomPrimitiveGeometry.ToSimplifiedStaticMesh // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b3aa8
	struct TArray<struct UAtomPrimitiveGeometry*> SplitByPolygonGroup(); // Function AtomRuntime.AtomPrimitiveGeometry.SplitByPolygonGroup // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b3a3c
	struct UAtomPrimitiveGeometry* SetVertexColor(struct FColor& Color); // Function AtomRuntime.AtomPrimitiveGeometry.SetVertexColor // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa9b3968
	struct UAtomPrimitiveGeometry* SetTiledUVs(float TileSize); // Function AtomRuntime.AtomPrimitiveGeometry.SetTiledUVs // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b38d8
	struct UAtomPrimitiveGeometry* SetMaterialName(struct FString Name, int32_t PolygonGroupIndex); // Function AtomRuntime.AtomPrimitiveGeometry.SetMaterialName // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b2a10
	int32_t GetNumberOfCommonPartLODs(struct FString ExportStyleName, enum class EAtomCommonPartType CommonPartType, struct FString CommonPartsMeshPath); // Function AtomRuntime.AtomPrimitiveGeometry.GetNumberOfCommonPartLODs // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b15c0
	struct TArray<struct FString> GetMaterialNames(); // Function AtomRuntime.AtomPrimitiveGeometry.GetMaterialNames // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b14a8
	int32_t GetBoneIndexForName(struct FString BoneName); // Function AtomRuntime.AtomPrimitiveGeometry.GetBoneIndexForName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b0dcc
	struct UAtomPrimitiveGeometry* DuplicateGeometry(); // Function AtomRuntime.AtomPrimitiveGeometry.DuplicateGeometry // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xa9aeaac
	struct UAtomPrimitiveGeometry* CreateEmptyAtomGeometry(); // Function AtomRuntime.AtomPrimitiveGeometry.CreateEmptyAtomGeometry // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9aea58
	struct UAtomPrimitiveGeometry* CreateAtomGeometryFromCommonPart(struct FString ExportStyleName, enum class EAtomCommonPartType CommonPartType, int32_t LODIndex, struct FString CommonPartsMeshPath); // Function AtomRuntime.AtomPrimitiveGeometry.CreateAtomGeometryFromCommonPart // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9ae25c
	struct UAtomPrimitiveGeometry* BakeTransforms(struct TArray<struct FTransform3f>& Transforms); // Function AtomRuntime.AtomPrimitiveGeometry.BakeTransforms // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa9ada34
	struct UAtomPrimitiveGeometry* BakeTransform(struct FTransform3f& Transform); // Function AtomRuntime.AtomPrimitiveGeometry.BakeTransform // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa9ad968
	struct UAtomPrimitiveGeometry* BakeScale(float Scale); // Function AtomRuntime.AtomPrimitiveGeometry.BakeScale // (Final|Native|Public|BlueprintCallable) // @ game+0xa9ad8d8
	void AttachVerticesToNamedBone(struct FString BoneName); // Function AtomRuntime.AtomPrimitiveGeometry.AttachVerticesToNamedBone // (Final|Native|Public|BlueprintCallable) // @ game+0xa9ad21c
	void AttachVerticesToBoneIndex(int32_t BoneIndex); // Function AtomRuntime.AtomPrimitiveGeometry.AttachVerticesToBoneIndex // (Final|Native|Public|BlueprintCallable) // @ game+0xa9ad19c
	struct UAtomPrimitiveGeometry* AppendAndWeld(struct UAtomPrimitiveGeometry* GeometryToAppend, struct FTransform3f& Transform); // Function AtomRuntime.AtomPrimitiveGeometry.AppendAndWeld // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa9acffc
	struct UAtomPrimitiveGeometry* Append(struct UAtomPrimitiveGeometry* GeometryToAppend, struct FTransform3f& Transform); // Function AtomRuntime.AtomPrimitiveGeometry.Append // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa9aceac
};

// Class AtomRuntime.AtomPrimitiveGeometryContainer
// Size: 0xf8 (Inherited: 0x28)
struct UAtomPrimitiveGeometryContainer : UObject {
	struct TSoftObjectPtr<UStaticMesh> SourceMesh; // 0x28(0x20)
	struct FString ExportStyleName; // 0x48(0x10)
	struct TMap<struct FString, int32_t> GeometryCount; // 0x58(0x50)
	char pad_A8[0x50]; // 0xa8(0x50)

	struct FAtomPrimitiveGeometryAndTransform GetShellGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetShellGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b8184
	struct FAtomPrimitiveGeometryAndTransform GetScaledShellGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledShellGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b80d0
	struct UAtomPrimitiveGeometry* GetScaledGeometry(enum class EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b800c
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetScaledDetailsGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledDetailsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b7f64
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetScaledCapsGeometry(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetScaledCapsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b7ebc
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetPartsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetPartsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b7b50
	struct UAtomPrimitiveGeometry* GetGeometryWithMaterialNames(enum class EPrimitiveGeometryComplexity PrimitiveGeometryComplexity, struct FString ShellMaterial, struct FString UndersideMaterial); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometryWithMaterialNames // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b70a4
	struct UAtomPrimitiveGeometry* GetGeometry(enum class EPrimitiveGeometryComplexity PrimitiveGeometryComplexity); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b7014
	struct FString GetExportStyleName(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetExportStyleName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa6c3e5c
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetDetailsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetDetailsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b6e94
	struct TArray<struct FTransform> GetDefaultBoneTransforms(float Scale); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetDefaultBoneTransforms // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b6df0
	struct TArray<struct FAtomPrimitiveGeometryAndTransform> GetCapsGeometry(); // Function AtomRuntime.AtomPrimitiveGeometryContainer.GetCapsGeometry // (Final|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b5f9c
};

// Class AtomRuntime.AtomRuntimeBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomRuntimeBlueprintLibrary : UBlueprintFunctionLibrary {

	struct FAtomColorInfo GetInfoForColorId(int32_t ColorId); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetInfoForColorId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9b77cc
	void GetCommonPartDescriptionFromType(enum class EAtomCommonPartType CommonPartType, struct FAtomCommonPartDescription& OutDescription); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartDescriptionFromType // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa9b65c0
	enum class EAtomCommonPartCategory GetCommonPartCategoryFromType(enum class EAtomCommonPartType CommonPartType); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartCategoryFromType // (Final|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0xa9b6540
	void GetCommonPartAssetDescriptionFromStaticMesh(struct UStaticMesh* StaticMesh, struct FAtomCommonPartAssetDescription& OutDescription, enum class EGetCommonPartDescriptionResult& OutIsValid); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetCommonPartAssetDescriptionFromStaticMesh // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9b63c0
	int32_t GetBitPackForColorId(int32_t AtomColorId); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetBitPackForColorId // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9b5ee4
	int32_t GetBitPackForColor(struct FColor& Color); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetBitPackForColor // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xa9b5e10
	struct TMap<int32_t, struct FAtomColorInfo> GetAllColorInfo(); // Function AtomRuntime.AtomRuntimeBlueprintLibrary.GetAllColorInfo // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9b5cec
};

// Class AtomRuntime.AtomRuntimeSettings
// Size: 0x60 (Inherited: 0x30)
struct UAtomRuntimeSettings : UDeveloperSettings {
	float PrimitiveGlobalScale; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct TSoftObjectPtr<UDataTable> ColorDataTableOverride; // 0x38(0x20)
	bool bEnableWorldConnectivity; // 0x58(0x01)
	bool bCookContent; // 0x59(0x01)
	char pad_5A[0x6]; // 0x5a(0x06)

	struct UDataTable* GetColorDataTable(); // Function AtomRuntime.AtomRuntimeSettings.GetColorDataTable // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b639c
};

// Class AtomRuntime.WorldConnectivitySubsystem
// Size: 0x180 (Inherited: 0x30)
struct UWorldConnectivitySubsystem : UWorldSubsystem {
	char pad_30[0x150]; // 0x30(0x150)

	void UnregisterConnectivityActor(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.UnregisterConnectivityActor // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b9568
	bool TryConnectObjectAtLocation(struct FWorldConnectivityHandle ObjectToConnect, struct FTransform& DesiredObjectTransform, struct TArray<struct FWorldConnectivityHandle>& ConnectionCandidates, bool PerformConnection); // Function AtomRuntime.WorldConnectivitySubsystem.TryConnectObjectAtLocation // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa9b8b84
	struct TArray<struct FConnectivityQueryResult> RunPlanarConnectivityQuery(struct AActor* AtomModelActorToPlace, struct AActor* AtomModelActorToConnect, struct FVector& QueryStartLocation, struct FVector& QueryEndLocation, enum class ECollisionChannel QueryCollisionChannel, int32_t QueryRadius); // Function AtomRuntime.WorldConnectivitySubsystem.RunPlanarConnectivityQuery // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa9b86a0
	void RegisterModelActor(struct AActor* Actor, struct FSerializedConnectivityObjects& Connections); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterModelActor // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa9b85ac
	void RegisterCustomConnectivityActor(struct AActor* Actor, struct FSerializedConnectivityObjects& ConnectivityObject); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterCustomConnectivityActor // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa9b85ac
	void RegisterConnectivityActor(struct AActor* Actor, struct UAtomModel* Model); // Function AtomRuntime.WorldConnectivitySubsystem.RegisterConnectivityActor // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b84dc
	double PlanarGridStepSize(); // Function AtomRuntime.WorldConnectivitySubsystem.PlanarGridStepSize // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b84bc
	struct FTransform GetTransform(struct FWorldConnectivityHandle Handle); // Function AtomRuntime.WorldConnectivitySubsystem.GetTransform // (Final|Native|Public|HasDefaults|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b8344
	struct TArray<struct FPlanarFieldInfo> GetPlanarFields(struct FWorldConnectivityHandle Handle, enum class EConnectionFieldGender Type); // Function AtomRuntime.WorldConnectivitySubsystem.GetPlanarFields // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b7c68
	struct FVector GetPlanarFieldCenter(struct FPlanarFieldInfo& Field); // Function AtomRuntime.WorldConnectivitySubsystem.GetPlanarFieldCenter // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xa9b7b8c
	struct FVector GetOverlapPenetrationDepth(struct AStaticMeshActor* Actor1, struct AStaticMeshActor* Actor2, struct FVector Offset); // Function AtomRuntime.WorldConnectivitySubsystem.GetOverlapPenetrationDepth // (Final|Native|Public|HasDefaults|BlueprintCallable) // @ game+0xa9b7878
	struct TArray<struct FWorldConnectivityHandle> GetConnectivityHandles(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectivityHandles // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b6bac
	struct FWorldConnectivityHandle GetConnectivityHandle(struct AActor* Actor); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectivityHandle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b6974
	struct TArray<struct FWorldConnectivityHandle> GetConnectedObjectsRecursively(struct FWorldConnectivityHandle Object); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectedObjectsRecursively // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b6810
	struct TArray<struct FWorldConnectivityHandle> GetConnectedObjects(struct FWorldConnectivityHandle Object); // Function AtomRuntime.WorldConnectivitySubsystem.GetConnectedObjects // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b66ac
	struct FPlanarFieldInfo GetClosestFieldToPoint(struct FWorldConnectivityHandle Handle, struct FVector& WorldLocation, enum class EConnectionFieldGender Type, bool& bSuccess); // Function AtomRuntime.WorldConnectivitySubsystem.GetClosestFieldToPoint // (Final|Native|Public|HasOutParms|HasDefaults|BlueprintCallable) // @ game+0xa9b5fd8
	struct UAtomModelAssetUserData* GetAtomModelAssetUserData(struct UObject* Object); // Function AtomRuntime.WorldConnectivitySubsystem.GetAtomModelAssetUserData // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b5d90
	struct AActor* GetActor(struct FWorldConnectivityHandle Handle); // Function AtomRuntime.WorldConnectivitySubsystem.GetActor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9b5ba0
	void DisconnectObjects(struct FWorldConnectivityHandle ObjectA, struct FWorldConnectivityHandle ObjectB); // Function AtomRuntime.WorldConnectivitySubsystem.DisconnectObjects // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b5874
	void DisconnectAllObjectConnections(struct FWorldConnectivityHandle Object); // Function AtomRuntime.WorldConnectivitySubsystem.DisconnectAllObjectConnections // (Final|Native|Public|BlueprintCallable) // @ game+0xa9b5734
};

// Class AtomRuntime.WorldConnectivityBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UWorldConnectivityBlueprintLibrary : UBlueprintFunctionLibrary {

	bool IsValid(struct FWorldConnectivityHandle& Handle); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa410b3c
	struct FTransform GetTransform(struct UObject* WorldContext, struct FWorldConnectivityHandle& Handle); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.GetTransform // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xa9b81f4
	struct FVector GetFieldCenter(struct UObject* WorldContext, struct FPlanarFieldInfo& Field); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.GetFieldCenter // (Final|Native|Static|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintPure) // @ game+0xa9b6ed0
	struct AActor* GetActor(struct UObject* WorldContext, struct FWorldConnectivityHandle& Handle); // Function AtomRuntime.WorldConnectivityBlueprintLibrary.GetActor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0xa9b5aa8
};

// Class AtomRuntime.AtomModel
// Size: 0x258 (Inherited: 0x28)
struct UAtomModel : UObject {
	struct FAtomModelAssetSettings Settings; // 0x28(0x38)
	struct TArray<struct FAtomModelPrimitive> Primitives; // 0x60(0x10)
	struct TArray<struct FAtomHingedElement> Elements; // 0x70(0x10)
	struct TArray<struct FAtomModelSelectionSet> SelectionSets; // 0x80(0x10)
	struct TArray<struct FAtomModelConfigurationGroup> Groups; // 0x90(0x10)
	struct TMap<enum class EAtomCommonPartType, struct TSoftObjectPtr<UStaticMesh>> CommonPartOverrides; // 0xa0(0x50)
	char CommonPartOptimization; // 0xf0(0x01)
	char pad_F1[0x7]; // 0xf1(0x07)
	struct FSerializedConnectivityObjects SerializedConnectivityObjects; // 0xf8(0x20)
	struct TMap<struct FString, struct TSoftObjectPtr<UTexture>> TextureNameToAsset; // 0x118(0x50)
	char pad_168[0x50]; // 0x168(0x50)
	struct FAtomSourceModel SourceModel; // 0x1b8(0xa0)

	struct UTexture* GetTextureForDecorationTextureName(struct FString TextureName); // Function AtomRuntime.AtomModel.GetTextureForDecorationTextureName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9e334c
	void GetPrimitivesForChildArray(int32_t InChildIdx, struct TArray<struct FAtomModelPrimitiveInstance>& OutPrimitives); // Function AtomRuntime.AtomModel.GetPrimitivesForChildArray // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0xa9e2b2c
	struct FAtomModelPartsCollection GetPartsCollection(); // Function AtomRuntime.AtomModel.GetPartsCollection // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9e2ac8
	struct FString GetModelPath(); // Function AtomRuntime.AtomModel.GetModelPath // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9e296c
	struct FString GetModelName(); // Function AtomRuntime.AtomModel.GetModelName // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9e292c
	struct TArray<struct TSoftObjectPtr<UStaticMesh>> GetGeneratedMergedMeshes(); // Function AtomRuntime.AtomModel.GetGeneratedMergedMeshes // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9e2134
	struct FString GetChildIdentifier(int32_t InChildIdx); // Function AtomRuntime.AtomModel.GetChildIdentifier // (Final|Native|Public|BlueprintCallable) // @ game+0xa9e1aa8
};

// Class AtomRuntime.AtomModelComponent
// Size: 0x2c0 (Inherited: 0x220)
struct UAtomModelComponent : USceneComponent {
	struct UAtomModel* AtomModel; // 0x220(0x08)
	enum class EAtomModelInstanceType InstanceType; // 0x228(0x01)
	char pad_229[0x7]; // 0x229(0x07)
	struct FString RenderStyle; // 0x230(0x10)
	struct FString FallbackRenderStyle; // 0x240(0x10)
	bool bUseCombinedMeshes; // 0x250(0x01)
	bool bUseColorPayload; // 0x251(0x01)
	bool bCreateRigidElements; // 0x252(0x01)
	bool bEnableConnectivity; // 0x253(0x01)
	struct FName SelectionSetFilter; // 0x254(0x04)
	char CommonPartOptimization; // 0x258(0x01)
	char pad_259[0x7]; // 0x259(0x07)
	struct TArray<struct USceneComponent*> RigidElementComponents; // 0x260(0x10)
	struct TMap<struct FName, struct FModelPrimitiveEntry> ComponentToPrimitive; // 0x270(0x50)
};

// Class AtomRuntime.AtomPrimitiveComponent
// Size: 0x5f0 (Inherited: 0x5c0)
struct UAtomPrimitiveComponent : UStaticMeshComponent {
	struct UAtomPrimitive* AtomPrimitive; // 0x5c0(0x08)
	struct FString RenderStyle; // 0x5c8(0x10)
	struct FString FallbackRenderStyle; // 0x5d8(0x10)
	bool bUseCombinedMeshes; // 0x5e8(0x01)
	char pad_5E9[0x7]; // 0x5e9(0x07)
};

// Class AtomRuntime.AtomModelProcessor
// Size: 0x58 (Inherited: 0x28)
struct UAtomModelProcessor : UObject {
	bool bEnableRebuildProgress; // 0x28(0x01)
	char pad_29[0x3]; // 0x29(0x03)
	float DialogDelay; // 0x2c(0x04)
	int32_t NumProgressSteps; // 0x30(0x04)
	char pad_34[0x4]; // 0x34(0x04)
	struct FString ProgressMessage; // 0x38(0x10)
	char pad_48[0x10]; // 0x48(0x10)

	struct FAtomProcessorResult OnProcessPrimitive(struct UAtomModel* DummyModel, struct UAtomPrimitive* Primitive, struct FAtomModelPartsCollection& AtomModelPartsCollection, struct FAtomOnProcessPrimitiveSettings& Settings); // Function AtomRuntime.AtomModelProcessor.OnProcessPrimitive // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	struct FAtomProcessorResult OnProcessModel(struct UAtomModel* Model, struct FAtomModelPartsCollection& AtomModelPartsCollection, struct TArray<struct TSoftObjectPtr<UObject>>& ExistingObjects); // Function AtomRuntime.AtomModelProcessor.OnProcessModel // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	struct FString OnGetTargetAssetPath(struct UAtomModel* Model, struct UAtomPrimitive* Primitive, struct FAtomModelPartsCollection& AtomModelPartsCollection); // Function AtomRuntime.AtomModelProcessor.OnGetTargetAssetPath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	struct FString OnGetProcessPrimitiveTargetAssetPath(struct UAtomModel* Model, struct UAtomPrimitive* Primitive, struct FAtomModelPartsCollection& AtomModelPartsCollection, struct FAtomOnProcessPrimitiveSettings& Settings); // Function AtomRuntime.AtomModelProcessor.OnGetProcessPrimitiveTargetAssetPath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	struct FString OnGetProcessModelTargetAssetPath(struct UAtomModel* Model, struct FAtomModelPartsCollection& AtomModelPartsCollection); // Function AtomRuntime.AtomModelProcessor.OnGetProcessModelTargetAssetPath // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	void IncrementProgress(int32_t NumSteps, struct FString Message); // Function AtomRuntime.AtomModelProcessor.IncrementProgress // (Final|Native|Public|BlueprintCallable) // @ game+0xa9e39fc
};

// Class AtomRuntime.AtomProcessorBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAtomProcessorBlueprintLibrary : UBlueprintFunctionLibrary {

	void SetModelProcessor(struct FAtomModelProcessorInstance& ProcessorInstance, struct UAtomModelProcessor* ModelProcessor, bool bUseCustomSettings); // Function AtomRuntime.AtomProcessorBlueprintLibrary.SetModelProcessor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9e420c
	bool IsValid(struct FAtomModelProcessorInstance& ProcessorInstance); // Function AtomRuntime.AtomProcessorBlueprintLibrary.IsValid // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9e4140
	struct UObject* GetProcessorClass(struct FAtomModelProcessorInstance& ProcessorInstance); // Function AtomRuntime.AtomProcessorBlueprintLibrary.GetProcessorClass // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9e31f4
	struct UAtomModelProcessor* GetModelProcessor(struct FAtomModelProcessorInstance& ProcessorInstance); // Function AtomRuntime.AtomProcessorBlueprintLibrary.GetModelProcessor // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9e29d0
	struct FAtomProcessorResult AppendAtomProcessorResult(struct FAtomProcessorResult& Result, struct FAtomProcessorResult& ResultToAppend); // Function AtomRuntime.AtomProcessorBlueprintLibrary.AppendAtomProcessorResult // (Final|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0xa9e1910
};

// Class AtomRuntime.AtomPrimitive
// Size: 0x1f0 (Inherited: 0x28)
struct UAtomPrimitive : UObject {
	int32_t PartId; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct FString PartRevision; // 0x30(0x10)
	struct FName DesignName; // 0x40(0x04)
	bool bIsFlex; // 0x44(0x01)
	bool bIsVariant; // 0x45(0x01)
	char pad_46[0x2]; // 0x46(0x02)
	struct TArray<struct FString> DecorationSurfaceNames; // 0x48(0x10)
	int32_t NumberOfColorSurfaces; // 0x58(0x04)
	enum class EAtomPlatform AtomPlatform; // 0x5c(0x01)
	char pad_5D[0x3]; // 0x5d(0x03)
	int32_t AtomMainGroupId; // 0x60(0x04)
	int32_t AtomSubMainGroupId; // 0x64(0x04)
	struct TMap<enum class EAtomCommonPartType, struct FAtomPrimitiveCommonPart> PrimitiveCommonParts; // 0x68(0x50)
	struct TMap<struct FName, struct FAtomPrimitiveCommonPart> CommonParts; // 0xb8(0x50)
	bool bOverrideConnectionFields; // 0x108(0x01)
	char pad_109[0x7]; // 0x109(0x07)
	struct FBoxSphereBounds Bounds; // 0x110(0x38)
	struct FBoxSphereBounds UnscaledBounds; // 0x148(0x38)
	struct TArray<struct UAtomPrimitiveGeometryContainer*> GeometryContainers; // 0x180(0x10)
	struct FConnectionFieldContainer ConnectionFields; // 0x190(0x30)
	struct FConnectionFieldContainer ConnectionFieldsOverride; // 0x1c0(0x30)

	bool IsFlexElement(); // Function AtomRuntime.AtomPrimitive.IsFlexElement // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9e412c
	struct FName GetSubMainGroupName(int32_t SubMainGroupId); // Function AtomRuntime.AtomPrimitive.GetSubMainGroupName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9e32c8
	struct FName GetMainGroupName(int32_t MainGroupId); // Function AtomRuntime.AtomPrimitive.GetMainGroupName // (Final|Native|Static|Public|BlueprintCallable) // @ game+0xa9e28a8
	struct UAtomPrimitiveGeometryContainer* GetGeometryContainerForExportStyle(struct FString ExportStyleName, struct FString FallbackExportStyleName); // Function AtomRuntime.AtomPrimitive.GetGeometryContainerForExportStyle // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0xa9e21c0
};


// BlueprintGeneratedClass BP_HitNotifySoundLibraryComponent.BP_HitNotifySoundLibraryComponent_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UBP_HitNotifySoundLibraryComponent_C : UFortHitNotifySoundLibraryComponent {
};


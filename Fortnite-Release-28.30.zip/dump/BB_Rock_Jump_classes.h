// BlueprintGeneratedClass BB_Rock_Jump.BB_Rock_Jump_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_Rock_Jump_C : UFortMobileActionButtonBehavior {
};


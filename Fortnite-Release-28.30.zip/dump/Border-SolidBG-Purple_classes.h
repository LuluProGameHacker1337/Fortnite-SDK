// BlueprintGeneratedClass Border-SolidBG-Purple.Border-SolidBG-Purple_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-SolidBG-Purple_C : UBorder-ShellTopBar_C {
};


// BlueprintGeneratedClass B_Pickups_Parent.B_Pickups_Parent_C
// Size: 0x5a4 (Inherited: 0x460)
struct AB_Pickups_Parent_C : AFortPickupsParent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x460(0x08)
	struct USceneComponent* Root; // 0x468(0x08)
	float MobileSelectedTL_LerpInteactoIcon_FF208F9641BE589B76EF698B94309EA7; // 0x470(0x04)
	float MobileSelectedTL_LerpObject_FF208F9641BE589B76EF698B94309EA7; // 0x474(0x04)
	enum class ETimelineDirection MobileSelectedTL__Direction_FF208F9641BE589B76EF698B94309EA7; // 0x478(0x01)
	char pad_479[0x7]; // 0x479(0x07)
	struct UTimelineComponent* MobileSelectedTL; // 0x480(0x08)
	struct UStaticMeshComponent* Static_Mesh_Pickup; // 0x488(0x08)
	struct USkeletalMeshComponent* Skeletal_Mesh_Pickup; // 0x490(0x08)
	struct UPrimitiveComponent* SkeletalOrStaticMeshAssetPrimitive; // 0x498(0x08)
	int32_t CurrentElementIndex; // 0x4a0(0x04)
	char pad_4A4[0x4]; // 0x4a4(0x04)
	double Component Radius (Scaled); // 0x4a8(0x08)
	double Component Radius Multiplier; // 0x4b0(0x08)
	struct TArray<struct FLinearColor> Outline Rarity Colors; // 0x4b8(0x10)
	double Component Radius; // 0x4c8(0x08)
	struct UParticleSystem* Picked Up Trail PS Old; // 0x4d0(0x08)
	struct TArray<double> Sparkle Spawn Rate (Picked Up); // 0x4d8(0x10)
	struct TArray<double> Lifetime (Picked Up); // 0x4e8(0x10)
	struct UForceFeedbackEffect* PickupForceFeedback Old; // 0x4f8(0x08)
	bool HasUniqueMaterialIds; // 0x500(0x01)
	char pad_501[0x7]; // 0x501(0x07)
	struct TArray<struct FLinearColor> BackgroundRarityColors; // 0x508(0x10)
	double Random Rotation; // 0x518(0x08)
	struct FVector MobileSelectedOffset; // 0x520(0x18)
	struct FVector MobileSelectedScale; // 0x538(0x18)
	struct UStaticMeshComponent* MobileInteractIcon; // 0x550(0x08)
	struct FVector MobileInteractIconLocation; // 0x558(0x18)
	struct FVector MobileInteractIconScale; // 0x570(0x18)
	struct UMaterialInterface* MobileInteractionMaterial; // 0x588(0x08)
	bool PickedUp; // 0x590(0x01)
	char pad_591[0x3]; // 0x591(0x03)
	struct FLinearColor MissionItemOutlineColor; // 0x594(0x10)

	int32_t GetViewDistanceQuality(); // Function B_Pickups_Parent.B_Pickups_Parent_C.GetViewDistanceQuality // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Setup View Distances(int32_t& viewDistanceQuality); // Function B_Pickups_Parent.B_Pickups_Parent_C.Setup View Distances // (Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Mobile Interation Icon Setup(); // Function B_Pickups_Parent.B_Pickups_Parent_C.Mobile Interation Icon Setup // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void SetVisibleMobileInteractIcon(bool Visible); // Function B_Pickups_Parent.B_Pickups_Parent_C.SetVisibleMobileInteractIcon // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void SetActiveBackgroundParticleSystem(bool Active, bool Reset); // Function B_Pickups_Parent.B_Pickups_Parent_C.SetActiveBackgroundParticleSystem // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void SetHiddenBackgroundVisualComponents(bool Hidden); // Function B_Pickups_Parent.B_Pickups_Parent_C.SetHiddenBackgroundVisualComponents // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void DestroyBackgroundVisualComponents(); // Function B_Pickups_Parent.B_Pickups_Parent_C.DestroyBackgroundVisualComponents // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ScaleHologramTimingsForPvP(); // Function B_Pickups_Parent.B_Pickups_Parent_C.ScaleHologramTimingsForPvP // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void SetHologramPickedUpParams(bool Tier 0); // Function B_Pickups_Parent.B_Pickups_Parent_C.SetHologramPickedUpParams // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void SpawnPickedUpTrailPS(); // Function B_Pickups_Parent.B_Pickups_Parent_C.SpawnPickedUpTrailPS // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void UserConstructionScript(); // Function B_Pickups_Parent.B_Pickups_Parent_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void MobileSelectedTL__FinishedFunc(); // Function B_Pickups_Parent.B_Pickups_Parent_C.MobileSelectedTL__FinishedFunc // (BlueprintEvent) // @ game+0x3d1d968
	void MobileSelectedTL__UpdateFunc(); // Function B_Pickups_Parent.B_Pickups_Parent_C.MobileSelectedTL__UpdateFunc // (BlueprintEvent) // @ game+0x3d1d968
	void DisableBacchusHighlight(); // Function B_Pickups_Parent.B_Pickups_Parent_C.DisableBacchusHighlight // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void HideBackgroundAndSpotlight(); // Function B_Pickups_Parent.B_Pickups_Parent_C.HideBackgroundAndSpotlight // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnAttached(); // Function B_Pickups_Parent.B_Pickups_Parent_C.OnAttached // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void EnableBacchusHighlight(); // Function B_Pickups_Parent.B_Pickups_Parent_C.EnableBacchusHighlight // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void OnTossed(); // Function B_Pickups_Parent.B_Pickups_Parent_C.OnTossed // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void OnPickedUp(struct AFortPawn* PickupTarget); // Function B_Pickups_Parent.B_Pickups_Parent_C.OnPickedUp // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveBeginPlay(); // Function B_Pickups_Parent.B_Pickups_Parent_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_B_Pickups_Parent(int32_t EntryPoint); // Function B_Pickups_Parent.B_Pickups_Parent_C.ExecuteUbergraph_B_Pickups_Parent // (Final|UbergraphFunction|HasDefaults) // @ game+0x3d1d968
};


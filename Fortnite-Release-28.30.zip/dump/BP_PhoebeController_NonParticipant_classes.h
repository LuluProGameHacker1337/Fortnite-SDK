// BlueprintGeneratedClass BP_PhoebeController_NonParticipant.BP_PhoebeController_NonParticipant_C
// Size: 0x1770 (Inherited: 0x1770)
struct ABP_PhoebeController_NonParticipant_C : ABP_PhoebePlayerController_C {
};


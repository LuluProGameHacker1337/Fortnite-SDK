// BlueprintGeneratedClass B_Medium_Explosion_CameraShake.B_Medium_Explosion_CameraShake_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UB_Medium_Explosion_CameraShake_C : ULegacyCameraShake {
};


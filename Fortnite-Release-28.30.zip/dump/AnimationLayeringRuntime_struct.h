// Enum AnimationLayeringRuntime.ECopyMotion_Component
enum class ECopyMotion_Component : uint8 {
	TranslationX = 0,
	TranslationY = 1,
	TranslationZ = 2,
	RotationAngle = 3,
	ECopyMotion_MAX = 4
};

// ScriptStruct AnimationLayeringRuntime.BoneMaskPerBoneData
// Size: 0x08 (Inherited: 0x00)
struct FBoneMaskPerBoneData {
	int32_t SkeletonPoseBoneIndex; // 0x00(0x04)
	float BlendWeight; // 0x04(0x04)
};

// ScriptStruct AnimationLayeringRuntime.BoneMaskBodyPartDefinition
// Size: 0x38 (Inherited: 0x00)
struct FBoneMaskBodyPartDefinition {
	struct FName Name; // 0x00(0x04)
	char pad_4[0x4]; // 0x04(0x04)
	struct TArray<struct FBranchFilter> BranchFilters; // 0x08(0x10)
	struct TArray<struct FBoneMaskPerBoneData> SkeletonPoseBoneWeights; // 0x18(0x10)
	struct TArray<int32_t> SkeletonPoseChildBoneIndices; // 0x28(0x10)
};

// ScriptStruct AnimationLayeringRuntime.BoneMaskEntry
// Size: 0x08 (Inherited: 0x00)
struct FBoneMaskEntry {
	float LocalSpaceWeight; // 0x00(0x04)
	float MeshSpaceWeight; // 0x04(0x04)
};

// ScriptStruct AnimationLayeringRuntime.BoneMask
// Size: 0x50 (Inherited: 0x00)
struct FBoneMask {
	struct TMap<struct FName, struct FBoneMaskEntry> BoneMaskMap; // 0x00(0x50)
};

// ScriptStruct AnimationLayeringRuntime.BoneMaskDefinition
// Size: 0x10 (Inherited: 0x00)
struct FBoneMaskDefinition {
	struct TArray<struct FBoneMaskBodyPartDefinition> BodyPartDefinitions; // 0x00(0x10)
};

// ScriptStruct AnimationLayeringRuntime.BoneMaskUpdateMultiParam
// Size: 0x0c (Inherited: 0x00)
struct FBoneMaskUpdateMultiParam {
	struct FName Name; // 0x00(0x04)
	float LocalSpaceWeight; // 0x04(0x04)
	float MeshSpaceWeight; // 0x08(0x04)
};

// ScriptStruct AnimationLayeringRuntime.BoneMaskBodyPartNameContainer
// Size: 0x10 (Inherited: 0x00)
struct FBoneMaskBodyPartNameContainer {
	struct TArray<struct FName> Names; // 0x00(0x10)
};

// ScriptStruct AnimationLayeringRuntime.AnimNode_BoneMask
// Size: 0xf8 (Inherited: 0x10)
struct FAnimNode_BoneMask : FAnimNode_Base {
	struct FPoseLink BasePose; // 0x10(0x10)
	struct TArray<struct FPoseLink> BlendPoses; // 0x20(0x10)
	struct TArray<float> BlendWeights; // 0x30(0x10)
	struct FBoneMask BoneMask; // 0x40(0x50)
	struct UBoneMaskDefinitionDataAsset* BoneMaskDefinitionDataAsset; // 0x90(0x08)
	struct TArray<struct FBoneMaskBodyPartNameContainer> BodyParts; // 0x98(0x10)
	enum class ECurveBlendOption CurveBlendOption; // 0xa8(0x01)
	char pad_A9[0x3]; // 0xa9(0x03)
	int32_t LODThreshold; // 0xac(0x04)
	char pad_B0[0x48]; // 0xb0(0x48)
};

// ScriptStruct AnimationLayeringRuntime.AnimNode_CopyBoneAdvanced
// Size: 0x128 (Inherited: 0xc8)
struct FAnimNode_CopyBoneAdvanced : FAnimNode_SkeletalControlBase {
	struct FBoneReference SourceBone; // 0xc8(0x0c)
	struct FBoneReference TargetBone; // 0xd4(0x0c)
	struct FVector TranslationWeight; // 0xe0(0x18)
	float RotationWeight; // 0xf8(0x04)
	float ScaleWeight; // 0xfc(0x04)
	enum class EBoneControlSpace ControlSpace; // 0x100(0x01)
	char pad_101[0x3]; // 0x101(0x03)
	struct FBoneReference TranslationSpaceBone; // 0x104(0x0c)
	bool bTranslationInCustomBoneSpace; // 0x110(0x01)
	bool bPropagateToChildren; // 0x111(0x01)
	char pad_112[0x16]; // 0x112(0x16)
};

// ScriptStruct AnimationLayeringRuntime.AnimNode_CopyMotion
// Size: 0x1e0 (Inherited: 0xc8)
struct FAnimNode_CopyMotion : FAnimNode_SkeletalControlBase {
	struct FComponentSpacePoseLink BasePose; // 0xc8(0x10)
	struct FComponentSpacePoseLink BasePoseReference; // 0xd8(0x10)
	bool bUseBasePose; // 0xe8(0x01)
	char pad_E9[0x3]; // 0xe9(0x03)
	struct FName PoseHistoryTag; // 0xec(0x04)
	float Delay; // 0xf0(0x04)
	struct FBoneReference SourceBone; // 0xf4(0x0c)
	struct FBoneReference BoneToModify; // 0x100(0x0c)
	struct FBoneReference CopySpace; // 0x10c(0x0c)
	struct FBoneReference ApplySpace; // 0x118(0x0c)
	char pad_124[0x4]; // 0x124(0x04)
	struct FRotator TranslationOffset; // 0x128(0x18)
	struct FRotator RotationOffset; // 0x140(0x18)
	struct FVector RotationPivot; // 0x158(0x18)
	struct FName CurvePrefix; // 0x170(0x04)
	struct FName TargetCurveName; // 0x174(0x04)
	float TargetCurveScale; // 0x178(0x04)
	enum class ECopyMotion_Component TargetCurveComponent; // 0x17c(0x01)
	enum class EAxis TargetCurveRotationAxis; // 0x17d(0x01)
	char pad_17E[0x2]; // 0x17e(0x02)
	struct FName TranslationX_CurveName; // 0x180(0x04)
	struct FName TranslationY_CurveName; // 0x184(0x04)
	struct FName TranslationZ_CurveName; // 0x188(0x04)
	struct FName RotationRoll_CurveName; // 0x18c(0x04)
	struct FName RotationPitch_CurveName; // 0x190(0x04)
	struct FName RotationYaw_CurveName; // 0x194(0x04)
	struct FVector TranslationScale; // 0x198(0x18)
	struct UCurveVector* TranslationRemapCurve; // 0x1b0(0x08)
	float RotationScale; // 0x1b8(0x04)
	char pad_1BC[0x4]; // 0x1bc(0x04)
	struct UCurveFloat* RotationRemapCurve; // 0x1c0(0x08)
	char pad_1C8[0x18]; // 0x1c8(0x18)
};


// BlueprintGeneratedClass BB_Rock_Boost.BB_Rock_Boost_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_Rock_Boost_C : UFortMobileActionButtonBehavior {
};


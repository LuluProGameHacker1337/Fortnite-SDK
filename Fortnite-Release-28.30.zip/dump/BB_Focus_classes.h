// BlueprintGeneratedClass BB_Focus.BB_Focus_C
// Size: 0x140 (Inherited: 0x140)
struct UBB_Focus_C : UFortMobileActionButtonBehavior_Focus {
};


// BlueprintGeneratedClass CamShake_Athena_Player_Slide.CamShake_Athena_Player_Slide_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCamShake_Athena_Player_Slide_C : ULegacyCameraShake {
};


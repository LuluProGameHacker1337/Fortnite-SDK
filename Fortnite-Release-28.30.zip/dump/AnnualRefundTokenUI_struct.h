// Enum AnnualRefundTokenUI.EFortPurchaseHistoryRefundType
enum class EFortPurchaseHistoryRefundType : uint8 {
	CancelPurchase = 0,
	ReturnTicket = 1,
	TokenlessRefund = 2,
	NonRefundable = 3,
	EFortPurchaseHistoryRefundType_MAX = 4
};

// ScriptStruct AnnualRefundTokenUI.PurchaseHistoryBundleEntry
// Size: 0x20 (Inherited: 0x00)
struct FPurchaseHistoryBundleEntry {
	char pad_0[0x10]; // 0x00(0x10)
	struct FString ID; // 0x10(0x10)
};


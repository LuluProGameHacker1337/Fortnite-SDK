// BlueprintGeneratedClass B_CameraLens_Shadow_Bomb_Loop.B_CameraLens_Shadow_Bomb_Loop_C
// Size: 0x388 (Inherited: 0x380)
struct AB_CameraLens_Shadow_Bomb_Loop_C : AEmitterCameraLensEffectBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)

	void ReceiveBeginPlay(); // Function B_CameraLens_Shadow_Bomb_Loop.B_CameraLens_Shadow_Bomb_Loop_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_B_CameraLens_Shadow_Bomb_Loop(int32_t EntryPoint); // Function B_CameraLens_Shadow_Bomb_Loop.B_CameraLens_Shadow_Bomb_Loop_C.ExecuteUbergraph_B_CameraLens_Shadow_Bomb_Loop // (Final|UbergraphFunction) // @ game+0x3d1d968
};


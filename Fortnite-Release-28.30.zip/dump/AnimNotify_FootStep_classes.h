// BlueprintGeneratedClass AnimNotify_FootStep.AnimNotify_FootStep_C
// Size: 0x78 (Inherited: 0x38)
struct UAnimNotify_FootStep_C : UAnimNotify {
	int32_t FootIndex; // 0x38(0x04)
	char pad_3C[0x4]; // 0x3c(0x04)
	struct FFortPlayerFoleyContextSettings PreviewSettings; // 0x40(0x38)

	void AudioPreview(struct AActor* InActor); // Function AnimNotify_FootStep.AnimNotify_FootStep_C.AudioPreview // (Public|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	bool Received_Notify(struct USkeletalMeshComponent* MeshComp, struct UAnimSequenceBase* Animation, struct FAnimNotifyEventReference& EventReference); // Function AnimNotify_FootStep.AnimNotify_FootStep_C.Received_Notify // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
};


// BlueprintGeneratedClass B_SparksSong_PreviewDisplay.B_SparksSong_PreviewDisplay_C
// Size: 0x310 (Inherited: 0x2a8)
struct AB_SparksSong_PreviewDisplay_C : ASparksSongPreviewActor {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x2a8(0x08)
	struct UBPC_SparksSongPreviewer_C* SongPreviewer; // 0x2b0(0x08)
	struct UPaperSpriteComponent* PaperSprite; // 0x2b8(0x08)
	struct UStaticMeshComponent* SM_AlbumCover; // 0x2c0(0x08)
	struct USceneComponent* Scene; // 0x2c8(0x08)
	struct UMaterialInstanceDynamic* AlbumCoverMID; // 0x2d0(0x08)
	struct UAthenaMusicPackItemDefinition* MyMusicPack; // 0x2d8(0x08)
	struct AFort_Entry_Music_Controller_BP_C* MusicManagerPtr; // 0x2e0(0x08)
	bool CanRetriggerNextMusicPack; // 0x2e8(0x01)
	char pad_2E9[0x7]; // 0x2e9(0x07)
	struct FDataTableRowHandle InputAbandon; // 0x2f0(0x10)
	struct UAudioComponent* CurrentPreviewAudio; // 0x300(0x08)
	struct FTimerHandle DebounceTimerHandle; // 0x308(0x08)

	void PerformSpecialAction(struct FName ActionName); // Function B_SparksSong_PreviewDisplay.B_SparksSong_PreviewDisplay_C.PerformSpecialAction // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void StartSongPreview(); // Function B_SparksSong_PreviewDisplay.B_SparksSong_PreviewDisplay_C.StartSongPreview // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnSongTextureLoaded(struct UTexture2D* CoverArt); // Function B_SparksSong_PreviewDisplay.B_SparksSong_PreviewDisplay_C.OnSongTextureLoaded // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void DebounceEvent(); // Function B_SparksSong_PreviewDisplay.B_SparksSong_PreviewDisplay_C.DebounceEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_B_SparksSong_PreviewDisplay(int32_t EntryPoint); // Function B_SparksSong_PreviewDisplay.B_SparksSong_PreviewDisplay_C.ExecuteUbergraph_B_SparksSong_PreviewDisplay // (Final|UbergraphFunction|HasDefaults) // @ game+0x3d1d968
};


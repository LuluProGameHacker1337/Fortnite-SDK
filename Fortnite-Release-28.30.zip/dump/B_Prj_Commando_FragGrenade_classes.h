// BlueprintGeneratedClass B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C
// Size: 0xd94 (Inherited: 0xaa0)
struct AB_Prj_Commando_FragGrenade_C : AFortProjectileBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xaa0(0x08)
	struct URotatingMovementComponent* RotatingMovement; // 0xaa8(0x08)
	struct UParticleSystemComponent* Fuse_Particle; // 0xab0(0x08)
	struct UStaticMeshComponent* Mesh; // 0xab8(0x08)
	struct UAudioComponent* GrenadeFuse_AudioComponent; // 0xac0(0x08)
	struct UParticleSystemComponent* Effect_Distance; // 0xac8(0x08)
	struct UParticleSystem* P_Explosion; // 0xad0(0x08)
	struct USoundBase* Cue_DistantSound; // 0xad8(0x08)
	struct USoundBase* Cue_CloseSound; // 0xae0(0x08)
	double ExplosionRadius; // 0xae8(0x08)
	int32_t NumberOfBouncesTillExplode; // 0xaf0(0x04)
	int32_t CurrentNumberOfBounces; // 0xaf4(0x04)
	struct USoundBase* Cue_GrenadeFuseSound; // 0xaf8(0x08)
	double BouncePawnAgainstPawnGravityScale; // 0xb00(0x08)
	struct UForceFeedbackEffect* ExplosionForceFeedbackNear; // 0xb08(0x08)
	struct UForceFeedbackEffect* ExplosionForceFeedbackFar; // 0xb10(0x08)
	int32_t MaxClusterGrenades; // 0xb18(0x04)
	struct FGameplayTag EC_ClusterExplosion; // 0xb1c(0x04)
	bool bHasCluster; // 0xb20(0x01)
	char pad_B21[0x7]; // 0xb21(0x07)
	struct AFortProjectileBase* Prj_Cluster; // 0xb28(0x08)
	struct FFortGameplayEffectContainerSpec ClusterContainerSpec; // 0xb30(0xb8)
	bool bHasKeepOut; // 0xbe8(0x01)
	char pad_BE9[0x7]; // 0xbe9(0x07)
	struct FFortGameplayEffectContainerSpec KeepOutContainerSpec; // 0xbf0(0xb8)
	struct AFortAreaOfEffectCloud* AOE_KeepOut; // 0xca8(0x08)
	bool bHasClusterTactical; // 0xcb0(0x01)
	char pad_CB1[0x7]; // 0xcb1(0x07)
	struct FFortGameplayEffectContainerSpec Cluster_Tactical_Container_Spec; // 0xcb8(0xb8)
	struct FGameplayTagContainer TC_ActorTagsThatShouldExplodeOnOverlap; // 0xd70(0x20)
	struct FGameplayTag T_Event_GrenadeExploded; // 0xd90(0x04)

	void SpawnKeepOut(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.SpawnKeepOut // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void SpawnClusters(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.SpawnClusters // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	double CalcGrenadeSpeed(double Angle); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.CalcGrenadeSpeed // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3d1d968
	void OnRep_StoredHit(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.OnRep_StoredHit // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void UserConstructionScript(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveBeginPlay(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void OnStop(struct FHitResult& Hit); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.OnStop // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	void Stop_Rotation(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.Stop_Rotation // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnExploded(struct TArray<struct AActor*>& HitActors, struct TArray<struct FHitResult>& HitResults); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.OnExploded // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveAnyDamage(float Damage, struct UDamageType* DamageType, struct AController* InstigatedBy, struct AActor* DamageCauser); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ReceiveAnyDamage // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void OnBounce(struct FHitResult& Hit); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.OnBounce // (Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	void On Destroy Grenade(struct AActor* DestroyedActor); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.On Destroy Grenade // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Bind Destroy Grenade(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.Bind Destroy Grenade // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Force On Exploded Effects(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.Force On Exploded Effects // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Unbind Destroy Grenade(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.Unbind Destroy Grenade // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void TriggerDoExplsoion(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.TriggerDoExplsoion // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveDestroyed(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ReceiveDestroyed // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void CheckKeepOutAndCluster(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.CheckKeepOutAndCluster // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveActorBeginOverlap(struct AActor* OtherActor); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ReceiveActorBeginOverlap // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void SendExplodedEvent(); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.SendExplodedEvent // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_B_Prj_Commando_FragGrenade(int32_t EntryPoint); // Function B_Prj_Commando_FragGrenade.B_Prj_Commando_FragGrenade_C.ExecuteUbergraph_B_Prj_Commando_FragGrenade // (Final|UbergraphFunction|HasDefaults) // @ game+0x3d1d968
};


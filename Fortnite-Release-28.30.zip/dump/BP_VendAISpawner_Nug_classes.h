// BlueprintGeneratedClass BP_VendAISpawner_Nug.BP_VendAISpawner_Nug_C
// Size: 0x2b8 (Inherited: 0x2b8)
struct ABP_VendAISpawner_Nug_C : ABP_VendAISpawner_Base_C {
};


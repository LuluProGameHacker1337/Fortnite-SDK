// BlueprintGeneratedClass BP_SkydiveSoundLibraryComponent.BP_SkydiveSoundLibraryComponent_C
// Size: 0x1d8 (Inherited: 0x1b8)
struct UBP_SkydiveSoundLibraryComponent_C : UFortSkydiveSoundLibraryComponent {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x1b8(0x08)
	struct FGameplayTag SkydiveEventTag; // 0x1c0(0x04)
	char pad_1C4[0x4]; // 0x1c4(0x04)
	struct TArray<struct UAudioComponent*> Components; // 0x1c8(0x10)

	void OnEventPlayed(struct FGameplayTag InEventName); // Function BP_SkydiveSoundLibraryComponent.BP_SkydiveSoundLibraryComponent_C.OnEventPlayed // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnSoundPlayed(struct FGameplayTag InEventName, struct UAudioComponent* InComponent); // Function BP_SkydiveSoundLibraryComponent.BP_SkydiveSoundLibraryComponent_C.OnSoundPlayed // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnSoundStopped(struct FGameplayTag InEventName, struct UAudioComponent* InComponent, bool& bStopped); // Function BP_SkydiveSoundLibraryComponent.BP_SkydiveSoundLibraryComponent_C.OnSoundStopped // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveBeginPlay(); // Function BP_SkydiveSoundLibraryComponent.BP_SkydiveSoundLibraryComponent_C.ReceiveBeginPlay // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_BP_SkydiveSoundLibraryComponent(int32_t EntryPoint); // Function BP_SkydiveSoundLibraryComponent.BP_SkydiveSoundLibraryComponent_C.ExecuteUbergraph_BP_SkydiveSoundLibraryComponent // (Final|UbergraphFunction) // @ game+0x3d1d968
};


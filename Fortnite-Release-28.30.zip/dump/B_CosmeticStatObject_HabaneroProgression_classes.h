// BlueprintGeneratedClass B_CosmeticStatObject_HabaneroProgression.B_CosmeticStatObject_HabaneroProgression_C
// Size: 0xd8 (Inherited: 0xd8)
struct UB_CosmeticStatObject_HabaneroProgression_C : UFortCosmeticStatObject_HabaneroProgression {
};


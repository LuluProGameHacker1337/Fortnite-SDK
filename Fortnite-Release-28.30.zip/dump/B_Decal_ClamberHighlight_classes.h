// BlueprintGeneratedClass B_Decal_ClamberHighlight.B_Decal_ClamberHighlight_C
// Size: 0x2c0 (Inherited: 0x298)
struct AB_Decal_ClamberHighlight_C : ADecalActor {
	struct UMaterialInstanceDynamic* Decal_MID; // 0x298(0x08)
	struct FLinearColor Color_NotInRange; // 0x2a0(0x10)
	struct FLinearColor Color_InRange; // 0x2b0(0x10)

	void SetIsInRange(bool bInRange?); // Function B_Decal_ClamberHighlight.B_Decal_ClamberHighlight_C.SetIsInRange // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void UserConstructionScript(); // Function B_Decal_ClamberHighlight.B_Decal_ClamberHighlight_C.UserConstructionScript // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
};


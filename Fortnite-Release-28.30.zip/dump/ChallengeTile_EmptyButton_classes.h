// BlueprintGeneratedClass ChallengeTile_EmptyButton.ChallengeTile_EmptyButton_C
// Size: 0x730 (Inherited: 0x730)
struct UChallengeTile_EmptyButton_C : UCommonButtonStyle {
};


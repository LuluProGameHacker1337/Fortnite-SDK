// Class AudioWorldization.AudioWorldizationReflectionProbe
// Size: 0x2e8 (Inherited: 0x290)
struct AAudioWorldizationReflectionProbe : AActor {
	char pad_290[0x8]; // 0x290(0x08)
	struct USubmixSendVolumeComponent* SubmixSends; // 0x298(0x08)
	struct USubmixOverrideVolumeComponent* SubmixEffects; // 0x2a0(0x08)
	struct UAudioGameplayVolumeComponent* AGVComponent; // 0x2a8(0x08)
	char pad_2B0[0x38]; // 0x2b0(0x38)
};

// Class AudioWorldization.AudioWorldizationSendsVolumeComponent
// Size: 0xc8 (Inherited: 0xb0)
struct UAudioWorldizationSendsVolumeComponent : UAudioGameplayVolumeComponentBase {
	struct FName Identifier; // 0xb0(0x04)
	char pad_B4[0x4]; // 0xb4(0x04)
	struct TArray<struct FAudioWorldizationSend> Sends; // 0xb8(0x10)
};

// Class AudioWorldization.AudioWorldizationData
// Size: 0xa8 (Inherited: 0x30)
struct UAudioWorldizationData : UDataAsset {
	struct FAudioWorldizationSettings Settings; // 0x30(0x78)
};

// Class AudioWorldization.AudioWorldizationDefaultSettings
// Size: 0xe8 (Inherited: 0x30)
struct UAudioWorldizationDefaultSettings : UDeveloperSettings {
	struct FAudioWorldizationGlobalSettings GlobalSettings; // 0x30(0x30)
	struct FAudioWorldizationSettings DefaultSettings; // 0x60(0x78)
	struct TArray<struct FSoftObjectPath> ModulationParameters; // 0xd8(0x10)
};

// Class AudioWorldization.AudioWorldizationSubsystem
// Size: 0x1d0 (Inherited: 0x40)
struct UAudioWorldizationSubsystem : UTickableWorldSubsystem {
	struct USoundControlBus* EnclosureBus; // 0x40(0x08)
	struct USoundControlBus* WallDistanceBus; // 0x48(0x08)
	struct USoundControlBus* ListenerAzimuthBus; // 0x50(0x08)
	char pad_58[0x8]; // 0x58(0x08)
	struct FAudioWorldizationSettings CurrentSettings; // 0x60(0x78)
	struct AAudioWorldizationReflectionProbe* VolumeActor; // 0xd8(0x08)
	struct UAudioWorldizationTracePolicyBase* TracePolicy; // 0xe0(0x08)
	struct UAudioWorldizationTraceDirectionPolicyBase* TraceDirectionPolicy; // 0xe8(0x08)
	char pad_F0[0xb0]; // 0xf0(0xb0)
	struct TArray<struct FAudioWorldizationSettings> SettingsStack; // 0x1a0(0x10)
	struct TArray<struct USoundControlBus*> QuadrantEnclosureBuses; // 0x1b0(0x10)
	struct TArray<struct USoundControlBus*> QuadrantWallDistanceBuses; // 0x1c0(0x10)

	void SetWorldizationSettings(struct FAudioWorldizationSettings& InSettings); // Function AudioWorldization.AudioWorldizationSubsystem.SetWorldizationSettings // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x80089a4
	void SetEnabled(bool bNewEnabled); // Function AudioWorldization.AudioWorldizationSubsystem.SetEnabled // (Final|Native|Public|BlueprintCallable) // @ game+0x8008924
	void SetDefaultSettings(); // Function AudioWorldization.AudioWorldizationSubsystem.SetDefaultSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x8008910
	void RemoveWorldizationSettings(struct FName InIdentifier); // Function AudioWorldization.AudioWorldizationSubsystem.RemoveWorldizationSettings // (Final|Native|Public|BlueprintCallable) // @ game+0x8008890
	void RemoveEffectSendOverride(struct FName InIdentifier); // Function AudioWorldization.AudioWorldizationSubsystem.RemoveEffectSendOverride // (Final|Native|Public|BlueprintCallable) // @ game+0x8008890
	void OverrideEffectSends(struct FName InIdentifier, struct TArray<struct FAudioWorldizationSend>& InSends); // Function AudioWorldization.AudioWorldizationSubsystem.OverrideEffectSends // (Final|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x80087b4
	float GetWallDistanceRatio(); // Function AudioWorldization.AudioWorldizationSubsystem.GetWallDistanceRatio // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x800878c
	float GetEnclosureFactor(); // Function AudioWorldization.AudioWorldizationSubsystem.GetEnclosureFactor // (Final|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x8008764
};

// Class AudioWorldization.AudioWorldizationTraceDirectionPolicyBase
// Size: 0x30 (Inherited: 0x28)
struct UAudioWorldizationTraceDirectionPolicyBase : UObject {
	char pad_28[0x8]; // 0x28(0x08)
};

// Class AudioWorldization.AudioWorldizationTraceDirectionPolicyDefault
// Size: 0x30 (Inherited: 0x30)
struct UAudioWorldizationTraceDirectionPolicyDefault : UAudioWorldizationTraceDirectionPolicyBase {
};

// Class AudioWorldization.AudioWorldizationTracePolicyBase
// Size: 0x28 (Inherited: 0x28)
struct UAudioWorldizationTracePolicyBase : UObject {
};

// Class AudioWorldization.AudioWorldizationTracePolicyDefault
// Size: 0x28 (Inherited: 0x28)
struct UAudioWorldizationTracePolicyDefault : UAudioWorldizationTracePolicyBase {
};

// Class AudioWorldization.AudioWorldizationVolumeComponent
// Size: 0xb8 (Inherited: 0xb0)
struct UAudioWorldizationVolumeComponent : UAudioGameplayVolumeComponentBase {
	struct UAudioWorldizationData* Settings; // 0xb0(0x08)
};

// Class AudioWorldization.GameFeatureAction_SetAudioWorldizationEffectSends
// Size: 0x90 (Inherited: 0x28)
struct UGameFeatureAction_SetAudioWorldizationEffectSends : UGameFeatureAction {
	struct FName Identifier; // 0x28(0x04)
	char pad_2C[0x4]; // 0x2c(0x04)
	struct TArray<struct FAudioWorldizationSend> Sends; // 0x30(0x10)
	char pad_40[0x50]; // 0x40(0x50)
};

// Class AudioWorldization.GameFeatureAction_SetAudioWorldizationSettings
// Size: 0xf0 (Inherited: 0x28)
struct UGameFeatureAction_SetAudioWorldizationSettings : UGameFeatureAction {
	struct FAudioWorldizationSettings Settings; // 0x28(0x78)
	char pad_A0[0x50]; // 0xa0(0x50)
};


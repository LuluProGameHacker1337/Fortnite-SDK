// BlueprintGeneratedClass B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C
// Size: 0x1190 (Inherited: 0xff0)
struct AB_Athena_Zipline_Ascender_C : AFortAscenderZipline {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xff0(0x08)
	struct UAudioParameterComponent* AudioParameter; // 0xff8(0x08)
	struct UCapsuleComponent* Capsule; // 0x1000(0x08)
	struct UStaticMeshComponent* Ascender_End_Cap; // 0x1008(0x08)
	struct UAudioComponent* PoleMotorSFX; // 0x1010(0x08)
	struct UNiagaraComponent* HandleVFX; // 0x1018(0x08)
	struct UNiagaraComponent* PoleMotorVFX; // 0x1020(0x08)
	struct UAudioComponent* HandleAscendingSFX; // 0x1028(0x08)
	struct UAudioComponent* HandleDescendingSFX; // 0x1030(0x08)
	struct USphereComponent* HandleInteractVolume; // 0x1038(0x08)
	struct UStaticMeshComponent* Handle; // 0x1040(0x08)
	struct UStaticMeshComponent* Top; // 0x1048(0x08)
	struct FScalableFloat Hotfix; // 0x1050(0x28)
	struct USoundBase* StartHandleSound; // 0x1078(0x08)
	struct USoundBase* StopHandleSound; // 0x1080(0x08)
	struct USoundBase* StopPoleMotorSoundSkid; // 0x1088(0x08)
	struct UMaterialInterface* SplineMeshMaterialOverride; // 0x1090(0x08)
	struct UNiagaraSystem* AscendingHandleVFX; // 0x1098(0x08)
	struct UNiagaraSystem* DescendingHandleVFX; // 0x10a0(0x08)
	struct UMaterialInterface* SplineThickenMeshMaterialOverride; // 0x10a8(0x08)
	double MaxWobbleAnimationLength; // 0x10b0(0x08)
	double LastWobbleActivationTime; // 0x10b8(0x08)
	double TilingDivisor; // 0x10c0(0x08)
	struct FVector HandleAnimOffset; // 0x10c8(0x18)
	struct FVector SlideAnimOffset; // 0x10e0(0x18)
	struct USoundBase* PlayerGrabBeginDecentSound; // 0x10f8(0x08)
	struct UAudioComponent* HandleStart; // 0x1100(0x08)
	struct FVector EndCapRelativeScale; // 0x1108(0x18)
	struct UGameplayEffect* StructureDamageGE; // 0x1120(0x08)
	struct FTimerHandle AudioVisualizerHandle; // 0x1128(0x08)
	struct TArray<struct AFortPlayerPawn*> PlayersOnAscender; // 0x1130(0x10)
	struct USoundBase* TravelSound; // 0x1140(0x08)
	bool ShouldPlayWhoosh; // 0x1148(0x01)
	char pad_1149[0x7]; // 0x1149(0x07)
	struct USoundBase* AscendWhooshSound; // 0x1150(0x08)
	struct AFortPlayerPawn* PlayerPawn; // 0x1158(0x08)
	struct FTimerHandle WhooshHandle; // 0x1160(0x08)
	struct FGameplayTag LinkToDestroyedGC; // 0x1168(0x04)
	bool BeDestroy; // 0x116c(0x01)
	char pad_116D[0x3]; // 0x116d(0x03)
	struct APlayerState* PlayerStateUsingHandleComponent; // 0x1170(0x08)
	struct TArray<struct FAudioParameter> AudioParameters; // 0x1178(0x10)
	struct UAudioParameterComponent* ParameterComponent; // 0x1188(0x08)

	struct TArray<enum class EFortTeamAffiliation> GetAffiliationsToShowFor(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetAffiliationsToShowFor // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	bool ShouldShowSoundIndicator(struct AFortPlayerController* PlayerController); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ShouldShowSoundIndicator // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	enum class EDynamicDestructionResourceType GetDynamicDestructionResourceType(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetDynamicDestructionResourceType // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	void GetDynamicDestructionStaticMeshComponents(struct TArray<struct UStaticMeshComponent*>& OutFullFXStaticMeshComponents, struct TArray<struct UStaticMeshComponent*>& OutVisibilityOnlyStaticMeshComponents, struct TArray<struct UStaticMeshComponent*>& OutShadowProxyStaticMeshComponents); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetDynamicDestructionStaticMeshComponents // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	bool ShouldUseDynamicDestructionNiagaraSystem(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ShouldUseDynamicDestructionNiagaraSystem // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	bool ShouldUseDynamicDestructionMaterial(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ShouldUseDynamicDestructionMaterial // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	void OnRep_BeDestroy(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnRep_BeDestroy // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BlueprintCanInteract // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	bool CanBeginZiplining(struct AFortPlayerPawn* InteractingPawn, struct UPrimitiveComponent* InteractComponent); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.CanBeginZiplining // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	void LocalOnFailedInteract(struct AFortPlayerPawn* InteractingPawn); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.LocalOnFailedInteract // (Event|Public|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	void GetBoundsComponents(struct AActor* SelfActor, struct TArray<struct USceneComponent*>& OutComponents); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetBoundsComponents // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	void ApplyStructureDamage(struct ABuildingSMActor* BuildingActor, struct AActor* DamageSource); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ApplyStructureDamage // (Event|Public|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	void AttachCapToEndOfSplineMesh(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.AttachCapToEndOfSplineMesh // (Public|HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	bool AttemptOverrideZiplineSocketOffset(struct AFortPlayerPawn* InteractingPawn, struct UPrimitiveComponent* InteractComponent, struct FVector& BaseSocketOffset, struct FVector& OutSocketOffset); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.AttemptOverrideZiplineSocketOffset // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	void CalculateLaunchVelocity(struct AActor* PlayerPawn, struct FVector& LaunchVelocity); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.CalculateLaunchVelocity // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3d1d968
	void SetCableTilingBySplineLength(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.SetCableTilingBySplineLength // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void DeactivateCableWobble(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.DeactivateCableWobble // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ActivateCableWobble(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ActivateCableWobble // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void HotfixEnabled(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.HotfixEnabled // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	struct UPrimitiveComponent* GetTopComponent(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetTopComponent // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	struct UPrimitiveComponent* GetHandleComponent(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetHandleComponent // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	struct UPrimitiveComponent* GetInteractComponentOverride(struct AFortPlayerPawn* InteractingPawn, struct UPrimitiveComponent* InteractComponent); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetInteractComponentOverride // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	bool PawnIsInHandleRange(struct AFortPawn* Pawn); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.PawnIsInHandleRange // (Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	int32_t GetLastSplinePointIndex(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.GetLastSplinePointIndex // (Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure) // @ game+0x3d1d968
	void UserConstructionScript(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnReady_93837FC44A18F6AE57D3478CC43A98AB(struct AFortGameStateAthena* GameState, struct UFortPlaylist* Playlist, struct FGameplayTagContainer& PlaylistContextTags); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnReady_93837FC44A18F6AE57D3478CC43A98AB // (HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveBeginPlay(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void BP_HandlePlayerStartedUsingHandle(struct AFortPlayerPawn* Player); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandlePlayerStartedUsingHandle // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void BP_HandlePlayerStoppedUsingHandle(struct AFortPlayerPawn* Player); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandlePlayerStoppedUsingHandle // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void BP_HandleStartedLoweringCable(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleStartedLoweringCable // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void BP_HandleStartedLoweringHandle(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleStartedLoweringHandle // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void BP_HandleStoppedLoweringCable(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleStoppedLoweringCable // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void BP_HandleStoppedLoweringHandle(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleStoppedLoweringHandle // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void OnZipliningStarted(struct AFortPlayerPawn* InteractingPawn, struct UPrimitiveComponent* InteractComponent); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnZipliningStarted // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void PlayerDescendingStarted(struct AFortPlayerPawn* Sliding Player); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.PlayerDescendingStarted // (Net|NetMulticast|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void BP_HandleUpdatedLoweringCable(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.BP_HandleUpdatedLoweringCable // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void OnZipliningStopped(struct AFortPlayerPawn* InteractingPawn, struct UPrimitiveComponent* InteractComponent, float ZiplineUsageDuration); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnZipliningStopped // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ShouldPlayWhooshTimer(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ShouldPlayWhooshTimer // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnAscenderSetupComplete_Event(); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.OnAscenderSetupComplete_Event // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void HandleLinkedActorDestroyed(struct AActor* DamageCauser); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.HandleLinkedActorDestroyed // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_B_Athena_Zipline_Ascender(int32_t EntryPoint); // Function B_Athena_Zipline_Ascender.B_Athena_Zipline_Ascender_C.ExecuteUbergraph_B_Athena_Zipline_Ascender // (Final|UbergraphFunction|HasDefaults) // @ game+0x3d1d968
};


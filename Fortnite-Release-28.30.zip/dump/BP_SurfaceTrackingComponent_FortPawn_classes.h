// BlueprintGeneratedClass BP_SurfaceTrackingComponent_FortPawn.BP_SurfaceTrackingComponent_FortPawn_C
// Size: 0x188 (Inherited: 0x188)
struct UBP_SurfaceTrackingComponent_FortPawn_C : UFortSurfaceTrackingComponent {
};


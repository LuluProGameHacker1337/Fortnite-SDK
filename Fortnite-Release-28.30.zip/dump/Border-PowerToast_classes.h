// BlueprintGeneratedClass Border-PowerToast.Border-PowerToast_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-PowerToast_C : UCommonBorderStyle {
};


// BlueprintGeneratedClass BasicNotification.BasicNotification_C
// Size: 0x100 (Inherited: 0x100)
struct UBasicNotification_C : UFortUINotification {
};


// BlueprintGeneratedClass BBE_Rock_ToggleRadio.BBE_Rock_ToggleRadio_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_Rock_ToggleRadio_C : UFortMobileActionButtonBehaviorExtension {
};


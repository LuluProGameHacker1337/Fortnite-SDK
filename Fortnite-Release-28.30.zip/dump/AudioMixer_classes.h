// Class AudioMixer.AudioBusSubsystem
// Size: 0x90 (Inherited: 0x30)
struct UAudioBusSubsystem : UAudioEngineSubsystem {
	char pad_30[0x60]; // 0x30(0x60)
};

// Class AudioMixer.AudioDeviceNotificationSubsystem
// Size: 0x128 (Inherited: 0x30)
struct UAudioDeviceNotificationSubsystem : UEngineSubsystem {
	char pad_30[0x8]; // 0x30(0x08)
	struct FMulticastInlineDelegate DefaultCaptureDeviceChanged; // 0x38(0x10)
	char pad_48[0x18]; // 0x48(0x18)
	struct FMulticastInlineDelegate DefaultRenderDeviceChanged; // 0x60(0x10)
	char pad_70[0x18]; // 0x70(0x18)
	struct FMulticastInlineDelegate DeviceAdded; // 0x88(0x10)
	char pad_98[0x18]; // 0x98(0x18)
	struct FMulticastInlineDelegate DeviceRemoved; // 0xb0(0x10)
	char pad_C0[0x18]; // 0xc0(0x18)
	struct FMulticastInlineDelegate DeviceStateChanged; // 0xd8(0x10)
	char pad_E8[0x18]; // 0xe8(0x18)
	struct FMulticastInlineDelegate DeviceSwitched; // 0x100(0x10)
	char pad_110[0x18]; // 0x110(0x18)
};

// Class AudioMixer.AudioMixerBlueprintLibrary
// Size: 0x28 (Inherited: 0x28)
struct UAudioMixerBlueprintLibrary : UBlueprintFunctionLibrary {

	void UnregisterAudioBusFromSubmix(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct UAudioBus* AudioBus); // Function AudioMixer.AudioMixerBlueprintLibrary.UnregisterAudioBusFromSubmix // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a9058
	float TrimAudioCache(float InMegabytesToFree); // Function AudioMixer.AudioMixerBlueprintLibrary.TrimAudioCache // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a8fd4
	void SwapAudioOutputDevice(struct UObject* WorldContextObject, struct FString NewDeviceId, struct FDelegate& OnCompletedDeviceSwap); // Function AudioMixer.AudioMixerBlueprintLibrary.SwapAudioOutputDevice // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x60a889c
	struct USoundWave* StopRecordingOutput(struct UObject* WorldContextObject, enum class EAudioRecordingExportType ExportType, struct FString Name, struct FString Path, struct USoundSubmix* SubmixToRecord, struct USoundWave* ExistingSoundWaveToOverwrite); // Function AudioMixer.AudioMixerBlueprintLibrary.StopRecordingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a80c4
	void StopAudioBus(struct UObject* WorldContextObject, struct UAudioBus* AudioBus); // Function AudioMixer.AudioMixerBlueprintLibrary.StopAudioBus // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a7fb0
	void StopAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToStopAnalyzing); // Function AudioMixer.AudioMixerBlueprintLibrary.StopAnalyzingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a7ec4
	void StartRecordingOutput(struct UObject* WorldContextObject, float ExpectedDuration, struct USoundSubmix* SubmixToRecord); // Function AudioMixer.AudioMixerBlueprintLibrary.StartRecordingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a7dcc
	void StartAudioBus(struct UObject* WorldContextObject, struct UAudioBus* AudioBus); // Function AudioMixer.AudioMixerBlueprintLibrary.StartAudioBus // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a7cac
	void StartAnalyzingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToAnalyze, enum class EFFTSize FFTSize, enum class EFFTPeakInterpolationMethod InterpolationMethod, enum class EFFTWindowType WindowType, float HopSize, enum class EAudioSpectrumType SpectrumType); // Function AudioMixer.AudioMixerBlueprintLibrary.StartAnalyzingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a7aa4
	void SetSubmixEffectChainOverride(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct TArray<struct USoundEffectSubmixPreset*> SubmixEffectPresetChain, float FadeTimeSec); // Function AudioMixer.AudioMixerBlueprintLibrary.SetSubmixEffectChainOverride // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a7314
	void SetBypassSourceEffectChainEntry(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex, bool bBypassed); // Function AudioMixer.AudioMixerBlueprintLibrary.SetBypassSourceEffectChainEntry // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a712c
	void ResumeRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Function AudioMixer.AudioMixerBlueprintLibrary.ResumeRecordingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a7078
	void ReplaceSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6eac
	void ReplaceSoundEffectSubmix(struct UObject* WorldContextObject, struct USoundSubmix* InSoundSubmix, int32_t SubmixChainIndex, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.ReplaceSoundEffectSubmix // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6eac
	void RemoveSubmixEffectPresetAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPresetAtIndex // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6db4
	void RemoveSubmixEffectPreset(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectPreset // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6cbc
	void RemoveSubmixEffectAtIndex(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, int32_t SubmixChainIndex); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffectAtIndex // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6db4
	void RemoveSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6cbc
	void RemoveSourceEffectFromPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, int32_t EntryIndex); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveSourceEffectFromPresetChain // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6ae8
	void RemoveMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.RemoveMasterSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a69d4
	void RegisterAudioBusToSubmix(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct UAudioBus* AudioBus); // Function AudioMixer.AudioMixerBlueprintLibrary.RegisterAudioBusToSubmix // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a68dc
	void PrimeSoundForPlayback(struct USoundWave* SoundWave, struct FDelegate OnLoadCompletion); // Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundForPlayback // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6754
	void PrimeSoundCueForPlayback(struct USoundCue* SoundCue); // Function AudioMixer.AudioMixerBlueprintLibrary.PrimeSoundCueForPlayback // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a66e8
	void PauseRecordingOutput(struct UObject* WorldContextObject, struct USoundSubmix* SubmixToPause); // Function AudioMixer.AudioMixerBlueprintLibrary.PauseRecordingOutput // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6634
	struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> MakePresetSpectralAnalysisBandSettings(enum class EAudioSpectrumBandPresetType InBandPresetType, int32_t InNumBands, int32_t InAttackTimeMsec, int32_t InReleaseTimeMsec); // Function AudioMixer.AudioMixerBlueprintLibrary.MakePresetSpectralAnalysisBandSettings // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x60a64d4
	struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> MakeMusicalSpectralAnalysisBandSettings(int32_t InNumSemitones, enum class EMusicalNoteName InStartingMusicalNote, int32_t InStartingOctave, int32_t InAttackTimeMsec, int32_t InReleaseTimeMsec); // Function AudioMixer.AudioMixerBlueprintLibrary.MakeMusicalSpectralAnalysisBandSettings // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x60a6330
	struct TArray<struct FSoundSubmixSpectralAnalysisBandSettings> MakeFullSpectrumSpectralAnalysisBandSettings(int32_t InNumBands, float InMinimumFrequency, float InMaximumFrequency, int32_t InAttackTimeMsec, int32_t InReleaseTimeMsec); // Function AudioMixer.AudioMixerBlueprintLibrary.MakeFullSpectrumSpectralAnalysisBandSettings // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable|BlueprintPure) // @ game+0x60a618c
	bool IsAudioBusActive(struct UObject* WorldContextObject, struct UAudioBus* AudioBus); // Function AudioMixer.AudioMixerBlueprintLibrary.IsAudioBusActive // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a6078
	void GetPhaseForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Phases, struct USoundSubmix* SubmixToAnalyze); // Function AudioMixer.AudioMixerBlueprintLibrary.GetPhaseForFrequencies // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x60a5dcc
	int32_t GetNumberOfEntriesInSourceEffectChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain); // Function AudioMixer.AudioMixerBlueprintLibrary.GetNumberOfEntriesInSourceEffectChain // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a5cb0
	void GetMagnitudeForFrequencies(struct UObject* WorldContextObject, struct TArray<float>& Frequencies, struct TArray<float>& Magnitudes, struct USoundSubmix* SubmixToAnalyze); // Function AudioMixer.AudioMixerBlueprintLibrary.GetMagnitudeForFrequencies // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x60a5a04
	void GetCurrentAudioOutputDeviceName(struct UObject* WorldContextObject, struct FDelegate& OnObtainCurrentDeviceEvent); // Function AudioMixer.AudioMixerBlueprintLibrary.GetCurrentAudioOutputDeviceName // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x60a592c
	void GetAvailableAudioOutputDevices(struct UObject* WorldContextObject, struct FDelegate& OnObtainDevicesEvent); // Function AudioMixer.AudioMixerBlueprintLibrary.GetAvailableAudioOutputDevices // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable) // @ game+0x60a5854
	struct FString Conv_AudioOutputDeviceInfoToString(struct FAudioOutputDeviceInfo& Info); // Function AudioMixer.AudioMixerBlueprintLibrary.Conv_AudioOutputDeviceInfoToString // (Final|RequiredAPI|Native|Static|Public|HasOutParms|BlueprintCallable|BlueprintPure) // @ game+0x60a579c
	void ClearSubmixEffects(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix); // Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffects // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a56dc
	void ClearSubmixEffectChainOverride(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, float FadeTimeSec); // Function AudioMixer.AudioMixerBlueprintLibrary.ClearSubmixEffectChainOverride // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a55e4
	void ClearMasterSubmixEffects(struct UObject* WorldContextObject); // Function AudioMixer.AudioMixerBlueprintLibrary.ClearMasterSubmixEffects // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a5548
	int32_t AddSubmixEffect(struct UObject* WorldContextObject, struct USoundSubmix* SoundSubmix, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.AddSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a53b4
	void AddSourceEffectToPresetChain(struct UObject* WorldContextObject, struct USoundEffectSourcePresetChain* PresetChain, struct FSourceEffectChainEntry Entry); // Function AudioMixer.AudioMixerBlueprintLibrary.AddSourceEffectToPresetChain // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a512c
	void AddMasterSubmixEffect(struct UObject* WorldContextObject, struct USoundEffectSubmixPreset* SubmixEffectPreset); // Function AudioMixer.AudioMixerBlueprintLibrary.AddMasterSubmixEffect // (Final|RequiredAPI|Native|Static|Public|BlueprintCallable) // @ game+0x60a4f7c
};

// Class AudioMixer.SynthSound
// Size: 0x490 (Inherited: 0x470)
struct USynthSound : USoundWaveProcedural {
	struct TWeakObjectPtr<struct USynthComponent> OwningSynthComponent; // 0x470(0x08)
	char pad_478[0x18]; // 0x478(0x18)
};

// Class AudioMixer.SynthComponent
// Size: 0x880 (Inherited: 0x220)
struct USynthComponent : USceneComponent {
	char bAutoDestroy : 1; // 0x220(0x01)
	char bStopWhenOwnerDestroyed : 1; // 0x220(0x01)
	char bAllowSpatialization : 1; // 0x220(0x01)
	char bOverrideAttenuation : 1; // 0x220(0x01)
	char pad_220_4 : 4; // 0x220(0x01)
	char pad_221[0x3]; // 0x221(0x03)
	char bEnableBusSends : 1; // 0x224(0x01)
	char bEnableBaseSubmix : 1; // 0x224(0x01)
	char bEnableSubmixSends : 1; // 0x224(0x01)
	char pad_224_3 : 5; // 0x224(0x01)
	char pad_225[0x3]; // 0x225(0x03)
	struct USoundAttenuation* AttenuationSettings; // 0x228(0x08)
	struct FSoundAttenuationSettings AttenuationOverrides; // 0x230(0x3d0)
	struct USoundConcurrency* ConcurrencySettings; // 0x600(0x08)
	struct TSet<struct USoundConcurrency*> ConcurrencySet; // 0x608(0x50)
	struct FSoundModulationDefaultRoutingSettings ModulationRouting; // 0x658(0x168)
	struct USoundClass* SoundClass; // 0x7c0(0x08)
	struct USoundEffectSourcePresetChain* SourceEffectChain; // 0x7c8(0x08)
	struct USoundSubmixBase* SoundSubmix; // 0x7d0(0x08)
	struct TArray<struct FSoundSubmixSendInfo> SoundSubmixSends; // 0x7d8(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> BusSends; // 0x7e8(0x10)
	struct TArray<struct FSoundSourceBusSendInfo> PreEffectBusSends; // 0x7f8(0x10)
	char bIsUISound : 1; // 0x808(0x01)
	char bIsPreviewSound : 1; // 0x808(0x01)
	char pad_808_2 : 6; // 0x808(0x01)
	char pad_809[0x3]; // 0x809(0x03)
	int32_t EnvelopeFollowerAttackTime; // 0x80c(0x04)
	int32_t EnvelopeFollowerReleaseTime; // 0x810(0x04)
	char pad_814[0x4]; // 0x814(0x04)
	struct FMulticastInlineDelegate OnAudioEnvelopeValue; // 0x818(0x10)
	char pad_828[0x20]; // 0x828(0x20)
	struct USynthSound* Synth; // 0x848(0x08)
	struct UAudioComponent* AudioComponent; // 0x850(0x08)
	char pad_858[0x28]; // 0x858(0x28)

	void Stop(); // Function AudioMixer.SynthComponent.Stop // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60bace8
	void Start(); // Function AudioMixer.SynthComponent.Start // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x252077c
	void SetVolumeMultiplier(float VolumeMultiplier); // Function AudioMixer.SynthComponent.SetVolumeMultiplier // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2e05a74
	void SetSubmixSend(struct USoundSubmixBase* Submix, float SendLevel); // Function AudioMixer.SynthComponent.SetSubmixSend // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60ba36c
	void SetSourceBusSendPreEffect(struct USoundSourceBus* SoundSourceBus, float SourceBusSendLevel); // Function AudioMixer.SynthComponent.SetSourceBusSendPreEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60ba2a4
	void SetSourceBusSendPostEffect(struct USoundSourceBus* SoundSourceBus, float SourceBusSendLevel); // Function AudioMixer.SynthComponent.SetSourceBusSendPostEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60ba1dc
	void SetOutputToBusOnly(bool bInOutputToBusOnly); // Function AudioMixer.SynthComponent.SetOutputToBusOnly // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b9478
	void SetModulationRouting(struct TSet<struct USoundModulatorBase*>& Modulators, enum class EModulationDestination Destination, enum class EModulationRouting RoutingMethod); // Function AudioMixer.SynthComponent.SetModulationRouting // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b9188
	void SetLowPassFilterFrequency(float InLowPassFilterFrequency); // Function AudioMixer.SynthComponent.SetLowPassFilterFrequency // (RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b8e4c
	void SetLowPassFilterEnabled(bool InLowPassFilterEnabled); // Function AudioMixer.SynthComponent.SetLowPassFilterEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b8dc8
	void SetAudioBusSendPreEffect(struct UAudioBus* AudioBus, float AudioBusSendLevel); // Function AudioMixer.SynthComponent.SetAudioBusSendPreEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b8970
	void SetAudioBusSendPostEffect(struct UAudioBus* AudioBus, float AudioBusSendLevel); // Function AudioMixer.SynthComponent.SetAudioBusSendPostEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b88a8
	bool IsPlaying(); // Function AudioMixer.SynthComponent.IsPlaying // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60b7f50
	struct TSet<struct USoundModulatorBase*> GetModulators(enum class EModulationDestination Destination); // Function AudioMixer.SynthComponent.GetModulators // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure) // @ game+0x60b7974
	void FadeOut(float FadeOutDuration, float FadeVolumeLevel, enum class EAudioFaderCurve FadeCurve); // Function AudioMixer.SynthComponent.FadeOut // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x1b2cef0
	void FadeIn(float FadeInDuration, float FadeVolumeLevel, float StartTime, enum class EAudioFaderCurve FadeCurve); // Function AudioMixer.SynthComponent.FadeIn // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x60b6cf0
	void AdjustVolume(float AdjustVolumeDuration, float AdjustVolumeLevel, enum class EAudioFaderCurve FadeCurve); // Function AudioMixer.SynthComponent.AdjustVolume // (Final|RequiredAPI|Native|Public|BlueprintCallable|Const) // @ game+0x60b63f8
};

// Class AudioMixer.SubmixEffectDynamicsProcessorPreset
// Size: 0x150 (Inherited: 0x68)
struct USubmixEffectDynamicsProcessorPreset : USoundEffectSubmixPreset {
	char pad_68[0x88]; // 0x68(0x88)
	struct FSubmixEffectDynamicsProcessorSettings Settings; // 0xf0(0x60)

	void SetSettings(struct FSubmixEffectDynamicsProcessorSettings& Settings); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b97b0
	void SetExternalSubmix(struct USoundSubmix* Submix); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetExternalSubmix // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b8cf0
	void SetAudioBus(struct UAudioBus* AudioBus); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.SetAudioBus // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b87c8
	void ResetKey(); // Function AudioMixer.SubmixEffectDynamicsProcessorPreset.ResetKey // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b8374
};

// Class AudioMixer.SubmixEffectSubmixEQPreset
// Size: 0xb0 (Inherited: 0x68)
struct USubmixEffectSubmixEQPreset : USoundEffectSubmixPreset {
	char pad_68[0x38]; // 0x68(0x38)
	struct FSubmixEffectSubmixEQSettings Settings; // 0xa0(0x10)

	void SetSettings(struct FSubmixEffectSubmixEQSettings& InSettings); // Function AudioMixer.SubmixEffectSubmixEQPreset.SetSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b9988
};

// Class AudioMixer.SubmixEffectReverbPreset
// Size: 0x110 (Inherited: 0x68)
struct USubmixEffectReverbPreset : USoundEffectSubmixPreset {
	char pad_68[0x68]; // 0x68(0x68)
	struct FSubmixEffectReverbSettings Settings; // 0xd0(0x40)

	void SetSettingsWithReverbEffect(struct UReverbEffect* InReverbEffect, float WetLevel, float DryLevel); // Function AudioMixer.SubmixEffectReverbPreset.SetSettingsWithReverbEffect // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60ba048
	void SetSettings(struct FSubmixEffectReverbSettings& InSettings); // Function AudioMixer.SubmixEffectReverbPreset.SetSettings // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b98a8
};

// Class AudioMixer.AudioGenerator
// Size: 0xa8 (Inherited: 0x28)
struct UAudioGenerator : UObject {
	char pad_28[0x80]; // 0x28(0x80)
};

// Class AudioMixer.QuartzClockHandle
// Size: 0x1f0 (Inherited: 0x28)
struct UQuartzClockHandle : UObject {
	char pad_28[0x1c8]; // 0x28(0x1c8)

	void UnsubscribeFromTimeDivision(struct UObject* WorldContextObject, enum class EQuartzCommandQuantization InQuantizationBoundary, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.UnsubscribeFromTimeDivision // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60bb178
	void UnsubscribeFromAllTimeDivisions(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.UnsubscribeFromAllTimeDivisions // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60bb0ac
	void SubscribeToQuantizationEvent(struct UObject* WorldContextObject, enum class EQuartzCommandQuantization InQuantizationBoundary, struct FDelegate& OnQuantizationEvent, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.SubscribeToQuantizationEvent // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60baf38
	void SubscribeToAllQuantizationEvents(struct UObject* WorldContextObject, struct FDelegate& OnQuantizationEvent, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.SubscribeToAllQuantizationEvents // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60bae0c
	void StopClock(struct UObject* WorldContextObject, bool CancelPendingEvents, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.StopClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60bacfc
	void StartOtherClock(struct UObject* WorldContextObject, struct FName OtherClockName, struct FQuartzQuantizationBoundary InQuantizationBoundary, struct FDelegate& InDelegate); // Function AudioMixer.QuartzClockHandle.StartOtherClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60baa70
	void StartClock(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.StartClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60ba9a0
	void SetTicksPerSecond(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float TicksPerSecond); // Function AudioMixer.QuartzClockHandle.SetTicksPerSecond // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60ba6e8
	void SetThirtySecondNotesPerMinute(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float ThirtySecondsNotesPerMinute); // Function AudioMixer.QuartzClockHandle.SetThirtySecondNotesPerMinute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60ba430
	void SetSecondsPerTick(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float SecondsPerTick); // Function AudioMixer.QuartzClockHandle.SetSecondsPerTick // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b94f8
	void SetMillisecondsPerTick(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float MillisecondsPerTick); // Function AudioMixer.QuartzClockHandle.SetMillisecondsPerTick // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b8ed0
	void SetBeatsPerMinute(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary& QuantizationBoundary, struct FDelegate& Delegate, struct UQuartzClockHandle*& ClockHandle, float BeatsPerMinute); // Function AudioMixer.QuartzClockHandle.SetBeatsPerMinute // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b8a38
	void ResumeClock(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.ResumeClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b86fc
	void ResetTransportQuantized(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary InQuantizationBoundary, struct FDelegate& InDelegate, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.ResetTransportQuantized // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b846c
	void ResetTransport(struct UObject* WorldContextObject, struct FDelegate& InDelegate); // Function AudioMixer.QuartzClockHandle.ResetTransport // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b8388
	void PauseClock(struct UObject* WorldContextObject, struct UQuartzClockHandle*& ClockHandle); // Function AudioMixer.QuartzClockHandle.PauseClock // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b82a8
	void NotifyOnQuantizationBoundary(struct UObject* WorldContextObject, struct FQuartzQuantizationBoundary InQuantizationBoundary, struct FDelegate& InDelegate, float InMsOffset); // Function AudioMixer.QuartzClockHandle.NotifyOnQuantizationBoundary // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b7f74
	bool IsClockRunning(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.IsClockRunning // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7ddc
	float GetTicksPerSecond(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetTicksPerSecond // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60b7d50
	float GetThirtySecondNotesPerMinute(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetThirtySecondNotesPerMinute // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60b7cc4
	float GetSecondsPerTick(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetSecondsPerTick // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60b7c38
	float GetMillisecondsPerTick(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetMillisecondsPerTick // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60b78e8
	float GetEstimatedRunTime(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetEstimatedRunTime // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7674
	float GetDurationOfQuantizationTypeInSeconds(struct UObject* WorldContextObject, enum class EQuartzCommandQuantization& QuantizationType, float Multiplier); // Function AudioMixer.QuartzClockHandle.GetDurationOfQuantizationTypeInSeconds // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b71dc
	struct FQuartzTransportTimeStamp GetCurrentTimestamp(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetCurrentTimestamp // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7144
	float GetBeatsPerMinute(struct UObject* WorldContextObject); // Function AudioMixer.QuartzClockHandle.GetBeatsPerMinute // (Final|RequiredAPI|Native|Public|BlueprintCallable|BlueprintPure|Const) // @ game+0x60b6fb4
	float GetBeatProgressPercent(enum class EQuartzCommandQuantization QuantizationBoundary, float PhaseOffset, float MsOffset); // Function AudioMixer.QuartzClockHandle.GetBeatProgressPercent // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b6eb8
};

// Class AudioMixer.QuartzSubsystem
// Size: 0x60 (Inherited: 0x40)
struct UQuartzSubsystem : UTickableWorldSubsystem {
	char pad_40[0x20]; // 0x40(0x20)

	bool IsQuartzEnabled(); // Function AudioMixer.QuartzSubsystem.IsQuartzEnabled // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x2d64ed4
	bool IsClockRunning(struct UObject* WorldContextObject, struct FName ClockName); // Function AudioMixer.QuartzSubsystem.IsClockRunning // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7e68
	float GetRoundTripMinLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetRoundTripMinLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7b90
	float GetRoundTripMaxLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetRoundTripMaxLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7b00
	float GetRoundTripAverageLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetRoundTripAverageLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7a70
	struct UQuartzClockHandle* GetHandleForClock(struct UObject* WorldContextObject, struct FName ClockName); // Function AudioMixer.QuartzSubsystem.GetHandleForClock // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7824
	float GetGameThreadToAudioRenderThreadMinLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMinLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7794
	float GetGameThreadToAudioRenderThreadMaxLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadMaxLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7794
	float GetGameThreadToAudioRenderThreadAverageLatency(struct UObject* WorldContextObject); // Function AudioMixer.QuartzSubsystem.GetGameThreadToAudioRenderThreadAverageLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b7704
	float GetEstimatedClockRunTime(struct UObject* WorldContextObject, struct FName& InClockName); // Function AudioMixer.QuartzSubsystem.GetEstimatedClockRunTime // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b75a8
	float GetDurationOfQuantizationTypeInSeconds(struct UObject* WorldContextObject, struct FName ClockName, enum class EQuartzCommandQuantization& QuantizationType, float Multiplier); // Function AudioMixer.QuartzSubsystem.GetDurationOfQuantizationTypeInSeconds // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b73a4
	struct FQuartzTransportTimeStamp GetCurrentClockTimestamp(struct UObject* WorldContextObject, struct FName& InClockName); // Function AudioMixer.QuartzSubsystem.GetCurrentClockTimestamp // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b7040
	float GetAudioRenderThreadToGameThreadMinLatency(); // Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMinLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b6e8c
	float GetAudioRenderThreadToGameThreadMaxLatency(); // Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadMaxLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b6e64
	float GetAudioRenderThreadToGameThreadAverageLatency(); // Function AudioMixer.QuartzSubsystem.GetAudioRenderThreadToGameThreadAverageLatency // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b6e38
	bool DoesClockExist(struct UObject* WorldContextObject, struct FName ClockName); // Function AudioMixer.QuartzSubsystem.DoesClockExist // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b6c08
	void DeleteClockByName(struct UObject* WorldContextObject, struct FName ClockName); // Function AudioMixer.QuartzSubsystem.DeleteClockByName // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b6b44
	void DeleteClockByHandle(struct UObject* WorldContextObject, struct UQuartzClockHandle*& InClockHandle); // Function AudioMixer.QuartzSubsystem.DeleteClockByHandle // (Final|RequiredAPI|Native|Public|HasOutParms|BlueprintCallable) // @ game+0x60b6a74
	struct UQuartzClockHandle* CreateNewClock(struct UObject* WorldContextObject, struct FName ClockName, struct FQuartzClockSettings InSettings, bool bOverrideSettingsIfClockExists, bool bUseAudioEngineClockManager); // Function AudioMixer.QuartzSubsystem.CreateNewClock // (Final|RequiredAPI|Native|Public|BlueprintCallable) // @ game+0x60b64f4
};


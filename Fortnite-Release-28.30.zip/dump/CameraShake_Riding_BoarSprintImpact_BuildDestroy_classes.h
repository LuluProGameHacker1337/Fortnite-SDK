// BlueprintGeneratedClass CameraShake_Riding_BoarSprintImpact_BuildDestroy.CameraShake_Riding_BoarSprintImpact_BuildDestroy_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_Riding_BoarSprintImpact_BuildDestroy_C : ULegacyCameraShake {
};


// BlueprintGeneratedClass CamShake_Athena_Player_PreSlide.CamShake_Athena_Player_PreSlide_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCamShake_Athena_Player_PreSlide_C : ULegacyCameraShake {
};


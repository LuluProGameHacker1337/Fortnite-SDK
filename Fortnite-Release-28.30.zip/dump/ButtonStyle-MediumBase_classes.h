// BlueprintGeneratedClass ButtonStyle-MediumBase.ButtonStyle-MediumBase_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-MediumBase_C : UButtonStyle-Base_C {
};


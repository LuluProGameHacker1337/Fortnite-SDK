// BlueprintGeneratedClass Border-Bang.Border-Bang_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-Bang_C : UCommonBorderStyle {
};


// BlueprintGeneratedClass BP_PlayerAugmentSystemBase.BP_PlayerAugmentSystemBase_C
// Size: 0x1a8 (Inherited: 0x1a8)
struct UBP_PlayerAugmentSystemBase_C : UFortPlayerStateComponent_PlayerAugmentSystem {
};


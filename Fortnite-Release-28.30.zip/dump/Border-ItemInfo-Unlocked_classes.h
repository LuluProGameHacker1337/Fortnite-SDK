// BlueprintGeneratedClass Border-ItemInfo-Unlocked.Border-ItemInfo-Unlocked_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-ItemInfo-Unlocked_C : UCommonBorderStyle {
};


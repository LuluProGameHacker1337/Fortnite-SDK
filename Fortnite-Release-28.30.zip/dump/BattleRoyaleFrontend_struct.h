// Enum BattleRoyaleFrontend.EOptionalBattleRoyaleFrontendExperienceFlowSteps
enum class EOptionalBattleRoyaleFrontendExperienceFlowSteps : uint8 {
	TryPlaySeasonTrailer = 0,
	TryPlayBattlePassTrailer = 1,
	TryShowHabaneroIntroModal = 2,
	TryShowFireModeSelectionReminderModal = 3,
	TryShowFireModeModal = 4,
	EOptionalBattleRoyaleFrontendExperienceFlowSteps_MAX = 5
};


// BlueprintGeneratedClass ButtonStyle_CycleArrow_Right_Double.ButtonStyle_CycleArrow_Right_Double_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle_CycleArrow_Right_Double_C : UButtonStyle-MediumTransparentNoCues_C {
};


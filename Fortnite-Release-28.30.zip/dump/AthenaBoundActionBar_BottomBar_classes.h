// BlueprintGeneratedClass AthenaBoundActionBar_BottomBar.AthenaBoundActionBar_BottomBar_C
// Size: 0x288 (Inherited: 0x288)
struct UAthenaBoundActionBar_BottomBar_C : UAthenaBoundActionBar {
};


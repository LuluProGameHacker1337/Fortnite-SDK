// BlueprintGeneratedClass CameraShake_Riding_Sprint_Loop.CameraShake_Riding_Sprint_Loop_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_Riding_Sprint_Loop_C : ULegacyCameraShake {
};


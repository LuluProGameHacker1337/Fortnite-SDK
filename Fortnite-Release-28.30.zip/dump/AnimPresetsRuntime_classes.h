// Class AnimPresetsRuntime.AnimPreset
// Size: 0x28 (Inherited: 0x28)
struct UAnimPreset : UObject {
};

// Class AnimPresetsRuntime.AnimPreset_BasicLocomotion
// Size: 0x78 (Inherited: 0x28)
struct UAnimPreset_BasicLocomotion : UAnimPreset {
	struct FAnimPreset_SingleAnimationData Idle; // 0x28(0x10)
	struct FAnimPreset_SingleAnimationData MoveForward; // 0x38(0x10)
	struct FAnimPreset_SingleAnimationData MoveBackward; // 0x48(0x10)
	struct FAnimPreset_SingleAnimationData MoveLeft; // 0x58(0x10)
	struct FAnimPreset_SingleAnimationData MoveRight; // 0x68(0x10)
};

// Class AnimPresetsRuntime.GameFeatureAction_AnimPreset
// Size: 0x88 (Inherited: 0x28)
struct UGameFeatureAction_AnimPreset : UGameFeatureAction {
	struct TSoftClassPtr<UObject> AnimBP_Preset_BasicLocomotion; // 0x28(0x20)
	struct TSoftClassPtr<UObject> AnimBP_CopyPoseFromMesh; // 0x48(0x20)
	struct TSoftClassPtr<UObject> AnimBP_RetargetPoseFromMesh; // 0x68(0x20)
};


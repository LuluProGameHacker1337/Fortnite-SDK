// BlueprintGeneratedClass BBE_Sprint.BBE_Sprint_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_Sprint_C : UFortMobileActionButtonBehaviorExtension {
};


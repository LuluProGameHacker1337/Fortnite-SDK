// BlueprintGeneratedClass BP_CamShake_BlurPulse.BP_CamShake_BlurPulse_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UBP_CamShake_BlurPulse_C : ULegacyCameraShake {
};


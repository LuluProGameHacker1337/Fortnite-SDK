// BlueprintGeneratedClass BP_UI_Habanero_TierTypeDataBase.BP_UI_Habanero_TierTypeDataBase_C
// Size: 0x8c (Inherited: 0x38)
struct UBP_UI_Habanero_TierTypeDataBase_C : UFortHabaneroTierTypeData {
	struct FColor Text_Color; // 0x38(0x04)
	struct FColor Background_Color; // 0x3c(0x04)
	struct FColor ParticlesOutward_Color; // 0x40(0x04)
	struct FColor ParticlesInwardSmall_Color; // 0x44(0x04)
	struct FColor ParticlesInwardMedium_Color; // 0x48(0x04)
	struct FColor ParticlesInwardBig_Color; // 0x4c(0x04)
	struct FColor ProgressBar_Color; // 0x50(0x04)
	struct FColor ProgressBackground_Color; // 0x54(0x04)
	struct FColor DeltaBar_Color; // 0x58(0x04)
	struct FColor BarGlow_Color; // 0x5c(0x04)
	struct FColor InnerBackground_Color; // 0x60(0x04)
	struct FColor ProgressOutline_Color; // 0x64(0x04)
	struct FColor Flare_Color; // 0x68(0x04)
	char pad_6C[0x4]; // 0x6c(0x04)
	struct FText Name; // 0x70(0x18)
	struct FColor EdgeBar_Color; // 0x88(0x04)
};


// BlueprintGeneratedClass BBE_SportbikeBoost.BBE_SportbikeBoost_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_SportbikeBoost_C : UFortMobileActionButtonBehaviorExtension {
};


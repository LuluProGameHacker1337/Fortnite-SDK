// BlueprintGeneratedClass Border-SolidBG-ToolTip.Border-SolidBG-ToolTip_C
// Size: 0xf0 (Inherited: 0xf0)
struct UBorder-SolidBG-ToolTip_C : UBorder-ShellTopBar_C {
};


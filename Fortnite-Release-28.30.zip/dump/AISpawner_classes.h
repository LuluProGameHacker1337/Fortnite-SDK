// Class AISpawner.AISpawnerPreviewerComponent
// Size: 0x280 (Inherited: 0x270)
struct UAISpawnerPreviewerComponent : UChildActorComponent {
	struct AFortPlayerMannequin* PlayerMannequinClass; // 0x270(0x08)
	char pad_278[0x8]; // 0x278(0x08)

	void SetCIDForPreview(struct UAthenaCharacterItemDefinition* InCID); // Function AISpawner.AISpawnerPreviewerComponent.SetCIDForPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xb845d24
	void SetActorForPreview(struct AActor* InActorClass); // Function AISpawner.AISpawnerPreviewerComponent.SetActorForPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xb845c10
	void ClearCIDPreview(); // Function AISpawner.AISpawnerPreviewerComponent.ClearCIDPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xb845bfc
	void ClearActorPreview(); // Function AISpawner.AISpawnerPreviewerComponent.ClearActorPreview // (Final|Native|Protected|BlueprintCallable) // @ game+0xb845bfc
};


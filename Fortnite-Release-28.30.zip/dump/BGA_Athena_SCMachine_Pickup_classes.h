// BlueprintGeneratedClass BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C
// Size: 0xb93 (Inherited: 0xaa0)
struct ABGA_Athena_SCMachine_Pickup_C : ABuildingGameplayActorSpawnChip {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0xaa0(0x08)
	struct UCapsuleComponent* OverlapCollision; // 0xaa8(0x08)
	struct UStaticMeshComponent* ParentMesh; // 0xab0(0x08)
	struct UFortLinkToActorComponent* FortLinkToActor; // 0xab8(0x08)
	struct UAudioComponent* SC_Machine_Memory_Card_Loop_Cue; // 0xac0(0x08)
	struct UParticleSystemComponent* SpawninEffect; // 0xac8(0x08)
	struct UStaticMeshComponent* BackgroundGlow; // 0xad0(0x08)
	struct UStaticMeshComponent* Card; // 0xad8(0x08)
	int32_t UnHide; // 0xae0(0x04)
	char pad_AE4[0x4]; // 0xae4(0x04)
	double DelayBeforeUnhide; // 0xae8(0x08)
	char OwnerTeam; // 0xaf0(0x01)
	char pad_AF1[0x7]; // 0xaf1(0x07)
	struct FTimerHandle Timer_DestroyPickup; // 0xaf8(0x08)
	struct FScalableFloat Row_PickupLife; // 0xb00(0x28)
	struct FText InteractText; // 0xb28(0x18)
	struct UParticleSystem* SpawnOutParticle; // 0xb40(0x08)
	struct USoundBase* PickupSound; // 0xb48(0x08)
	bool SpawnSoundPlayed; // 0xb50(0x01)
	char pad_B51[0x7]; // 0xb51(0x07)
	struct USoundBase* SpawnInSound; // 0xb58(0x08)
	bool IsPendingKill; // 0xb60(0x01)
	bool HideAndKill; // 0xb61(0x01)
	char pad_B62[0x6]; // 0xb62(0x06)
	struct FScalableFloat Row_PickUpInteractTime; // 0xb68(0x28)
	bool IsDelayingDeath; // 0xb90(0x01)
	bool OwnerDiedInVortex; // 0xb91(0x01)
	bool CollectedPickup; // 0xb92(0x01)

	bool BuildDataRegistryResolverScope(struct TArray<struct FName>& InOutResolverScopes, int32_t& InOutPriority); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BuildDataRegistryResolverScope // (Event|Public|HasOutParms|HasDefaults|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	struct UObject* GetCacheContextOverride(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.GetCacheContextOverride // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	void Enable Hide and Kill(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Enable Hide and Kill // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Mark as Pending Kill(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Mark as Pending Kill // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Mark Spawn Sound As Played(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Mark Spawn Sound As Played // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Set Un Hide(int32_t UnHide); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Set Un Hide // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Mark As Collected(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.Mark As Collected // (Private|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnRep_CollectedPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnRep_CollectedPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	bool BlueprintGetInteractionTime(struct AFortPawn* InteractingPawn, float& OutInteractionTime, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintGetInteractionTime // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	bool CanHandleCleanupEvents(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.CanHandleCleanupEvents // (Event|Protected|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	void OnRep_HideAndKill(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnRep_HideAndKill // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	bool ShouldDie(float Damage, struct AController* EventInstigator, struct AActor* DamageCauser); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ShouldDie // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	struct FText BlueprintGetInteractionString(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintGetInteractionString // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|Const) // @ game+0x3d1d968
	bool BlueprintCanInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted, enum class TInteractionType InteractionType); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintCanInteract // (Event|Public|HasOutParms|BlueprintCallable|BlueprintEvent|BlueprintPure|Const) // @ game+0x3d1d968
	void OnRep_UnHide(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnRep_UnHide // (HasDefaults|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void UserConstructionScript(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.UserConstructionScript // (Event|Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ReceiveBeginPlay(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void DestroyPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.DestroyPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void BlueprintOnInteract(struct AFortPawn* InteractingPawn, enum class EInteractionBeingAttempted InteractionBeingAttempted); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BlueprintOnInteract // (BlueprintAuthorityOnly|Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void CollectPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.CollectPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnDestroyPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnDestroyPickup // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void SpawnSound(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.SpawnSound // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnDeathServer(float Damage, struct FGameplayTagContainer& DamageTags, struct FVector Momentum, struct FHitResult& HitInfo, struct AController* InstigatedBy, struct AActor* DamageCauser, struct FGameplayEffectContextHandle EffectContext); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.OnDeathServer // (BlueprintAuthorityOnly|Event|Public|HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	void HideAndKillPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.HideAndKillPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void DelayDestroyPickup(); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.DelayDestroyPickup // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void BndEvt__Collision_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature(struct UPrimitiveComponent* OverlappedComponent, struct AActor* OtherActor, struct UPrimitiveComponent* OtherComp, int32_t OtherBodyIndex, bool bFromSweep, struct FHitResult& SweepResult); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BndEvt__Collision_K2Node_ComponentBoundEvent_0_ComponentBeginOverlapSignature__DelegateSignature // (HasOutParms|BlueprintEvent) // @ game+0x3d1d968
	void BndEvt__BGA_Athena_SCMachine_Pickup_FortLinkToActor_K2Node_ComponentBoundEvent_4_OnLinkedActorDestroyed__DelegateSignature(struct AActor* DamageCauser); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.BndEvt__BGA_Athena_SCMachine_Pickup_FortLinkToActor_K2Node_ComponentBoundEvent_4_OnLinkedActorDestroyed__DelegateSignature // (BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_BGA_Athena_SCMachine_Pickup(int32_t EntryPoint); // Function BGA_Athena_SCMachine_Pickup.BGA_Athena_SCMachine_Pickup_C.ExecuteUbergraph_BGA_Athena_SCMachine_Pickup // (Final|UbergraphFunction|HasDefaults) // @ game+0x3d1d968
};


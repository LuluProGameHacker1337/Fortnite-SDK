// BlueprintGeneratedClass BP_PlayerStateCustomFeedMessages.BP_PlayerStateCustomFeedMessages_C
// Size: 0x108 (Inherited: 0x108)
struct UBP_PlayerStateCustomFeedMessages_C : UFortPlayerStateComponent_CustomFeedMessage {
};


// BlueprintGeneratedClass BB_RerollAugment.BB_RerollAugment_C
// Size: 0x140 (Inherited: 0x140)
struct UBB_RerollAugment_C : UFortMobileActionButtonBehavior_RerollAugments {
};


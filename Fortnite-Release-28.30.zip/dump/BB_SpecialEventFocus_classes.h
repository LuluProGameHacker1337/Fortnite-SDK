// BlueprintGeneratedClass BB_SpecialEventFocus.BB_SpecialEventFocus_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_SpecialEventFocus_C : UFortMobileActionButtonBehavior {
};


// BlueprintGeneratedClass CameraModifier_Athena_Sliding.CameraModifier_Athena_Sliding_C
// Size: 0x108 (Inherited: 0x100)
struct UCameraModifier_Athena_Sliding_C : USlidingCameraModifier {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x100(0x08)

	void BlendOut(); // Function CameraModifier_Athena_Sliding.CameraModifier_Athena_Sliding_C.BlendOut // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_CameraModifier_Athena_Sliding(int32_t EntryPoint); // Function CameraModifier_Athena_Sliding.CameraModifier_Athena_Sliding_C.ExecuteUbergraph_CameraModifier_Athena_Sliding // (Final|UbergraphFunction) // @ game+0x3d1d968
};


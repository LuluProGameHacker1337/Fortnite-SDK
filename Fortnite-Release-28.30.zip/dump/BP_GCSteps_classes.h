// BlueprintGeneratedClass BP_GCSteps.BP_GCSteps_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UBP_GCSteps_C : ULegacyCameraShake {
};


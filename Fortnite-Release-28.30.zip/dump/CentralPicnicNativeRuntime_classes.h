// Class CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge
// Size: 0x2f0 (Inherited: 0x290)
struct ACentralPicnicMeshNetworkBridge : AInfo {
	struct UMeshNetworkComponent* MeshNetworkComponent; // 0x290(0x08)
	int64_t CurrentHealth; // 0x298(0x08)
	int64_t DefaultHealth; // 0x2a0(0x08)
	float DamageModifier; // 0x2a8(0x04)
	char pad_2AC[0x44]; // 0x2ac(0x44)

	void WaitForMeshNetwork(); // Function CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge.WaitForMeshNetwork // (Final|Native|Protected) // @ game+0xb810824
	void OnRep_DefaultHealth(int64_t OldValue); // Function CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge.OnRep_DefaultHealth // (Final|Native|Protected|BlueprintCallable|Const) // @ game+0xb8107a4
	void OnRep_DamageModifier(float OldValue); // Function CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge.OnRep_DamageModifier // (Final|Native|Protected|BlueprintCallable|Const) // @ game+0xb810724
	void OnRep_CurrentHealth(int64_t OldValue); // Function CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge.OnRep_CurrentHealth // (Final|Native|Protected|BlueprintCallable|Const) // @ game+0xb8106a4
	void HandleMeshNetworkTypeSet(enum class EMeshNetworkNodeType NodeType); // Function CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge.HandleMeshNetworkTypeSet // (Final|Native|Private) // @ game+0xb810624
	void BroadcastEvent_HealthUpdated(int64_t NewValue); // Function CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge.BroadcastEvent_HealthUpdated // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xb8105a4
	void BroadcastEvent_DefaultHealthUpdated(int64_t NewValue); // Function CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge.BroadcastEvent_DefaultHealthUpdated // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xb810524
	void BroadcastEvent_DamageModifierUpdated(float NewValue); // Function CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge.BroadcastEvent_DamageModifierUpdated // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xb8104a4
	void BroadcastEvent_ChainsDamaged(int64_t DamageDealt); // Function CentralPicnicNativeRuntime.CentralPicnicMeshNetworkBridge.BroadcastEvent_ChainsDamaged // (Final|Native|Public|BlueprintCallable|Const) // @ game+0xb810424
};


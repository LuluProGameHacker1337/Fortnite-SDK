// BlueprintGeneratedClass BBE_Rock_VehicleExit.BBE_Rock_VehicleExit_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_Rock_VehicleExit_C : UFortMobileActionButtonBehaviorExtension {
};


// ScriptStruct CentralPicnicNativeRuntime.CentralPicnicMeshNetworkMetadata
// Size: 0x18 (Inherited: 0x00)
struct FCentralPicnicMeshNetworkMetadata {
	int64_t CurrentHealth; // 0x00(0x08)
	int64_t DefaultHealth; // 0x08(0x08)
	float DamageModifier; // 0x10(0x04)
	bool bHasInitialized; // 0x14(0x01)
	bool bHasCompleted; // 0x15(0x01)
	char pad_16[0x2]; // 0x16(0x02)
};

// ScriptStruct CentralPicnicNativeRuntime.CentralPicnicEvent_HealthUpdated
// Size: 0x08 (Inherited: 0x00)
struct FCentralPicnicEvent_HealthUpdated {
	int64_t CurrentHealth; // 0x00(0x08)
};

// ScriptStruct CentralPicnicNativeRuntime.CentralPicnicEvent_DefaultHealthUpdated
// Size: 0x08 (Inherited: 0x00)
struct FCentralPicnicEvent_DefaultHealthUpdated {
	int64_t CurrentDefaultHealth; // 0x00(0x08)
};

// ScriptStruct CentralPicnicNativeRuntime.CentralPicnicEvent_DamageModifierUpdated
// Size: 0x04 (Inherited: 0x00)
struct FCentralPicnicEvent_DamageModifierUpdated {
	float CurrentDamageModifier; // 0x00(0x04)
};

// ScriptStruct CentralPicnicNativeRuntime.CentralPicnicEvent_ChainsDamaged
// Size: 0x08 (Inherited: 0x00)
struct FCentralPicnicEvent_ChainsDamaged {
	int64_t DamageDealt; // 0x00(0x08)
};


// BlueprintGeneratedClass BP_ProjectileTrajectorySplineMesh.BP_ProjectileTrajectorySplineMesh_C
// Size: 0x700 (Inherited: 0x700)
struct UBP_ProjectileTrajectorySplineMesh_C : USplineMeshComponent {
};


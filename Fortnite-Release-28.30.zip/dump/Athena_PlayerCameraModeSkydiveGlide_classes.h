// BlueprintGeneratedClass Athena_PlayerCameraModeSkydiveGlide.Athena_PlayerCameraModeSkydiveGlide_C
// Size: 0x1ba0 (Inherited: 0x1ba0)
struct UAthena_PlayerCameraModeSkydiveGlide_C : UAthena_PlayerCameraModeBase_C {
};


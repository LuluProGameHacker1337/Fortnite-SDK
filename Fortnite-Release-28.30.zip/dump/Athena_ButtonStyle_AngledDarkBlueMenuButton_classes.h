// BlueprintGeneratedClass Athena_ButtonStyle_AngledDarkBlueMenuButton.Athena_ButtonStyle_AngledDarkBlueMenuButton_C
// Size: 0x730 (Inherited: 0x730)
struct UAthena_ButtonStyle_AngledDarkBlueMenuButton_C : UAthena_ButtonStyle_AngledBlueMenuButton_C {
};


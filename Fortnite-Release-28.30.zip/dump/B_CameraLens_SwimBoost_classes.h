// BlueprintGeneratedClass B_CameraLens_SwimBoost.B_CameraLens_SwimBoost_C
// Size: 0x388 (Inherited: 0x380)
struct AB_CameraLens_SwimBoost_C : AEmitterCameraLensEffectBase {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x380(0x08)

	void ReceiveBeginPlay(); // Function B_CameraLens_SwimBoost.B_CameraLens_SwimBoost_C.ReceiveBeginPlay // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_B_CameraLens_SwimBoost(int32_t EntryPoint); // Function B_CameraLens_SwimBoost.B_CameraLens_SwimBoost_C.ExecuteUbergraph_B_CameraLens_SwimBoost // (Final|UbergraphFunction) // @ game+0x3d1d968
};


// BlueprintGeneratedClass CameraShake_tacticalSprint_StartAnim.CameraShake_tacticalSprint_StartAnim_C
// Size: 0x1f0 (Inherited: 0x1f0)
struct UCameraShake_tacticalSprint_StartAnim_C : ULegacyCameraShake {
};


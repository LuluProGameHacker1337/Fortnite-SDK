// BlueprintGeneratedClass BP_Figure_CharacterAccUserData.BP_Figure_CharacterAccUserData_C
// Size: 0x70 (Inherited: 0x30)
struct UBP_Figure_CharacterAccUserData_C : UPrimaryDataAsset {
	struct TArray<struct FName> Character Accent Registration; // 0x30(0x10)
	struct TArray<struct FVector> Character Accent Initial; // 0x40(0x10)
	struct TArray<struct FFigure_PushAwayControl_Struct> Spawn Push Away Control; // 0x50(0x10)
	struct TArray<bool> CharacterAccent Anim Override; // 0x60(0x10)
};


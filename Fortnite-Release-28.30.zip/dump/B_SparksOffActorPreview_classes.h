// BlueprintGeneratedClass B_SparksOffActorPreview.B_SparksOffActorPreview_C
// Size: 0x528 (Inherited: 0x488)
struct AB_SparksOffActorPreview_C : ABp_SparksActorPreviewLightRig_Base_C {
	struct FPointerToUberGraphFrame UberGraphFrame; // 0x488(0x08)
	struct USkeletalMeshComponent* SampleMesh; // 0x490(0x08)
	struct UArrowComponent* Arrow; // 0x498(0x08)
	struct UDirectionalLightComponent* DirectionalLight_pc; // 0x4a0(0x08)
	struct UDirectionalLightComponent* DirectionalLight_mobile; // 0x4a8(0x08)
	struct USkyLightComponent* SkyLight_mobile; // 0x4b0(0x08)
	struct USpotLightComponent* RimRight3_pc; // 0x4b8(0x08)
	struct USkyLightComponent* SkyLight_pc; // 0x4c0(0x08)
	struct USpotLightComponent* SpotLight_rimlight_pc; // 0x4c8(0x08)
	struct USpotLightComponent* RimRight2_pc; // 0x4d0(0x08)
	struct USpotLightComponent* RimBottom_pc; // 0x4d8(0x08)
	struct USpotLightComponent* RimTop_pc; // 0x4e0(0x08)
	struct USceneComponent* Lighting; // 0x4e8(0x08)
	float Timeline_0_HiddenAmount_1D4E289F4B8CA6B6B9F4579D0FE7ABCC; // 0x4f0(0x04)
	enum class ETimelineDirection Timeline_0__Direction_1D4E289F4B8CA6B6B9F4579D0FE7ABCC; // 0x4f4(0x01)
	char pad_4F5[0x3]; // 0x4f5(0x03)
	struct UTimelineComponent* ; // 0x4f8(0x08)
	enum class ETimelineDirection Timeline__Direction_941C70EB408D2013A38BD198CDF9688B; // 0x500(0x01)
	char pad_501[0x7]; // 0x501(0x07)
	struct UTimelineComponent* Timeline; // 0x508(0x08)
	bool Is  active; // 0x510(0x01)
	char pad_511[0x7]; // 0x511(0x07)
	struct TArray<struct USkeletalMeshComponent*> SkeletalMeshToResIn; // 0x518(0x10)

	void GetInstrumentMeshComponents(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.GetInstrumentMeshComponents // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Light Control(bool Active); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Light Control // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Set UP Lighting(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Set UP Lighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Switch Mobile Lighting(bool NewParam); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Switch Mobile Lighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Switch PC Lighting(bool Visibility); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Switch PC Lighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void HandleLightingSettingsChanged(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.HandleLightingSettingsChanged // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Switch Erebus Lighting(bool Visibility); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Switch Erebus Lighting // (Public|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void Timeline__FinishedFunc(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Timeline__FinishedFunc // (BlueprintEvent) // @ game+0x3d1d968
	void Timeline__UpdateFunc(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Timeline__UpdateFunc // (BlueprintEvent) // @ game+0x3d1d968
	void Timeline__PlayResIn__EventFunc(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Timeline__PlayResIn__EventFunc // (BlueprintEvent) // @ game+0x3d1d968
	void Timeline__LoadingFXOutro__EventFunc(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Timeline__LoadingFXOutro__EventFunc // (BlueprintEvent) // @ game+0x3d1d968
	void Timeline__ShowPawn__EventFunc(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Timeline__ShowPawn__EventFunc // (BlueprintEvent) // @ game+0x3d1d968
	void Timeline_0__FinishedFunc(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Timeline_0__FinishedFunc // (BlueprintEvent) // @ game+0x3d1d968
	void Timeline_0__UpdateFunc(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.Timeline_0__UpdateFunc // (BlueprintEvent) // @ game+0x3d1d968
	void OnPreviewVisualsSpawned(bool bUseSecondaryTransitionEffects, bool bShowFloor); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.OnPreviewVisualsSpawned // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void UpdateSettings(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.UpdateSettings // (BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnPreviewVisualsBeginLoading(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.OnPreviewVisualsBeginLoading // (Event|Protected|BlueprintEvent) // @ game+0x3d1d968
	void OnAllLODStreamingComplete(); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.OnAllLODStreamingComplete // (Event|Public|BlueprintEvent) // @ game+0x3d1d968
	void ExecuteUbergraph_B_SparksOffActorPreview(int32_t EntryPoint); // Function B_SparksOffActorPreview.B_SparksOffActorPreview_C.ExecuteUbergraph_B_SparksOffActorPreview // (Final|UbergraphFunction) // @ game+0x3d1d968
};


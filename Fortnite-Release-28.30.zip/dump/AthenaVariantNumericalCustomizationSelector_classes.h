// WidgetBlueprintGeneratedClass AthenaVariantNumericalCustomizationSelector.AthenaVariantNumericalCustomizationSelector_C
// Size: 0x408 (Inherited: 0x408)
struct UAthenaVariantNumericalCustomizationSelector_C : UFortVariantNumericalPicker {
};


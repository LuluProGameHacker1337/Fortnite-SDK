// BlueprintGeneratedClass BB_HoagieMoveDown.BB_HoagieMoveDown_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_HoagieMoveDown_C : UFortMobileActionButtonBehavior {
};


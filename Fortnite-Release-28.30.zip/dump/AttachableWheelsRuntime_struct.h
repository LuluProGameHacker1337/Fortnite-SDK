// ScriptStruct AttachableWheelsRuntime.AttachableWheelAttachData
// Size: 0x58 (Inherited: 0x00)
struct FAttachableWheelAttachData {
	struct TWeakObjectPtr<struct UPrimitiveComponent> PrimitiveComponent; // 0x00(0x08)
	struct FVector Pos; // 0x08(0x18)
	struct FVector Axis1; // 0x20(0x18)
	struct FVector Axis2; // 0x38(0x18)
	struct FName AttachmentName; // 0x50(0x04)
	char pad_54[0x4]; // 0x54(0x04)
};


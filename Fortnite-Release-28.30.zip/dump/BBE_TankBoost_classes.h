// BlueprintGeneratedClass BBE_TankBoost.BBE_TankBoost_C
// Size: 0x80 (Inherited: 0x80)
struct UBBE_TankBoost_C : UFortMobileActionButtonBehaviorExtension {
};


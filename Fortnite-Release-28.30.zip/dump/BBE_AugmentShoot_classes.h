// BlueprintGeneratedClass BBE_AugmentShoot.BBE_AugmentShoot_C
// Size: 0x90 (Inherited: 0x90)
struct UBBE_AugmentShoot_C : UFortMobileActionBBE_AugmentShoot {
};


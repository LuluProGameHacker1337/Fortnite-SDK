// BlueprintGeneratedClass Athena_PlayerCameraModeMelee.Athena_PlayerCameraModeMelee_C
// Size: 0x1ba0 (Inherited: 0x1ba0)
struct UAthena_PlayerCameraModeMelee_C : UAthena_PlayerCameraModeBase_C {
};


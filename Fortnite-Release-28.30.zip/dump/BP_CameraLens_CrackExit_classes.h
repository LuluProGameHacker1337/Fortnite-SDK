// BlueprintGeneratedClass BP_CameraLens_CrackExit.BP_CameraLens_CrackExit_C
// Size: 0x388 (Inherited: 0x380)
struct ABP_CameraLens_CrackExit_C : AEmitterCameraLensEffectBase {
	struct UParticleSystemComponent* Portal; // 0x380(0x08)
};


// BlueprintGeneratedClass ButtonStyle-TextOnlyBase_Empty.ButtonStyle-TextOnlyBase_Empty_C
// Size: 0x730 (Inherited: 0x730)
struct UButtonStyle-TextOnlyBase_Empty_C : UButtonStyle-Base_C {
};


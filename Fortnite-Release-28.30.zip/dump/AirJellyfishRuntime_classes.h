// Class AirJellyfishRuntime.FortAirJellyfishAnimInstance
// Size: 0x580 (Inherited: 0x560)
struct UFortAirJellyfishAnimInstance : UFortAnimInstance {
	float RotatorLerpRate; // 0x558(0x04)
	float VelocityDirectionScalar; // 0x55c(0x04)
	struct FRotator RootRotation; // 0x560(0x18)
};


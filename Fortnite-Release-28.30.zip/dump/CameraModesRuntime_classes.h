// Class CameraModesRuntime.CameraModes_FirstPersonCameraController
// Size: 0x3e8 (Inherited: 0x3c0)
struct ACameraModes_FirstPersonCameraController : AFortFirstPersonCameraController {
	struct FGameplayTag PreventWeaponHolsterTag; // 0x3c0(0x04)
	float HeadMotionScalar; // 0x3c4(0x04)
	struct TArray<struct AFortWeapon*> AllowedWeaponClassList; // 0x3c8(0x10)
	struct USkeletalMeshComponent* FirstPersonSkeletalMeshComp; // 0x3d8(0x08)
	char pad_3E0[0x8]; // 0x3e0(0x08)

	void UpdateFirstPersonFOV(float FOV); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.UpdateFirstPersonFOV // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void SetFovOverride(float FOV, float TransitionTime); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.SetFovOverride // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void OnLocalPlayerVisibilityChanged(bool bShouldBeVisible); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.OnLocalPlayerVisibilityChanged // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
	void HandleWeaponEquipped(struct AFortWeapon* NewWeapon, struct AFortWeapon* PrevWeapon); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.HandleWeaponEquipped // (Final|Native|Private) // @ game+0xb84f05c
	void ClearFovOverride(float TransitionTime); // Function CameraModesRuntime.CameraModes_FirstPersonCameraController.ClearFovOverride // (Event|Protected|BlueprintCallable|BlueprintEvent) // @ game+0x3d1d968
};


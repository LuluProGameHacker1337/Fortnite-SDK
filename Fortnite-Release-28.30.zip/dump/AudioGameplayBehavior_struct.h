// Enum AudioGameplayBehavior.EAudioGameplayBehaviorPlayState
enum class EAudioGameplayBehaviorPlayState : uint8 {
	Stopped = 0,
	Playing = 1,
	TickingWhileStopped = 2,
	EAudioGameplayBehaviorPlayState_MAX = 3
};

// ScriptStruct AudioGameplayBehavior.ActiveVoice
// Size: 0x18 (Inherited: 0x00)
struct FActiveVoice {
	struct USoundBase* sound; // 0x00(0x08)
	struct UAudioComponent* Component; // 0x08(0x08)
	struct FPlayingId ID; // 0x10(0x04)
	char pad_14[0x4]; // 0x14(0x04)
};

// ScriptStruct AudioGameplayBehavior.PlayingId
// Size: 0x04 (Inherited: 0x00)
struct FPlayingId {
	char pad_0[0x4]; // 0x00(0x04)
};

// ScriptStruct AudioGameplayBehavior.AudioGameplayBehaviorInstance
// Size: 0x10 (Inherited: 0x00)
struct FAudioGameplayBehaviorInstance {
	struct UAudioGameplayBehavior* sound; // 0x00(0x08)
	struct UAudioGameplayBehavior* Instance; // 0x08(0x08)
};


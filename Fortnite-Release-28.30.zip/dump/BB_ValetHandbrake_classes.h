// BlueprintGeneratedClass BB_ValetHandbrake.BB_ValetHandbrake_C
// Size: 0x138 (Inherited: 0x138)
struct UBB_ValetHandbrake_C : UFortMobileActionButtonBehavior {
};

